import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { box, chineseRoof, plaqueMesh, M } from './kit.js';

/** Compressed present-day memorial and adjacent mixed-use street. The
 * historical garden creek is not part of this reconstructed site. */
export function buildMemorial(scene) {
  const base=1.45, A=-13.3;
  const group=new THREE.Group(); group.name='Mengxi present-day memorial';
  const mat=(c,roughness=.88,emissive='#0c0d10',emissiveIntensity=.10)=>new THREE.MeshStandardMaterial({color:c,roughness,emissive,emissiveIntensity});
  const gray=mat('#7a7c78'), stone=mat('#a0a096'), darker=mat('#535451'), wood=mat('#563f36',.78),
    plaster=mat('#afaaa0'), asphalt=mat('#44474b',.99), paving=mat('#8d8c83',.95),
    foliage=mat('#354332',.96,'#18241c',.24), warm=mat('#858071',.70,'#ffa663',.19),
    glass=mat('#262d32',.63,'#293646',.18), earth=mat('#464c37',.98);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=512;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#777c7e';ctx.fillRect(0,0,512,512);
  let seed=9251;
  function unit(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
  for(let row=0;row<35;row++)for(let col=-1;col<26;col++){
    const x=(col+(row%2)*.5)*20.5,y=row*14.63,r=129+(unit()-.50)*23;
    ctx.fillStyle=`rgb(${r+2},${r+4},${r+5})`;ctx.fillRect(x+.56,y+.54,19.73,13.66);
    ctx.fillStyle='rgba(160,158,150,.12)';ctx.fillRect(x+.57,y+.86,19.4,1.1);
  }
  const brickMap=new THREE.CanvasTexture(canvas);brickMap.colorSpace=THREE.SRGBColorSpace;
  brickMap.anisotropy=4;
  const brickGray=mat('#a8b1b8',.94);brickGray.map=brickMap;
  const buckets=new Map();
  const put=(m,g)=>{
    if(!buckets.has(m))buckets.set(m,[]);
    // Keep all index layouts and vertex attributes merge compatible.
    buckets.get(m).push(g.index ? g.toNonIndexed() : g);
  };
  const S=(m,w,h,d,x,y,z)=>put(m,box(w,h,d,x,y,z));
  const flush=()=>{for(const [m,p] of buckets){const merged=mergeGeometries(p);const o=new THREE.Mesh(merged,m);o.receiveShadow=true;group.add(o);}buckets.clear();};
  const label=(name,w,h,x,y,z)=>{
    const p=plaqueMesh(name,w,h,{dir:'h',bg:'#b0a795',fg:'#51493b',border:'#a19685'});
    p.position.set(x,y,z);p.rotation.y=Math.PI;group.add(p);
  };
  const roof=(w,d,r,x,y,z)=>{
    const g=chineseRoof({width:w,depth:d,height:r,overhang:.47,curve:.5,eaveLift:.17,hip:false,segU:28,segV:10});
    g.translate(x,y,z);put(M.mxTile,g);
    for(let j=0;j<Math.round(w/.235);j++){
      const xx=x-w/2+.14+j*.235;
      for(const zz of [z-d*.5-.47,z+d*.5+.47]){
        put(M.mxTile,new THREE.CylinderGeometry(.061,.062,.19,7).rotateX(Math.PI/2).translate(xx,y+.008,zz));
      }
    }
  };
  const fills=[];
  const lamp=(x,y,z,amount=16)=>{
    const l=new THREE.PointLight(0xffce99,amount,10.5,2);l.position.set(x,y,z);scene.add(l);fills.push([l,amount]);
  };
  // Ordinary asphalt, narrow continuous sidewalk and selectively recessed shops.
  S(asphalt,92,.17,7.8,-19,base-.15,0);
  S(paving,93,.14,1.5,-19,base-.09,4.62);S(paving,93,.14,1.48,-19,base-.09,-4.6);
  const asphaltPatch=mat('#4c4a4a',.98);
  for(let i=0;i<42;i++){
    const x=-65+i*2.15;
    S(darker,2.105,.16,.24,x,base-.028,3.96);S(darker,2.105,.16,.24,x,base-.028,-3.96);
    if(i%4===0)S(asphaltPatch,2.5,.007,.33,x,base-.060,-1.4+(i%3)*1.2);
  }
  for(const side of [-1,1]){
    for(let i=0;i<16;i++){
      const x=-64+i*5.6,w=5.32;
      if(side===1&&Math.abs(x-A)<14)continue;
      const z=side*6.8,h=3.15+(i%5)*.62;
      const wall=i%5===0?gray:(i%3===0?darker:plaster);
      S(wall,w,h,3.95,x,base+h*.5,z+side*1.25);
      S(darker,w+.19,.17,4.16,x,base+h,z+side*1.22);
      for(const sx of [-1,1]){
        S(wood,1.47,2.06,.18,x+sx*1.06,base+1.3,z-side*.84);
        S((i+side)%7===0?warm:glass,1.31,1.86,.05,x+sx*1.06,base+1.3,z-side*.949);
        S(darker,1.64,.15,.31,x+sx*1.06,base+.24,z-side*.99);
        for(let k=-1;k<=1;k++)S(wood,.04,1.78,.06,x+sx*1.06+k*.28,base+1.3,z-side*.99);
      }
      if(i%5===2){
        S(wall,w+.035,1.89,3.52,x,base+h+.9,z+side*1.3);
        for(const s of [-1,1])S(glass,.87,1.02,.12,x+s*1.05,base+h+.96,z-side*.49);
      }
    }
  }
  // Three-panel grey-brick street portal, a real dark centre opening and stone cheeks.
  const z=5.85, entrance=2.04,ww=12.82,hh=4.34;
  for(const side of [-1,1]){
    const cx=A+side*(ww*.25+entrance*.25);
    S(brickGray,(ww-entrance)/2,hh,.65,cx,base+hh/2,z);
    S(stone,.16,hh-.30,.17,A+side*(entrance*.5+.14),base+hh*.49,z-.39);
    S(stone,.23,hh-.22,.14,A+side*(ww*.5-.32),base+hh*.50,z-.41);
    S(stone,2.23,.70,.16,A+side*3.49,base+2.86,z-.41);
    S(darker,1.85,.42,.20,A+side*3.49,base+2.86,z-.46);
    S(gray,5.62,3.35,5.0,A+side*9.28,base+1.675,z+2.53);
    roof(5.50,5.15,.62,A+side*9.25,base+3.38,z+2.4);
    S(wood,2.75,2.74,.22,A+side*9.25,base+1.38,z-.02);
    for(let i=0;i<9;i++) S(glass,.16,2.15,.06,A+side*9.25+(i-4)*.24,base+1.42,z-.157);
    for(let step=0;step<3;step++)S(stone,2.84,.11,.34,A+side*9.25,base+.09+step*.12,z-.57+step*.32);
  }
  S(brickGray,ww,1.44,.65,A,base+3.60,z);
  S(stone,2.68,.38,.22,A,base+2.92,z-.428);
  roof(ww+.4,4.74,.57,A,base+hh,z+1.86);
  label('梦溪园',2.12,.45,A,base+3.33,z-.548);
  for(let i=0;i<4;i++)S(stone,2.37,.12,.36,A,base+.08+i*.122,z-1.09+i*.34);
  for(const side of [-1,1]){
    put(stone,new THREE.CylinderGeometry(.34,.34,.24,14).rotateZ(Math.PI/2).rotateY(Math.PI/2)
        .translate(A+side*1.43,base+.54,z-.88));
  }
  // Limited dry courtyard. The circular opening and rails follow the 2013
  // documented restoration, not evidence of a surviving Song-period structure.
  S(paving,22,.18,27,A,base-.08,20);
  for(let i=0;i<19;i++)for(let j=0;j<7;j++){
    const x=A-6+(i+.5)*.63,z=7.1+j*.82;
    S(i%3===0?stone:paving,.61,.055,.79,x,base+.03,z);
  }
  const moonZ=13.1,moonTop=4.34,moonR=1.27,c=1.93;
  const wall=new THREE.Shape([new THREE.Vector2(-5.1,0),new THREE.Vector2(5.1,0),new THREE.Vector2(5.1,moonTop),new THREE.Vector2(-5.1,moonTop)]);
  const hole=new THREE.Path();hole.absarc(0,c,moonR,0,Math.PI*2,true);wall.holes.push(hole);
  const gate=new THREE.ExtrudeGeometry(wall,{depth:.65,bevelEnabled:false,curveSegments:40});
  gate.translate(A,base,moonZ);put(gray,gate);
  roof(10.43,1.0,.19,A,base+moonTop,moonZ+.30);
  for(let j=0;j<30;j++){
    const a=j*Math.PI*2/30+.012,b=(j+1)*Math.PI*2/30-.012;
    const p=(q,r)=>new THREE.Vector2(Math.cos(q)*r,Math.sin(q)*r+c);
    const ring=new THREE.ExtrudeGeometry(new THREE.Shape([p(a,moonR),p(a,moonR+.19),p(b,moonR+.19),p(b,moonR)]),
      {depth:.14,bevelEnabled:false});ring.translate(A,base,moonZ-.10);put(stone,ring);
  }
  label('梦溪园',1.94,.46,A,base+3.60,moonZ-.128);
  for(let k=0;k<5;k++){
    const tz=moonZ-2.7+k*.51, y=base+.10+k*.142;
    S(stone,3.94,.17,.52,A,y,tz);
    if(k%2===0)for(const s of [-1,1]){
      S(stone,.16,.88,.17,A+s*1.82,y+.43,tz);
      S(stone,.24,.13,.19,A+s*1.82,y+.87,tz);
    }
    for(const s of [-1,1]){
      put(stone,box(.13,.16,.56).rotateX(-.24).translate(A+s*1.82,y+.75,tz));
    }
  }
  for(const side of [-1,1]){
    S(gray,.34,2.71,18.0,A+side*9.06,base+1.35,20.6);
    S(M.mxTile,.55,.17,18.3,A+side*9.06,base+2.73,20.6);
    S(earth,4.2,.12,9.6,A+side*5.67,base+.04,20.37);
  }
  // Memorial front: dark wooden long panels, a simple grey lower apron and
  // a recessed gallery. Exhibits are modest stylised panels, not photographs.
  const hz=27.9;
  S(gray,13.8,.56,6.92,A,base+.26,hz);
  S(plaster,13.62,3.23,.32,A,base+1.75,hz+3.2);
  for(const side of [-1,1]){
    S(plaster,.30,3.38,6.70,A+side*6.82,base+1.71,hz);
    for(let i=0;i<24;i++){
      const x=A+side*(1.80+i*.195);
      S(wood,.043,2.67,.08,x,base+1.9,hz-3.39);
    }
    S(glass,4.76,2.36,.04,A+side*4.11,base+1.91,hz-3.30);
    S(wood,.22,3.4,.23,A+side*1.5,base+1.94,hz-3.67);
    S(wood,.24,3.34,.24,A+side*6.68,base+1.92,hz-3.62);
    S(wood,4.92,.26,.23,A+side*4.12,base+3.03,hz-3.43);
    for(const y of [.92,1.48,2.46])S(wood,4.82,.075,.092,A+side*4.10,base+y,hz-3.43);
  }
  roof(14.3,7.32,1.18,A,base+3.79,hz);
  label('沈括纪念室',3.27,.62,A,base+3.29,hz-3.72);
  for(let i=0;i<5;i++){
    const x=A+(i-2)*2.12;
    S(wood,1.67,2.16,.15,x,base+1.67,hz+2.79);
    S(paving,1.43,1.93,.042,x,base+1.70,hz+2.694);
    for(let line=0;line<6;line++)S(darker,1.07-line*.048,.025,.033,x,base+2.13-line*.145,hz+2.667);
  }
  const display=new THREE.Group();display.name='interpretive display only';group.add(display);
  S(wood,2.19,.77,.74,A+4,base+.74,28.52);
  S(glass,2.24,.26,.80,A+4,base+1.24,28.52);
  const border=new THREE.Group();border.name='no exterior water or replica Song park';group.add(border);
  function shrubs(x,z,cap=1){
    for(let i=0;i<16;i++){
      const a=i*2.39996,r=(.19+((i*.618)%1)*.61)*cap;
      put(foliage,new THREE.IcosahedronGeometry(.126+((i*.72)%1)*.22,1)
             .scale(1.2,.62,.97).translate(x+r*Math.cos(a),base+.37+((i*.337)%1)*.54*cap,z+r*Math.sin(a)));
    }
  }
  for(const [xx,zz,r] of [[A-3.2,4.7,1.2],[A+3.3,4.7,1.2],[A-6.3,19,1.2],[A+5.9,20.5,1.3],
    [A-1.8,21.8,.74],[A-6,24,1.12],[A+6.4,23.1,.92]])shrubs(xx,zz,r);
  for(const [x,y,z,v] of [[-47,5.8,-1.4,73],[-29,5.4,2.1,48],[A-4,5.1,2.6,57],[A+4,4.6,2.3,46],
    [A-.3,4.7,11.5,26],[A+3.7,5.5,24.3,58],[A+.6,4.2,27.6,29]])lamp(x,y,z,v);
  flush();scene.add(group);
  const streetFinish={enabled:true,set(v){
    streetFinish.last=v;
    asphalt.roughness=1-Math.min(v,1.5)*.040;
    paving.roughness=.99-Math.min(v,1.5)*.065;
    asphalt.metalness=Math.min(v,1.5)*.016;
  }};
  const lamps=[{pos:[A-5.5,4.9,5.42],kind:'alley',big:false},{pos:[A+4.8,4.8,24.12],kind:'yard',big:false}];
  return {group,anchors:{lamps,paths:[]},streetFinish,setLights(v){for(const [l,amount] of fills)l.intensity=amount*Math.min(v,1.5);}, fills};
}
