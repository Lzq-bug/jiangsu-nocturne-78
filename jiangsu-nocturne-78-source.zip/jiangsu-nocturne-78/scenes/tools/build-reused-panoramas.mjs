/** Build the checked-in standalone panoramas newly attached to matching cards. */
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { readFileSync, writeFileSync } from 'node:fs';

export const reusedScenes = {
  'minor-cups-1': { path: '/pano/njbridge.html', label: '3D 建模 · 天堑飞虹', source: 'scenes/njbridge/index.html' },
  'minor-cups-3': { path: '/pano/tongli.html', label: '3D 建模 · 川字河灯', source: 'scenes/tongli/index.html' },
  'minor-swords-6': { path: '/pano/beigu.html', label: '3D 建模 · 满眼风光', source: 'scenes/beigu/index.html' },
  'minor-swords-7': { path: '/pano/maoshan.html', label: '3D 建模 · 上清灯山', source: 'scenes/maoshan/index.html' },
  'minor-swords-8': { path: '/pano/wenbi.html', label: '3D 建模 · 红梅夕照', source: 'scenes/wenbi/index.html' },
  'minor-swords-9': { path: '/pano/langshan.html', label: '3D 建模 · 江海第一山', source: 'scenes/langshan/index.html' },
  'minor-swords-10': { path: '/pano/yunlong.html', label: '3D 建模 · 冈岭四合', source: 'scenes/yunlong/index.html' },
  'minor-swords-11': { path: '/pano/huaguo.html', label: '3D 建模 · 山海一夜', source: 'scenes/huaguo/index.html' },
};

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const build = fileURLToPath(new URL('./build-single.mjs', import.meta.url));
  for (const { path, source } of Object.values(reusedScenes)) {
    const input = source.slice('scenes/'.length);
    execFileSync(process.execPath, [build, input, input.replace(/index\.html$/, 'src/main.js'), '../public' + path], { stdio: 'inherit' });
    // Normalize only the upstream vendor indentation and blank whitespace lines.
    const out = fileURLToPath(new URL('../../public' + path, import.meta.url));
    const html = readFileSync(out, 'utf8').replace(/^[ \t]+(?=material = getMaterial\( data\.material \);$)/gm, '\t\t\t\t')
      .replace(/^[ \t]+$/gm, '');
    writeFileSync(out, html);
  }
}
