// Rebuild the authored Qingming Bridge bundle; apply package calibration and regenerate narration.
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const root = fileURLToPath(new URL('../../', import.meta.url));
const qingming = resolve(root,'scenes/qingming');
const output = resolve(root,'public/pano/qingmingqiao.html');
const build = resolve(qingming,'tools/build-single.mjs');
execFileSync(process.execPath,[build,'index.html','src/main.js',output],{cwd:qingming,stdio:'inherit'});
const normalized=readFileSync(output,'utf8')
  .replace(/^[ \t]+(?=material = getMaterial\( data\.material \);$)/gm,'\t\t\t\t')
  .replace(/^[ \t]+$/gm,'');
writeFileSync(output,normalized);
for(const name of ['guard-native-panorama-mode.mjs','refine-native-panorama-look.mjs','build-guide-catalog.mjs']){
  execFileSync(process.execPath,[resolve(root,'scenes/tools',name)],{cwd:root,stdio:'inherit'});
}
