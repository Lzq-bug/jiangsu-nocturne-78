import fs from 'node:fs';
import { resolve } from 'node:path';
import ts from 'typescript';

const root=resolve(import.meta.dirname,'../..');
const read=p=>fs.readFileSync(resolve(root,p),'utf8');
const parse=(code)=>ts.createSourceFile('source.ts',code,ts.ScriptTarget.Latest,true);
const first=(n,p)=>{if(p(n))return n;return n.forEachChild(c=>first(c,p));};
const prop=(n,k)=>n?.properties?.find(x=>x.name?.text===k)?.initializer;
const value=n=>n&&ts.isStringLiteralLike(n)?n.text:undefined;
const clip=(s,n=600)=>s.replace(/\s+/g,' ').trim().slice(0,n);
const dir='src/ui/guides/';
const rows=JSON.parse(read(dir+'station-index.json'));
const stories=JSON.parse(read(dir+'stories.json'));
const draft=Object.assign({},...['major','water','lamps'].map(n=>JSON.parse(read(dir+n+'.json'))));
const catalog={};
const codes=['Major','Water','Lamps'].map(n=>parse(read('src/ui/deckScenes'+n+'.ts')));
const authoredStops=parse(read('src/ui/refinedCanalStops.ts'));
const extras=JSON.parse(authoredStops.text.match(/export const EXTRA_BRIDGE_STOPS:[^=]*= ([\s\S]*?);\s*$/)?.[1]??'{}');
const spotsMajor=parse(read('src/spots/majorSpots.ts'));
const spotsMinor=parse(read('src/spots/minorSpots.ts'));
const takeInit=(node,key)=>first(node,n=>ts.isVariableDeclaration(n)&&n.name.getText()===key)?.initializer;
const unwrap=node=>{
 while(node && (ts.isAsExpression(node)||ts.isSatisfiesExpression(node)||ts.isParenthesizedExpression(node)))node=node.expression;
 return node;
};
const maj=unwrap(takeInit(spotsMajor,'MAJOR_SPOTS'))?.elements??[];
const min=unwrap(takeInit(spotsMinor,'MINOR_SPOTS'));
const city=id=>{
 const [,kind,n]=id.split('-');
 const v=id.startsWith('major-')?maj.find(s=>Number(prop(s,'slot')?.getText())===Number(kind)):unwrap(prop(min,kind))?.elements?.[Number(n)-1];
 return value(prop(v,'city'))??'江苏';
};
function nativeStops(file,keys) {
 const text=read('public'+file);
 const group=text.split(/(?=^__def\()/m).filter(s=>/\b(?:const|let) STATIONS\s*=/.test(s));
 const lists=group.map(block=>{
  const start=block.indexOf('{'); const code=block.slice(start+1);
  const arr=unwrap(takeInit(parse(code),'STATIONS'));
  return (arr?.elements??[]).flatMap(n=>{
   // Zhonghua uses a statically authored station(...) helper with positional metadata.
   if(file==='/pano/zhonghua.html'&&ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='station'){
    const [id,label,lead,body]=[0,1,7,8].map(i=>value(n.arguments[i]));
    if(id&&label&&lead&&body)return [{id,label,text:clip(lead+body)}];
   }
   const id=value(prop(n,'id'));
   if(!id)return [];
   const label=value(prop(n,'name'))??value(prop(n,'title'))??value(prop(n,'short'))??id;
   const parts=['lead','body','desc','description','text','story'].map(k=>value(prop(n,k))).filter(Boolean);
   return [{id,label,text:clip([...new Set(parts)].join(''))}];
  });
 });
 const best=lists.sort((a,b)=>b.filter(x=>keys.includes(x.id)).length-a.filter(x=>keys.includes(x.id)).length)[0]??[];
 return keys.map(id=>best.find(s=>s.id===id)??{id,label:id,text:''});
}
function cue(label){
 if(/月|倒影|水影|灯影|水面/.test(label))return '先看光源在岸上的位置，再把视线压向水面，比较倒影在哪里被波纹断开。';
 if(/码头|临水|岸|河埠|舟|船|港/.test(label))return '把视线沿水线移到岸边，留意水线、贴水设施和岸上建筑之间的高度差。';
 if(/石塔|宝塔|塔|叠檐|层檐/.test(label))return '由塔身下部向上看，比较明暗交界处的轮廓和各层檐口的位置。';
 if(/门|入口|关|轴线|牌坊/.test(label))return '从入口朝内看，留意门框怎样同时留住前景，并把视线引到深处。';
 if(/古街|巷|市|坊|街/.test(label))return '顺着两侧立面向远处看，留意檐下的灯和转弯处的开口如何改变街巷的进深。';
 if(/山|坡|岩|高|远|俯|空中/.test(label))return '以远处天际线为参照，比较近处坡面、树冠与建筑的高低关系。';
 if(/院|园|廊|亭|窗|梅|花/.test(label))return '先看近处边框，再看它给远景留出的缺口；移动视角时，两者的重合会随之变化。';
 return '先看机位正面的轮廓，再向一侧拖动，把近处构件与远处的地标分开观察。';
}
const contextual=(label,detail)=>clip(label+'。'+(detail?'此处可看'+detail.replace(/[。；]$/,'')+'。':'')+cue(label));
for(const row of rows){
 if(!draft[row.id] || catalog[row.id])throw Error('missing or duplicate '+row.id);
 const authored=draft[row.id];
 if(authored.intro.length<85 || !authored.avatar?.name || !/^#[\da-f]{6}$/i.test(authored.avatar.accent??''))throw Error('invalid guide '+row.id);
 const profile=codes.map(n=>first(n,x=>ts.isPropertyAssignment(x)&&x.name?.text===row.id)?.initializer).find(Boolean);
 const details=prop(profile,'details')?.elements?.map(value)??[];
 const reference=value(prop(profile,'reference'));
 const scenicStops=prop(unwrap(takeInit(authoredStops,'REFINED_CANAL_STOPS')),row.id)?.elements;
 if(scenicStops && scenicStops.length!==row.stops.length)throw Error('authored stop count mismatch '+row.id);
 const stops=row.mode==='native'?nativeStops(row.embed,row.stops).map(s=>s.text.length>=38?s:{...s,text:s.text+cue(s.label)}):row.stops.map((label,i)=>({id:'view-'+(i+1),label,text:value(prop(scenicStops?.[i],'description'))??extras[row.id]?.[i]?.description??contextual(label,details[i%details.length])}));
 const story=stories[row.id];
 if(!story?.title||!story?.text||!story?.source?.url)throw Error('missing scene story '+row.id);
 catalog[row.id]={title:row.title,city:city(row.id),...authored,...(reference?{reference}:{}),stops,story};
}
if(Object.keys(stories).length!==78||rows.length!==78||new Set(Object.values(catalog).map(g=>g.avatar.name)).size!==78)throw Error('guide roster must contain 78 distinct guides');
const output=JSON.stringify(catalog,null,2)+'\n';
const dest=resolve(root,'public/guides.json');
if(process.argv.includes('--check')){if(!fs.existsSync(dest)||fs.readFileSync(dest,'utf8')!==output)throw Error('guides.json is not current');}
else fs.writeFileSync(dest,output);
const all=Object.values(catalog).flatMap(g=>g.stops);
console.log(JSON.stringify({scenes:rows.length,stations:all.length,stationsWithCopy:all.filter(s=>s.text).length,cities:[...new Set(Object.values(catalog).map(g=>g.city))]}));
