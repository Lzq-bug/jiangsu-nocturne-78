/**
 * Repair the native HUD ↔ camera view-mode callback loop in the bundled scenes.
 * Use after building standalone panoramas; 35 affected scenes get dual-mode
 * setter semantics, two bundles already prevent recursion and remain unchanged.
 * Usage: node scenes/tools/guard-native-panorama-mode.mjs [public/pano] [--check]
 */
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';

const check = process.argv.includes('--check');
const dir = resolve(process.argv.slice(2).find(arg => arg !== '--check') ?? 'public/pano');
const preGuarded = new Set(['dongguan.html', 'nantong.html']);
const marker = '/* native-mode-reentry-guard:v1 */ ';
const nativeSetter = /^  function setMode\(m(?:, notify = true)?\) \{.*?^  \}/gms;
const cameraSetter = /^function setMode\(m\) \{.*?^\}/gms;

function locate(source, regex, description, file) {
  const results = [...source.matchAll(regex)];
  if (results.length !== 1) throw new Error(`${file}: expected one ${description}, found ${results.length}`);
  return results[0][0];
}
function guard(before, name) {
  const ui = locate(before, nativeSetter, 'native mode UI setter', name);
  const camera = locate(before, cameraSetter, 'native camera mode setter', name);
  if (preGuarded.has(name)) {
    const builtInGuard = name === 'dongguan.html'
      ? camera.includes('if (from !== m) ui.setMode(m);')
      : !ui.includes('onMode(m);') && before.includes('function click(m) {\n    setMode(m);\n    onMode(m);');
    if (!builtInGuard) throw new Error(`${name}: expected original non-recursive mode handler`);
    return { name, before, after: before, existing: true };
  }

  const rawUI = ui
    .replace('function setMode(m, notify = true)', 'function setMode(m)')
    .replace(`${marker}if (notify) onMode(m);`, 'onMode(m);');
  const rawCamera = camera.replace(`${marker}ui.setMode(m, false);`, 'ui.setMode(m);');
  if ((rawUI.match(/onMode\(m\);/g) ?? []).length !== 1
      || (rawCamera.match(/ui\.setMode\(m\);/g) ?? []).length !== 1) {
    throw new Error(`${name}: unexpected native mode handlers`);
  }
  const readyUI = rawUI.replace('function setMode(m)', 'function setMode(m, notify = true)')
    .replace('onMode(m);', `${marker}if (notify) onMode(m);`);
  const readyCamera = rawCamera.replace('ui.setMode(m);', `${marker}ui.setMode(m, false);`);
  return { name, before, after: before.replace(ui, readyUI).replace(camera, readyCamera), existing: false };
}

try {
  const names = readdirSync(dir).filter(name => name.endsWith('.html')).sort();
  if (names.length !== 37) throw new Error(`${dir}: expected 37 independent native panoramas, found ${names.length}`);
  const results = names.map(name => guard(readFileSync(join(dir, name), 'utf8'), name));
  const changed = results.filter(p => p.before !== p.after);
  const alreadyProtected = results.filter(p => p.existing).map(p => p.name);
  if (alreadyProtected.length !== 2) throw new Error('expected two pre-guarded native mode handlers');
  if (!check) for (const row of changed) writeFileSync(join(dir, row.name), row.after);
  console.log(JSON.stringify({ check, processed: results.length, alreadyProtected, changed: changed.map(row => row.name) }, null, 2));
  if (check && changed.length) process.exitCode = 1;
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
