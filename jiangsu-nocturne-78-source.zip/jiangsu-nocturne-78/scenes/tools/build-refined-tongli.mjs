// Regenerate the embedded Tongli panorama and its guide narration from source.
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const root = fileURLToPath(new URL('../../', import.meta.url));
const scenes = resolve(root, 'scenes');
const build = resolve(scenes, 'tools', 'build-single.mjs');
execFileSync(process.execPath, [build, 'tongli/index.html', 'tongli/src/main.js',
  '../public/pano/tongli.html'], { cwd: scenes, stdio: 'inherit' });

const output = resolve(root, 'public/pano/tongli.html');
const normalized = readFileSync(output, 'utf8')
  .replace(/^[ \t]+(?=material = getMaterial\( data\.material \);$)/gm, '\t\t\t\t')
  .replace(/^[ \t]+$/gm, '');
writeFileSync(output, normalized);
for (const name of ['refine-native-panorama-look.mjs', 'guard-native-panorama-mode.mjs', 'build-guide-catalog.mjs']) {
  execFileSync(process.execPath, [resolve(scenes, 'tools', name)], { cwd: root, stdio: 'inherit' });
}
