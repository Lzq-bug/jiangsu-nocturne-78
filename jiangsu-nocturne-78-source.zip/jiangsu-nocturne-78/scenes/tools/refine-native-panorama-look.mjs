/**
 * Apply the native-night look to a full directory of 37 standalone scene HTMLs.
 * No DOM filters or image downloads. Run after the scene builds, before Vite
 * packaging, or on an already built offline package's dist/pano. Originals
 * remain embedded in the labeled calibration comments for repeatable updates.
 * Usage: node scenes/tools/refine-native-panorama-look.mjs [public/pano]
 *        node scenes/tools/refine-native-panorama-look.mjs [public/pano] --check
 */
import { readFileSync, writeFileSync, renameSync, rmSync } from 'node:fs';
import { resolve, join } from 'node:path';

const look = {
  // exposure: multiplier; bloomFloor: added linear HDR threshold; haze: native fog-density multiplier
  canal: { exposure: 0.98, bloomFloor: 0.14, haze: 0.95 },
  garden: { exposure: 1.07, bloomFloor: 0.13, haze: 0.98 },
  shore: { exposure: 1.02, bloomFloor: 0.16, haze: 1.06 },
  ridge: { exposure: 1.04, bloomFloor: 0.12, haze: 1.10 },
  masonry: { exposure: 1.05, bloomFloor: 0.16, haze: 0.94 },
  urban: { exposure: 0.96, bloomFloor: 0.19, haze: 0.98 },
};

const districts = {
  canal: ['anfeng', 'biji', 'dongguan', 'fuzimiao', 'hanshan', 'nantong', 'panmen', 'pingjianglu', 'qingmingqiao', 'tongli'],
  garden: ['canglang', 'erfenmingyue', 'geyuan', 'huishan', 'mengxi', 'wangshiyuan', 'wenbi', 'zhuozheng'],
  shore: ['liandao', 'shouxihu', 'taihu'],
  ridge: ['beigu', 'huaguo', 'jinshan', 'langshan', 'maoshan', 'santai', 'yunlong'],
  masonry: ['baoen', 'chaotian', 'haichun', 'taicheng', 'zhenhuailou', 'zhonghua'],
  urban: ['jinjihu', 'njbridge', 'xiaolou'],
};

const tweaks = {
  fuzimiao: { exposure: 1.01, bloomFloor: 0.10, haze: 0.97 },
  shouxihu: { exposure: 1.04, bloomFloor: 0.15, haze: 1.02 },
  geyuan: { haze: 1.00 }, // preserve the season switches' native fog values
  huaguo: { exposure: 0.99, haze: 1.00 }, // already runs an intentionally lifted mountain night
  panmen: { bloomFloor: 0.10 }, // its native threshold is already high
  njbridge: { exposure: 1.01, haze: 1.04 }, // retain legibility of the double-decker truss
  wenbi: { exposure: 1.08 }, // slightly more legible pond and stone detail
};
const directory = resolve(process.argv.slice(2).find(arg => arg !== '--check') ?? 'public/pano');
const check = process.argv.includes('--check');
const marker = '/* native-night-look:v1 */ ';

function patchOnce(entry, expression, replacer, descriptor, file) {
  const matches = [...entry.matchAll(expression)];
  if (matches.length !== 1) throw new Error(`${file}: expected one ${descriptor}, found ${matches.length}`);
  return entry.replace(expression, replacer);
}

function calibrate(html, settings, file) {
  const mainMatches = [...html.matchAll(/^    __req\(("[^"\n]+")\);/gm)];
  if (mainMatches.length !== 1) throw new Error(`${file}: standalone entry marker missing or duplicated`);
  const main = mainMatches[0];
  const start = html.indexOf(`__def(${main[1]}, function (__req) {`);
  if (start < 0 || start > main.index) throw new Error(`${file}: can't isolate standalone entry module`);
  let entry = html.slice(start, main.index);
  // Unwrap previous passes without modifying arbitrary copied scene code.
  entry = entry.replaceAll(/\/\* native-night-look:v1 \*\/ \(([^()\n]*)\) [*+] [\d.]+/g, '$1');
  const tweak = (value, op, amount) => `${marker}(${value}) ${op} ${amount.toFixed(2)}`;
  entry = patchOnce(entry, /^(renderer\.toneMappingExposure\s*=\s*)([\d.]+|[A-Z][\w]*\.[\w]+);/gm,
    (_, pre, value) => `${pre}${tweak(value, '*', settings.exposure)};`, 'renderer exposure hook', file);
  entry = patchOnce(entry, /^((?:const|let) bloom = new UnrealBloomPass\(new THREE\.Vector2\([^\n]+?\),[^,\n]+,[^,\n]+,\s*)([\d.]+|[A-Z][\w]*\.[\w]+)(\);)/gm,
    (_, pre, value, post) => `${pre}${tweak(value, '+', settings.bloomFloor)}${post}`, 'bloom threshold hook', file);
  if (settings.haze !== 1) {
    // Match only the static native fog constructor; never touch dynamic fog toggles or shaders.
    const fog = /(\bscene\.fog\s*=\s*new THREE\.FogExp2\([^\n;]+?,\s*)([\d.]+|[A-Z][\w]*(?:\.[\w]+)?)(\);)/g;
    const matches = [...entry.matchAll(fog)];
    if (matches.length > 1) throw new Error(`${file}: multiple static fog hooks; inspect scene before calibration`);
    if (matches.length === 1) entry = entry.replace(fog, (_, pre, value, post) => `${pre}${tweak(value, '*', settings.haze)}${post}`);
  }
  const patched = html.slice(0, start) + entry + html.slice(main.index);
  return patched;
}

try {
  const plans = [];
  for (const [district, names] of Object.entries(districts)) {
    for (const name of names) {
      const file = join(directory, name + '.html');
      const before = readFileSync(file, 'utf8');
      const after = calibrate(before, { ...look[district], ...tweaks[name] }, file);
      plans.push({ name, district, file, after, changed: before !== after });
    }
  }
  if (plans.length !== 37 || new Set(plans.map(p => p.name)).size !== 37) throw new Error('expected 37 unique native scenes');
  if (!check) {
    for (const plan of plans.filter(p => p.changed)) {
      const temporary = `${plan.file}.night-look-${process.pid}.tmp`;
      try {
        writeFileSync(temporary, plan.after, { flag: 'wx' });
        renameSync(temporary, plan.file);
      } finally {
        rmSync(temporary, { force: true });
      }
    }
  }
  const changed = plans.filter(p => p.changed).map(p => p.name);
  console.log(JSON.stringify({ planned: plans.length, mode: check ? 'check' : 'calibrate', changed }, null, 2));
  if (check && changed.length) process.exitCode = 1;
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
