/**
 * Read-only parity check against the initial release snapshot.
 * Usage: node scenes/tools/audit-original-panoramas.mjs [baseline-commit]
 * Separately reports the added panorama files without treating them as originals.
 */
import { execFileSync } from 'node:child_process';
import { lstatSync, readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { reusedScenes } from './build-reused-panoramas.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const folder = 'public/pano';
const baseline = process.argv[2] ?? '97aa219be87f3876fee47aa30044b9c4dae10dd3';
const expectedOriginalCount = 29;
const expectedNewCount = 8;
const git = (...args) => execFileSync('git', args, { cwd: root, maxBuffer: 16 * 1024 * 1024 });

try {
  const ref = git('rev-parse', '--verify', '--end-of-options', baseline + '^{commit}').toString().trim();
  const originals = git('ls-tree', '-rz', '--name-only', ref, '--', folder)
    .toString().split('\0').filter(name => name.endsWith('.html')).sort();
  const local = readdirSync(path.join(root, folder), { withFileTypes: true })
    .filter(e => !e.isDirectory() && e.name.endsWith('.html'))
    .map(e => folder + '/' + e.name).sort();
  const equal = [];
  const missing = [];
  const different = [];

  for (const name of originals) {
    const file = path.join(root, name);
    if (!local.includes(name)) { missing.push(name); continue; }
    if (!lstatSync(file).isFile() || !readFileSync(file).equals(git('cat-file', 'blob', ref + ':' + name))) {
      different.push(name);
    } else {
      equal.push(name);
    }
  }

  const additionExpected = Object.values(reusedScenes).map(e => 'public' + e.path).sort();
  const added = local.filter(name => !originals.includes(name));
  const additionMissing = additionExpected.filter(name => !added.includes(name));
  const unexpected = added.filter(name => !additionExpected.includes(name));
  const irregular = added.filter(name => !lstatSync(path.join(root, name)).isFile());
  const overlap = additionExpected.filter(name => originals.includes(name));
  const pass = originals.length === expectedOriginalCount && equal.length === expectedOriginalCount
    && added.length === expectedNewCount && additionExpected.length === expectedNewCount
    && !missing.length && !different.length && !additionMissing.length && !unexpected.length && !irregular.length && !overlap.length;

  console.log(JSON.stringify({
    pass, baseline: ref,
    originalCount: originals.length, originalByteIdenticalCount: equal.length,
    originals: equal, missingOriginals: missing, differentOriginals: different,
    newCount: added.length, newPanoramas: added, missingNewPanoramas: additionMissing,
    unexpectedNewPanoramas: unexpected, nonFileNewPanoramas: irregular, overlappingPanoramas: overlap,
  }, null, 2));
  if (!pass) process.exitCode = 1;
} catch (error) {
  console.error('Cannot audit panorama bytes against the release baseline:', error.message);
  process.exitCode = 1;
}
