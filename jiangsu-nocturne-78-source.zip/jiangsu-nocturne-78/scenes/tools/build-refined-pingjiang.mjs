import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'../..');
const scripts=resolve(root,'scenes/tools');
const output=resolve(root,'public/pano/pingjianglu.html');
execFileSync(process.execPath,[resolve(scripts,'build-single.mjs'),'pingjiang.html','src/pj/main.js','../public/pano/pingjianglu.html'],{cwd:resolve(root,'scenes'),stdio:'inherit'});
const html=readFileSync(output,'utf8').replace(/^[ \t]+(?=material = getMaterial\( data\.material \);$)/gm,'\t\t\t\t').replace(/^[ \t]+$/gm,'');
writeFileSync(output,html);
for(const file of ['refine-native-panorama-look.mjs','guard-native-panorama-mode.mjs','build-guide-catalog.mjs']){
  const executable=resolve(scripts,file);
  execFileSync(process.execPath,[executable],{cwd:root,stdio:'inherit'});
}
