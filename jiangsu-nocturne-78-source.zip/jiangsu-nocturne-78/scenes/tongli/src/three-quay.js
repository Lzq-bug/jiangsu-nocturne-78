import * as THREE from 'three';
import { meterBox as box, mesh, mergeAll, lit, glow } from './kit.js';
import { BANK } from './data.js';

export function buildThreeQuay() {
  const group=new THREE.Group();group.name='three-quay-detail';
  const ashlar=[],caps=[],plaster=[],tile=[],wood=[],cloth=[],warm=[];
  const rails=(a,b)=>{
    const [x,z]=a,dx=b[0]-x,dz=b[1]-z,L=Math.hypot(dx,dz),N=Math.max(2,Math.round(L/1.35)),angle=Math.atan2(-dz,dx);
    for(let i=0;i<=N;i++){
      const cx=x+dx*i/N,cz=z+dz*i/N;
      caps.push(box(.24,.75,.25,cx,BANK,cz),box(.29,.10,.28,cx,BANK+.64,cz));
      if(i<N){
        const cap=new THREE.BoxGeometry(L/N+.01,.147,.18);
        cap.rotateY(angle);cap.translate(cx+dx/(2*N),BANK+.49,cz+dz/(2*N));caps.push(cap);
      }
    }
  };
  rails([-20,18.12],[-14.3,18.12]);rails([-11.8,18.12],[-7.4,18.12]);
  rails([4.1,24.4],[8.6,23]);rails([15.2,22.68],[21,23.42]);
  rails([-2.58,39],[-2.62,44]);rails([2.57,39],[2.72,44]);
  // Stepped landing cut toward the wider corner instead of filling the narrow passage.
  for(let i=0;i<6;i++)ashlar.push(box(1.50-.025*i,.35,.42,20.34,BANK-.09-i*.33,24.52-i*.37));
  for(const [x0,z0,len] of [[-20,18.3,11],[9,22.5,9],[-7,18.0,9]]){
    for(let j=0;j<5;j++) for(let k=0;k<Math.ceil(len/1.12);k++){
      const x=x0+k*1.12+(j%2)*.41;
      if(x>x0+len)continue;
      ashlar.push(box(.94+(k%3)*.055,.30+(j%2)*.03,.125,x,BANK-.25-(j+1)*.34,z0+(z0<20?.045:-.045)));
    }
  }
  for(const side of [-1,1])for(let j=0;j<5;j++)for(let k=0;k<21;k++){
    const z=26+k*.91+(j%2)*.39;if(z>44.2)continue;
    ashlar.push(box(.12,.30+(j%2)*.032,.78+(k%3)*.045,side*2.22,BANK-.46-j*.36,z));
  }
  for(const [x,z,s] of [[-3,7,1],[10,7.8,1],[11,31,-1]]){
    plaster.push(box(6.7,2.58,3.8,x,BANK,z));
    ashlar.push(box(6.84,.37,3.88,x,BANK,z));
    const front=z+s*1.96;
    for(const k of [-1,0,1]){
      warm.push(box(1.15,1.38,.055,x+k*1.79,BANK+.69,front));
      for(const d of [-.63,-.28,.29,.63]) wood.push(box(.058,1.58,.065,x+k*1.79+d,BANK+.55,front+s*.047));
      wood.push(box(1.29,.067,.082,x+k*1.79,BANK+1.32,front+s*.049));
    }
    for(const side of [-1,1]){
      const roof=new THREE.BoxGeometry(7.0,.14,2.33);
      roof.rotateX(side*.37);roof.translate(x,BANK+2.92,z+side);tile.push(roof);
    }
    tile.push(box(7.08,.15,.16,x,BANK+3.31,z));
    const canvas=new THREE.BoxGeometry(6.85,.08,1.42);
    canvas.rotateX(s*.27);canvas.translate(x,BANK+2.21,front+s*.7);cloth.push(canvas);
    cloth.push(box(6.91,.18,.07,x,BANK+1.92,front+s*1.36));
    for(const side of [-1,1]) wood.push(box(.085,2.07,.085,x+side*3.16,BANK,front+s*1.27));
  }
  const branch=[];
  const limb=(a,b,d)=>{const v=new THREE.Vector3(...a),w=new THREE.Vector3(...b),ax=w.clone().sub(v),g=new THREE.CylinderGeometry(d*.48,d,ax.length(),7);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),ax.normalize()));g.translate(...v.add(w).multiplyScalar(.5).toArray());branch.push(g);};
  limb([-4.4,BANK,28.8],[-2.8,5.45,26.9],.25);limb([-2.8,5.45,26.9],[.4,7.1,26.3],.15);
  limb([-2.8,5.45,26.9],[-4.7,7.08,22.9],.14);limb([.4,7.1,26.3],[2.2,8.05,27.4],.105);
  const greens=[];
  for(let i=0;i<57;i++){
    const a=i*2.3996,r=.29+(i%11)*.208;
    const g=new THREE.IcosahedronGeometry(.29+(i%5)*.073,1);
    g.scale(1.45,.78,1.19);
    g.rotateY(a*.73);g.translate(-1.18+Math.cos(a)*r,7.46+Math.sin(a*.43)*.61,26.0+Math.sin(a)*r);greens.push(g);
  }
  const add=(parts,mat)=>{const m=mesh(mergeAll(parts),mat);m.receiveShadow=true;group.add(m);};
  add(ashlar,lit('#706f62',{rough:.92}));add(caps,lit('#8a887a',{rough:.89}));add(plaster,lit('#aaaca1',{rough:.94}));
  add(tile,lit('#34383c',{rough:.92}));add(wood,lit('#463126',{rough:.92}));add(cloth,lit('#435a4d',{rough:.94}));add(warm,glow('#bb713f',.8));
  add(branch,lit('#352d25',{rough:1}));add(greens,lit('#28382c',{rough:1}));
  return group;
}
