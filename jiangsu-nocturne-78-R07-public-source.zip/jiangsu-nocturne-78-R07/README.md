# 夜泊江苏 R07｜公开可编辑源码

本版保留 78 处可游览的 3D 场景、553 个导览点、78 则故事和 16 张具有明确再分发许可的实拍封面，其他卡面为数字绘景。三维场景是数字重建，不宣称全部通过实地测绘。周庄双桥保留交互式 3D 夜游；旧照片导览与未核实授权的旧照片不纳入公开包。

摄影署名、来源、许可链接及改动见 [夜拍封面与署名](docs/night-cover-register.md)。照片许可证不适用于其余源码；本包不另行授予源码开源许可证。

<div align="center">

# 夜泊江苏 · Jiangsu Nocturne

**装在浏览器里的江苏夜色收藏册。**
在观星台收集星屑，举行启封仪式，把 78 帧水韵江苏的夜色收进你的「夜泊阁」，
再走进 360° 全景，云夜游这方「月落乌啼霜满天」的土地。

**78 帧江苏夜景 · 3D 视差卡牌 · 78 个卡牌夜景：37 个独立全景 + 41 个地标写意场景 · 360° 全景夜游 · Local-first · React + TypeScript + Three.js + Vite**

</div>

---

## 项目简介

《夜泊江苏》是一款以 **江苏景点夜景 + VR 效果卡牌 + 收集玩法** 为核心的 Web 小游戏。

核心循环很简单：

**观星台捕星 → 获得星屑 → 启封一帧夜色 → 新帧入阁 / 重复补偿 → 推进 78 帧收藏 → 全景夜游**

项目不要求注册账号、不依赖任何 API Key、不联网也能完整游玩；存档保存在浏览器本地。

## 特色

- **78 帧江苏夜景**：22 张「城章」收录全省最具代表性的夜景地标（夫子庙秦淮画舫、拙政园夜园、瘦西湖五亭桥、金鸡湖东方之门、寒山寺枫桥、云龙湖苏公塔影……），56 张「夜签」按 **灯影 / 水岸 / 山寺 / 城垣** 四大夜色系列铺开，覆盖江苏 13 个设区市。
- **程序化夜景引擎**：每帧卡面与全景画面由 `src/ui/nightScene.ts` 实时生成——夜空渐变、月相、星野、十六种剪影母题（画舫、瓮城、宝塔、拱桥、灯塔、大佛、天际线……）、水面光晕与倒影，全部原创算法，无任何外部素材。
- **实拍封面与数字绘景**：已收录 16 张可再分发夜拍。图片和登记表位于 `src/assets/photos/`，其余卡面使用数字绘景。
- **VR 效果 · 三层呈现**：
  - **真 3D 卡牌**：投影 / 光晕 / 卡面 / 眩光多层空间视差，桌面指针倾斜跟随、移动端陀螺仪倾斜设备即转动视线，光影随视角实时变化；详情页点按卡牌可 3D 翻面，背面是羊皮纸「夜航手记」；
  - **360° 全景夜游**：详情页与「夜泊画廊」基于 Three.js 实时 3D 建模——按景点母题生成建筑体块、地标构筑物、灯笼光晕、水面倒影与星空月色的微城场景，透视相机立于场景中心，拖动/陀螺仪环顾四周，可全屏、可自动环游；
  - **37 个可走入的独立 3D 场景**：重点卡牌直接嵌入完整的独立 Three.js 夜景场景（源码见 [`scenes/`](scenes/)）——保留各自的解说机位、热点导航、参数面板或专属互动，详见下文场景清单。
  - **41 个地标写意夜景**：其余卡牌使用按地标编排的实时 Three.js 场景，不再复用旧通用微城。每处至少三个可进入的分区，带独立近景布置、机位、说明和可复原的操作。图像参考只用于核对建筑轮廓，不随这些新场景打包。
- **夜泊画廊**：22 张城章免费开放预览与全景夜游，点开即游——演示零门槛。
- **原创异形卡牌体系**：城章采用「月芒尖碑」轮廓，四系列夜签各自拥有独立外形语言。
- **启封仪式**：消耗星屑，在 12 枚封缄中亲手选择并点亮一帧夜色；概率先于动画确定，诚实可信。
- **Local-first**：核心玩法、抽牌、收藏、存档、导入导出均可在本地完成，无任何在线依赖。
- **响应式与无障碍**：Desktop / Mobile 均适配，支持 `prefers-reduced-motion` 与系统「减少动态效果」自动降级。

## 快速开始

```bash
npm install        # 或 pnpm install
npm run dev        # 开发预览 http://localhost:5173
npm run build      # 产出纯静态 dist/，可部署到任意静态服务器
npm run test       # vitest 单元测试
```

运行环境：现代浏览器（Chrome / Edge / Firefox / Safari 最新版），Node.js 22 LTS（或较新 LTS）。无插件、无后端、无 API Key。

## 3D 场景源码（`scenes/`）

[`scenes/`](scenes/) 收录全部 30+ 座独立 3D 夜景场景的完整源码：每座场景都是一个零运行时依赖的 Three.js 程序化重建项目——建筑、水体、灯火、星空全部用基础几何体与原创着色实时生成，构建后是单个可直接离线打开的 HTML 文件。场景内含多解说机位、热点导航、参数面板与专属互动（敲钟、起灯、廿四番花信风、慈寿塔风铎、串场河推潮、四季月色换挡等）。

### 场景清单

**原版接入的 29 个场景**（保留原模型和机位，更新渲染参数与个别显示问题）：

| 场景 | 目录 / 入口 | 嵌入卡牌 |
|---|---|---|
| 夫子庙 · 秦淮画廊 | `scenes/`（根项目 `npm run build`） | major-0 |
| 平江路 · 灯河夜巷 | `scenes/`（`npm run build:pingjiang`） | major-3 |
| 瘦西湖 · 五亭桥月 | `scenes/src/sxh/`（`npm run build:sxh`） | major-6 |
| 金鸡湖 · 湖光门影 | `scenes/gate/`（`npm run build:gate`） | major-4 |
| 台城明城墙 · 湖山入城 | `scenes/src/tc/`（`npm run build:taicheng`） | minor-pentacles-1 |
| 寒山寺 · 枫桥夜泊 | `scenes/hanshan/` | major-5 |
| 中华门 · 瓮城灯阵 | `scenes/zhonghua/` | major-1 |
| 金山寺 · 江天灯火 | `scenes/jinshan/` | major-11 |
| 连岛 · 开渔夏夜 | `scenes/liandao/` | major-15 |
| 朝天宫 · 金陵文庙 | `scenes/zhonghua/chaotian-palace/` | minor-pentacles-3 |
| 沧浪亭 · 清风明月 | `scenes/canglang/` | minor-pentacles-5 |
| 二分明月楼 · 一园明月 | `scenes/mingyue/` | minor-pentacles-10 |
| 海春轩塔 · 一塔两朝 | `scenes/haichun/` | minor-swords-14 |
| 篦箕巷 · 运河灯巷 | `scenes/biji/` | minor-pentacles-7 |
| 大报恩寺 · 琉璃塔夜必灯 | `scenes/baoen/` | minor-swords-12 |
| 惠山古镇 · 二泉灯影 | `scenes/huishan/` | minor-pentacles-2 |
| 小娄巷 · 一巷明月 | `scenes/xiaolou/` | minor-pentacles-6 |
| 梦溪园巷 · 泉声灯影 | `scenes/mengxi/` | minor-pentacles-8 |
| 盘门三景 · 运河夜阑 | `scenes/panmen/` | minor-pentacles-4 |
| 清名桥 · 运河灯河 | `scenes/qingming/` | major-8 |
| 东关街 · 灯火长街 | `scenes/dongguan/` | major-7 |
| 个园 · 一园四季 | `scenes/geyuan/` | minor-pentacles-9 |
| 南通博物苑 · 濠河夜月 | `scenes/nantong/` | minor-pentacles-12 |
| 三台山 · 衲田花信 | `scenes/santai/` | minor-swords-13 |
| 拙政园 · 拙政问雅 | `scenes/zhuozheng/` | major-2 |
| 安丰古镇 · 串场河夜潮 | `scenes/anfeng/` | minor-pentacles-14 |
| 鼋头渚 · 太湖灯塔 | `scenes/taihu-lighthouse/` | major-9 |
| 网师园 · 夜花园 | `scenes/wangshi-yuan/` | minor-pentacles-11 |
| 镇淮楼 · 谯楼更鼓 | `scenes/zhenhuai-lou/` | minor-pentacles-13 |

**新增接入 8 个已有独立场景**：南京长江大桥、同里古镇、北固山、茅山、文笔塔、狼山、云龙山、花果山。可运行 `node scenes/tools/build-reused-panoramas.mjs` 重新构建对应的 `public/pano/` 文件。

**按卡牌建模的 41 个地标写意夜景** 位于 `src/ui/deckScenes*.ts`。参照夫子庙秦淮画廊的朱印、夜蓝金边、底部机位与讲解布局；每张卡有至少 3 个机位、场内指路热点及对应的可复原 3D 互动。支持拖动全景、地标环绕、热点开关、自动巡览、全屏及流畅优先。周庄默认进入实时 3D，也可选带标识的非实拍图像导览。

这些新增场景是第一轮可玩数字重建，不是实景测绘。原有 29 个独立全景保留原模型、机位和既有导览；本轮更新渲染表现。启封流程未改动。未接入的旧源码或姊妹场景不计入 37 个独立全景。

数字人版的原生场景按新版渲染配置检查（见末尾）。`audit-original-panoramas.mjs` 仅用于上一版未改动原生场景时的历史基线审计，不用于本版。

### 场景构建

每个子目录都是独立项目（含本地 `vendor/` Three.js，离线可构建）：

```bash
cd scenes/haichun
npm install        # 多数场景零依赖,可跳过
node tools/build-single.mjs 或按各项目 package.json 的 build 脚本
# 产出 dist/单个 HTML 文件,双击即可离线游览
```

根项目（夫子庙/平江路/瘦西湖/金鸡湖/台城五入口共用构建系统）：

```bash
cd scenes
npm run build        # 夫子庙
npm run build:sxh    # 瘦西湖
npm run build:gate   # 金鸡湖
# 全部入口:npm run build:all
```

## 仓库结构

```
├── src/                  # 主应用:页面/卡牌/收藏/启封/3D 全景引擎
│   ├── assets/photos/    # 16 张获准再分发的照片封面和登记表
│   └── ui/               # VrCard 真 3D 卡牌 / PanoView 全景 / nightScene 程序化夜景
├── public/pano/          # 嵌入主应用的场景单文件(构建产物)
├── scenes/               # 30+ 座独立 3D 场景完整源码(见上)
├── docs/                 # 参赛材料
```

## 技术栈

React 18 · TypeScript · Vite 6 · zustand · Three.js（78 个卡牌夜景）· CSS 3D（视差卡牌与全景圆柱投影）· Web Audio（程序化音效）· Vitest

## 许可

项目原创部分仅供学习与竞赛展示使用。随包分发的 Three.js 及其插件适用 [MIT 许可证](licenses/Three.js-MIT.txt)。摄影作品按 [各自许可](docs/night-cover-register.md) 分发。

## 场景数字人导游

卡牌解锁后或在免费夜泊画廊中，场景下方有可收起的数字人导游。78 个景点各有虚构角色、插画形象和较长的中文场景介绍；导游还可朗读当前机位，支持主动点击语音输入、识别后编辑、再提交文本。口型是播放状态动画，不是真人视频或精确唇形同步。语音输入是否可用及是否联网，由浏览器的语音服务决定；始终可用文字输入。朗读使用设备支持的中文语音。

```sh
npm ci
npm run build
npm run guide:serve
# http://127.0.0.1:8787 ，网页与 /api/guide 同源
```

本机可以从主厅顶部打开「设置 → 导游 API 设置」填写 Base URL、模型和密钥。请用 `node server/guide.mjs --local-settings` 启动本机编辑模式。应用后仅在服务进程内存中保留，重启即清除；浏览器和游戏存档不保存密钥。「测试连接」才会发送一条试问，可能计费。公网部署不要开启本机编辑：请用服务器环境变量。默认允许 OpenAI 和 DeepSeek 的 API 主机；其他官方供应商可按部署说明加入允许列表。

默认不配置付费服务。浏览、文字导览和系统朗读不依赖聊天模型。如需启用语音/文字问答的回答功能，只在服务端设置以下环境变量，不要把真实密钥写进前端、提交到仓库或发在聊天里：

- `GUIDE_API_BASE`：兼容 OpenAI Chat Completions 的 API 根地址，含版本段（比如 `https://api.openai.com/v1`）。
- `GUIDE_MODEL`：你的供应商支持的模型 ID。
- `GUIDE_API_KEY`：该供应商的服务端密钥。

详见 [导游接口部署说明](server/README.md)。当前景点和机位由后端从可信的 `guides.json` 查表，应答聚焦于景点和本场景，不替代现场实时信息。配置 API 后，提交的提问文本和近期对话会发送给所选模型服务；原始麦克风音频不由项目服务器处理。项目自带的旧「星语」功能是独立功能，导游不读取其客户端设置。

重新生成可信景点目录：`npm run guide:catalog`。37 个独立场景的渲染配置与模式保护可由 `node scenes/tools/refine-native-panorama-look.mjs` 和 `node scenes/tools/guard-native-panorama-mode.mjs` 复用，后接 `--check` 检查产物。视觉更新以环境、材质和倒影为主，仍为数字重建，不是实景拍摄或测绘。
