import * as THREE from 'three';
import { GEO } from './data.js';
import { M, PAL, mesh, box, lit } from './kit.js';
import { depthTexture, MAP_HALF } from './terrain.js';
import * as T from './textures.js';

/** 现灯塔：金山石贴面收分直棱塔、红褐色灯室与双重上翘檐。旋转扫光为写意。 */
const { x: LX, z: LZ, padY } = GEO.light;
const CORE_BASE = new THREE.Color(PAL.beamWhite);

function shaftMesh(material, bottom, top, h) {
  const p = [-bottom,0,-bottom, bottom,0,-bottom, bottom,0,bottom, -bottom,0,bottom,
    -top,h,-top, top,h,-top, top,h,top, -top,h,top];
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,0,0,1,0,0,1,1,1,0,1,1,1],2));
  g.setIndex([0,4,5,0,5,1,1,5,6,1,6,2,2,6,7,2,7,3,3,7,4,3,4,0,4,7,6,4,6,5]);
  const flat=g.toNonIndexed(); flat.computeVertexNormals(); g.dispose();
  const m=new THREE.Mesh(flat,material);m.castShadow=m.receiveShadow=true;return m;
}

function hipRoof(material, radius, rise, ridge) {
  const xyz=[],uv=[];
  const edge=(side,t,r)=>[[t*r,-r],[r,t*r],[-t*r,r],[-r,-t*r]][side];
  const vert=(side,i,j)=>{
    const u=i/14, v=j/10, t=u*2-1, [ex,ez]=edge(side,t,radius);
    const xx=ex*(1-v), zz=ez*(1-v)+Math.max(-1,Math.min(1,ez/radius))*v*ridge;
    return {p:[xx,rise*(v**1.32)+0.36*(Math.abs(t)**5)*((1-v)**2),zz],uv:[u*3,v]};
  };
  for(let k=0;k<4;k++)for(let i=0;i<14;i++)for(let j=0;j<10;j++){
    const a=vert(k,i,j),b=vert(k,i+1,j),c=vert(k,i+1,j+1),d=vert(k,i,j+1);
    for(const q of [a,b,c,a,c,d]){xyz.push(...q.p);uv.push(...q.uv);}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(xyz,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.computeVertexNormals();
  const m=new THREE.Mesh(g,material);m.castShadow=m.receiveShadow=true;return m;
}

export function buildLighthouse(scene) {
  const grp = new THREE.Group();
  grp.name = 'lighthouse';
  scene.add(grp);

  const granite=lit('#bdb3ac',{rough:0.95, emissive:'#675c55', ei:.18});
  const trim=lit('#7b746d',{map:T.stone('#87827b'),rough:.86, emissive:'#56473f', ei:.08});
  const dark=lit('#231d1d',{rough:0.96});
  const rail=lit('#753f35',{rough:.81, emissive:'#3f241a', ei:.19});
  const glazed=lit('#745741',{map:T.roofTiles('#534132','#795634','#a37b54'),rough:.87,
    side:THREE.DoubleSide,emissive:'#4b3123',ei:.12});
  const baseY=padY;
  const base=mesh([box(4.52,.34,4.54,0,.15,0),box(3.96,.34,3.96,0,.46,0)],trim);
  base.name='taihu-stepped-stone-plinth';base.position.set(LX,baseY,LZ);base.receiveShadow=true;grp.add(base);
  const shaftH=8.54, bottom=1.69, top=1.13;
  const shaft=shaftMesh(granite,bottom,top,shaftH);
  shaft.name='taihu-rectilinear-tapered-shaft';shaft.position.set(LX,baseY+.63,LZ);grp.add(shaft);
  const stoneJoints=[];
  // Fine individual course seams, not raised circular collar bands.
  for(const sgn of [-1,1])for(let i=1;i<=13;i++){
    const y=.63+i*shaftH/14,r=bottom+(top-bottom)*i/14;
    stoneJoints.push(box(2*r,.015,.009,0,y,sgn*(r+.009)),box(.009,.015,2*r,sgn*(r+.009),y,0));
  }
  const parts=mesh(stoneJoints,trim);parts.position.set(LX,baseY,LZ);grp.add(parts);
  const openings=mesh([box(.75,1.82,.041,0,1.16,-1.686),box(.25,.40,.046,.03,3.18,-1.555),
    box(.24,.35,.049,.03,5.36,-1.41),box(.22,.31,.054,.03,7.54,-1.267),
    box(.049,.35,.25,1.479,4.30,-.25),box(.044,.29,.23,1.315,6.79,-.25)],dark);
  openings.name='taihu-door-and-slit-windows';openings.position.set(LX,baseY,LZ);grp.add(openings);
  const sill=mesh([box(1.02,.25,.25,0,2.16,-1.72),box(.14,1.93,.22,-.43,1.11,-1.72),
    box(.14,1.93,.22,.43,1.11,-1.72)],trim);
  sill.position.set(LX,baseY,LZ);grp.add(sill);

  const galleryY=baseY+9.18;
  const belt=mesh([box(2.55,.24,2.55,0,.10,0),box(2.89,.23,2.89,0,.31,0),
    box(3.04,.16,3.04,0,.58,0),box(2.97,.09,2.97,0,.86,0)],rail);
  belt.name='taihu-red-lantern-gallery';belt.position.set(LX,galleryY,LZ);grp.add(belt);
  const stoneCaps=[];
  for(const x of [-1.21,1.21])for(const z of [-1.21,1.21])stoneCaps.push(box(.133,.66,.133,x,.57,z));
  const caps=mesh(stoneCaps,trim);caps.position.set(LX,galleryY,LZ);grp.add(caps);

  const roomY=galleryY+.65,roomH=1.75;
  const cols=[];
  for(const x of [-1.04,1.04])for(const z of [-1.04,1.04])cols.push(box(.16,roomH,.16,x,roomH/2,z));
  const posts=mesh(cols,granite);posts.position.set(LX,roomY,LZ);grp.add(posts);

  // 灯：一颗高动态的核，加一圈镜片反光
  const optic = new THREE.Group();
  // 灯核独占一份材质：下面每帧要按光束强度改它的颜色，不能进 glow() 的缓存池
  const coreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(PAL.beamWhite).multiplyScalar(1.2) });
  coreMat.toneMapped = false;
  coreMat.fog = false;
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.21, 18, 12), coreMat);
  const shell = new THREE.Mesh(new THREE.SphereGeometry(0.36, 20, 14), M.glass);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: T.softGlow('255,238,196', 0.12), transparent: true, blending: THREE.AdditiveBlending,
    depthWrite: false, fog: false, opacity: 0.95,
  }));
  halo.scale.set(2.6, 2.6, 1);
  halo.material.toneMapped = false;
  optic.add(core, shell, halo);
  optic.position.set(LX, roomY + roomH * 0.52, LZ);
  grp.add(optic);
  const LAMP = new THREE.Vector3(LX, roomY + roomH * 0.52, LZ);

  const lampLight = new THREE.PointLight(0xffd9a0, 24, 30, 2);
  lampLight.position.copy(LAMP);
  grp.add(lampLight);

  /* Two hipped and gently upturned tiled roofs, each with visible underside. */
  const lower=hipRoof(glazed,1.94,0.84,.69), upper=hipRoof(glazed,1.59,.82,.53);
  lower.name='taihu-lower-hip-eave';upper.name='taihu-upper-hip-eave';
  lower.position.set(LX,baseY+11.45,LZ);
  upper.position.set(LX,baseY+12.27,LZ);
  const fascia=mesh([box(2.58,.18,2.58,0,11.44,0),box(1.54,.29,1.77,0,12.12,0),
    box(.12,.12,1.18,0,13.10,0)],rail);
  fascia.position.set(LX,baseY,LZ);grp.add(lower,upper,fascia);
  const courtLight=new THREE.PointLight(0xe3bc91,37,17,2);
  courtLight.position.set(LX-3.25,baseY+2.1,LZ-4.1);grp.add(courtLight);

  /* ---- 旋转光束：空中锥壳 + 湖面亮扇 ---- */
  const beamMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
    side: THREE.DoubleSide,
    uniforms: {
      uTime: { value: 0 }, uStrength: { value: 1 },
      uColor: { value: new THREE.Color(PAL.beamWhite) },
    },
    vertexShader: `
      varying float vT; varying vec3 vN; varying vec3 vV;
      void main(){
        vT = uv.y;                       // 锥顶 1，锥底 0
        vN = normalize(normalMatrix * normal);
        vec4 mv = modelViewMatrix * vec4(position,1.0);
        vV = normalize(-mv.xyz);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      uniform float uTime; uniform float uStrength; uniform vec3 uColor;
      varying float vT; varying vec3 vN; varying vec3 vV;
      void main(){
        // 锥壳是空心的：掠射优先会把光画成一块木板，正对镜头的一圈才该最亮
        float face = abs(dot(normalize(vN), normalize(vV)));
        float along = smoothstep(0.0, 0.32, vT) * pow(vT, 1.35);
        float hum = 0.86 + 0.14*sin(uTime*3.1 + vT*22.0);
        float a = along * (0.10 + 0.90*face*face) * uStrength * hum;
        gl_FragColor = vec4(uColor, a * 0.055);
      }`,
  });
  const BEAM_LEN = 1150, BEAM_R = 42;
  const lobeGeo = new THREE.ConeGeometry(BEAM_R, BEAM_LEN, 44, 1, true);
  lobeGeo.translate(0, -BEAM_LEN / 2, 0);   // apex at origin, opening toward -Y
  // 光束与水面亮扇单独成一个根节点：它们不是实体，不该被水面镜像成一块半透明板
  const beamRoot = new THREE.Group();
  beamRoot.name = 'beam';
  scene.add(beamRoot);
  const beam = new THREE.Group();
  const TILT = 0.06;
  for (const sgn of [1, -1]) {
    const lobe = new THREE.Mesh(lobeGeo, beamMat);
    // 锥轴原指向 -Y：转成水平，两瓣成一条直线，并略微压向湖面
    lobe.rotation.x = sgn * (Math.PI / 2 - TILT);
    lobe.renderOrder = 6;
    lobe.frustumCulled = false;
    beam.add(lobe);
  }
  beam.position.copy(LAMP);
  beam.rotation.order = 'YXZ';
  beamRoot.add(beam);

  // 湖面上的亮扇：与空中光锥同一根轴，转同一个角。
  // 只画开阔水面——贴着岸的地方用烘好的高程图把扇形切掉，免得爬到陆地上。
  const fanMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
    side: THREE.DoubleSide,
    uniforms: {
      uTime: { value: 0 }, uStrength: { value: 1 }, uMap: { value: T.beamGrad() },
      uColor: { value: new THREE.Color(PAL.beamWhite) },
      uDepthMap: { value: depthTexture() },
    },
    vertexShader: `
      varying vec2 vUv; varying vec3 vW;
      void main(){
        vUv = uv;
        vec4 wp = modelMatrix * vec4(position,1.0);
        vW = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }`,
    fragmentShader: `
      uniform float uTime; uniform float uStrength; uniform sampler2D uMap; uniform vec3 uColor;
      uniform sampler2D uDepthMap;
      varying vec2 vUv; varying vec3 vW;
      void main(){
        float m = texture2D(uMap, vUv).a;
        float e = texture2D(uDepthMap, (vW.xz + ${MAP_HALF.toFixed(1)}) / ${(2 * MAP_HALF).toFixed(1)}).r * 32.0 - 24.0;
        float water = smoothstep(1.5, -0.5, e);
        // 夜里湖面上不是均匀亮，而是一段段被涌切碎的光
        float chop = 0.72 + 0.28*sin(vUv.x*46.0 - uTime*2.6) * sin(vUv.x*13.0 + uTime*1.1);
        gl_FragColor = vec4(uColor * 1.15, m * chop * uStrength * water * 0.085);
      }`,
  });
  const HALF_ANG = 0.075;
  const fan = new THREE.Group();
  for (const sgn of [1, -1]) {
    // 扇形绕局部 +Y 张开，铺平后 +Y 落到 -Z，正好接上 sgn=+1 那瓣光锥
    const center = sgn * Math.PI / 2;
    const sec = new THREE.Mesh(
      new THREE.RingGeometry(90, BEAM_LEN * 0.9, 30, 1, center - HALF_ANG, HALF_ANG * 2),
      fanMat,
    );
    // RingGeometry 的 uv 是盒状坐标，改成 沿射程=u / 横向=v 才能对上 beamGrad 的渐变
    const uvA = sec.geometry.attributes.uv, pA = sec.geometry.attributes.position;
    for (let i = 0; i < uvA.count; i++) {
      const px = pA.getX(i), py = pA.getY(i);
      const r = (Math.hypot(px, py) - 90) / (BEAM_LEN * 0.9 - 90);
      uvA.setXY(i, Math.max(0, r), 0.5 + (Math.atan2(py, px) - center) / (HALF_ANG * 2));
    }
    uvA.needsUpdate = true;
    sec.rotation.x = -Math.PI / 2;
    sec.renderOrder = 4;
    fan.add(sec);
  }
  fan.position.set(LX, 0.16, LZ);
  fan.rotation.order = 'YXZ';
  beamRoot.add(fan);

  const spin = (2 * Math.PI) / 12;   // 12 秒一转
  return {
    group: grp,
    LAMP,
    lampLight,
    update(t, strength = 1) {
      const a = t * spin;
      beam.rotation.y = a;
      fan.rotation.y = a;
      const pulse = 0.55 + 0.45 * Math.pow(Math.abs(Math.sin(a * 2)), 2.2);
      const s = strength * pulse;
      beamMat.uniforms.uTime.value = t;
      beamMat.uniforms.uStrength.value = s;
      fanMat.uniforms.uTime.value = t;
      fanMat.uniforms.uStrength.value = s * 1.25;
      lampLight.intensity = 14 + 22 * s;
      coreMat.color.copy(CORE_BASE).multiplyScalar(0.72 + 0.8 * s);
      halo.material.opacity = 0.18 + 0.29 * s;
      const hs = 2.0 + 2.1 * s;
      halo.scale.set(hs, hs, 1);
    },
  };
}
