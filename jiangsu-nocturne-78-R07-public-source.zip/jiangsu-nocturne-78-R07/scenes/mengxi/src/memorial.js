import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { box, chineseRoof, plaqueMesh, M } from './kit.js';

/** Rear display hall figure, distinct from both plaza sculpture and the exterior bust.
 * The robe is a continuous folded mesh; the unknown back is only a plain continuation. */
function addSeatedShenKuo(parent,x,floor,z) {
  const g=new THREE.Group();g.name='mengxi-rear-hall-seated-shen-kuo';
  g.position.set(x,floor,z);g.rotation.y=Math.PI;
  const pale=new THREE.MeshStandardMaterial({color:'#b7b7ad',roughness:.90});
  const stoneEdge=new THREE.MeshStandardMaterial({color:'#a6a79f',roughness:.94});
  const dark=new THREE.MeshStandardMaterial({color:'#343a36',roughness:.87});
  const plume=new THREE.MeshStandardMaterial({color:'#92978b',roughness:.92});
  function part(geometry,mat,name) {
    const o=new THREE.Mesh(geometry,mat);o.name=name;o.castShadow=true;o.receiveShadow=true;g.add(o);
    return o;
  }
  function oval(mat,name,x,y,z,a,b,c) {
    return part(new THREE.SphereGeometry(1,18,12).scale(a,b,c).translate(x,y,z),mat,name);
  }
  function line(mat,name,nodes,r,taper=1) {
    const p=nodes.map(v=>new THREE.Vector3(...v));
    const c=new THREE.CatmullRomCurve3(p);
    const geo=new THREE.TubeGeometry(c,Math.max(12,3*nodes.length),r,7);
    const attr=geo.getAttribute('position');
    if(taper!==1) {
      const rings=Math.max(12,3*nodes.length);
      for(let j=0;j<=rings;j++) {
        const t=j/rings,m=c.getPointAt(t),d=(1-t)+t*taper;
        for(let q=0;q<8;q++){const i=j*8+q;
          attr.setXYZ(i,m.x+(attr.getX(i)-m.x)*d,m.y+(attr.getY(i)-m.y)*d,m.z+(attr.getZ(i)-m.z)*d);
        }
      }
      geo.computeVertexNormals();
    }
    return part(geo,mat,name);
  }
  function robe(name,levels,folds) {
    const N=48,xyz=[],idx=[],uv=[];
    for(let j=0;j<levels.length;j++) {
      const [y,cx,cz,rx,rz,phase]=levels[j];
      for(let i=0;i<=N;i++){
        const a=2*Math.PI*i/N, f=1+folds*Math.cos(a*9+phase)+folds*.47*Math.sin(a*14-phase);
        xyz.push(cx+Math.sin(a)*rx*f,y,cz+Math.cos(a)*rz*f);uv.push(i/N,j/(levels.length-1));
        if(i&&j){const d=j*(N+1)+i,b=d-(N+1);idx.push(b-1,b,d-1,b,d,d-1);}
      }
    }
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(xyz,3));
    geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.setIndex(idx);geo.computeVertexNormals();
    return part(geo,pale,name);
  }
  // Low, dark rectilinear stone block, not an outdoor monument pedestal.
  part(box(1.48,.083,1.00,0,.048,.012),dark,'shen-kuo-plinth-foot');
  part(box(1.46,.76,.97,0,.45,.012),dark,'shen-kuo-dark-rectangular-plinth');
  part(box(1.51,.058,1.02,0,.849,.02),stoneEdge,'shen-kuo-low-stone-sculpture-base');
  // Broader knees pull robe forward over a seated base; narrower waist and shoulders stand vertically.
  robe('shen-kuo-seated-drapery',[
    [.865,0,.16,.48,.36,1.10],[.92,-.02,.19,.46,.37,.65],[1.03,-.035,.205,.44,.34,.59],
    [1.17,-.04,.205,.355,.325,.30],[1.33,-.04,.17,.385,.35,.40],
    [1.465,-.025,.10,.36,.335,.30],[1.57,-.025,-.03,.295,.265,.51],
    [1.65,-.018,-.055,.25,.203,.40],[1.70,-.018,-.06,.21,.18,.35]
  ],.071);
  robe('shen-kuo-robed-torso',[
    [1.55,0,-.063,.26,.225,.43],[1.65,.006,-.089,.268,.213,.36],
    [1.79,.013,-.105,.255,.198,.17],[1.96,.004,-.109,.272,.154,0],
    [2.06,-.008,-.102,.285,.148,0],[2.15,-.014,-.091,.233,.128,0],
    [2.23,-.015,-.075,.124,.103,0],[2.28,-.020,-.066,.076,.067,0]
  ],.047);
  line(pale,'shen-kuo-left-fallen-sleeve',[[-.205,2.064,-.080],[-.316,1.91,-.020],[-.346,1.66,.150],[-.22,1.57,.282]],.115,.69);
  line(pale,'shen-kuo-right-loose-sleeve',[[.214,2.04,-.10],[.32,1.85,-.015],[.346,1.64,.111],[.26,1.615,.272],[.158,1.60,.302]],.121,.68);
  oval(stoneEdge,'shen-kuo-left-hand',-.123,1.60,.334,.090,.044,.077).rotation.z=.07;
  oval(stoneEdge,'shen-kuo-right-hand',.091,1.63,.338,.085,.042,.077);
  line(stoneEdge,'shen-kuo-crossed-collar',[[-.137,2.205,.012],[-.078,2.14,.036],[.013,2.07,.065],[.103,1.995,.086]],.024,.79);
  line(stoneEdge,'shen-kuo-inner-collar',[[.108,2.196,.013],[.066,2.132,.037],[.014,2.082,.068]],.020,.80);
  line(stoneEdge,'shen-kuo-front-fold',[[-.16,1.58,.39],[-.188,1.48,.492],[-.30,1.25,.49],[-.305,1.05,.51],[-.408,.91,.38]],.022,.67);
  line(stoneEdge,'shen-kuo-diagonal-fold',[[.13,1.52,.344],[.114,1.355,.459],[.164,1.17,.466],[.24,1.01,.408]],.021,.77);
  line(stoneEdge,'shen-kuo-loose-sleeve-fold',[[.345,1.78,.069],[.369,1.565,.202],[.373,1.38,.239],[.410,1.19,.168]],.024,.66);
  oval(pale,'shen-kuo-neck',-.021,2.25,-.059,.074,.100,.075);
  oval(pale,'shen-kuo-carved-head',-.028,2.386,-.037,.116,.154,.112);
  oval(stoneEdge,'shen-kuo-carved-hair',-.030,2.475,-.073,.123,.089,.108);
  oval(stoneEdge,'shen-kuo-small-topknot',-.048,2.575,-.080,.045,.064,.047);
  for(const side of [-1,1]){
    oval(pale,'shen-kuo-ear',-.028+side*.103,2.380,-.035,.025,.051,.028);
    oval(stoneEdge,'shen-kuo-brow',-.028+side*.047,2.418,.058,.040,.017,.028);
    oval(plume,'shen-kuo-eye-carving',-.027+side*.043,2.401,.065,.031,.007,.012);
  }
  oval(pale,'shen-kuo-nose',-.029,2.379,.071,.023,.047,.046);
  line(stoneEdge,'shen-kuo-stone-beard',[[-.035,2.344,.071],[-.041,2.302,.079],[-.041,2.250,.070]],.031,.20);
  parent.add(g);
}

/** Compressed present-day memorial and adjacent mixed-use street. The
 * historical garden creek is not part of this reconstructed site. */
export function buildMemorial(scene) {
  const base=1.45, A=-13.3;
  const group=new THREE.Group(); group.name='Mengxi present-day memorial';
  const mat=(c,roughness=.88,emissive='#0c0d10',emissiveIntensity=.10)=>new THREE.MeshStandardMaterial({color:c,roughness,emissive,emissiveIntensity});
  const gray=mat('#7a7c78'), stone=mat('#a0a096'), darker=mat('#535451'), wood=mat('#563f36',.78),
    plaster=mat('#afaaa0'), asphalt=mat('#44474b',.99), paving=mat('#8d8c83',.95),
    foliage=mat('#354332',.96,'#18241c',.24), warm=mat('#858071',.70,'#ffa663',.19),
    glass=mat('#262d32',.63,'#293646',.18), earth=mat('#464c37',.98);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=512;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#777c7e';ctx.fillRect(0,0,512,512);
  let seed=9251;
  function unit(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
  for(let row=0;row<35;row++)for(let col=-1;col<26;col++){
    const x=(col+(row%2)*.5)*20.5,y=row*14.63,r=129+(unit()-.50)*23;
    ctx.fillStyle=`rgb(${r+2},${r+4},${r+5})`;ctx.fillRect(x+.56,y+.54,19.73,13.66);
    ctx.fillStyle='rgba(160,158,150,.12)';ctx.fillRect(x+.57,y+.86,19.4,1.1);
  }
  const brickMap=new THREE.CanvasTexture(canvas);brickMap.colorSpace=THREE.SRGBColorSpace;
  brickMap.anisotropy=4;
  const brickGray=mat('#a8b1b8',.94);brickGray.map=brickMap;
  const buckets=new Map();
  const put=(m,g)=>{
    if(!buckets.has(m))buckets.set(m,[]);
    // Keep all index layouts and vertex attributes merge compatible.
    buckets.get(m).push(g.index ? g.toNonIndexed() : g);
  };
  const S=(m,w,h,d,x,y,z)=>put(m,box(w,h,d,x,y,z));
  const flush=()=>{for(const [m,p] of buckets){const merged=mergeGeometries(p);const o=new THREE.Mesh(merged,m);o.receiveShadow=true;group.add(o);}buckets.clear();};
  const label=(name,w,h,x,y,z)=>{
    const p=plaqueMesh(name,w,h,{dir:'h',bg:'#b0a795',fg:'#51493b',border:'#a19685'});
    p.position.set(x,y,z);p.rotation.y=Math.PI;group.add(p);
  };
  const roof=(w,d,r,x,y,z)=>{
    const g=chineseRoof({width:w,depth:d,height:r,overhang:.47,curve:.5,eaveLift:.17,hip:false,segU:28,segV:10});
    g.translate(x,y,z);put(M.mxTile,g);
    for(let j=0;j<Math.round(w/.235);j++){
      const xx=x-w/2+.14+j*.235;
      for(const zz of [z-d*.5-.47,z+d*.5+.47]){
        put(M.mxTile,new THREE.CylinderGeometry(.061,.062,.19,7).rotateX(Math.PI/2).translate(xx,y+.008,zz));
      }
    }
  };
  const fills=[];
  const lamp=(x,y,z,amount=16)=>{
    const l=new THREE.PointLight(0xffce99,amount,10.5,2);l.position.set(x,y,z);scene.add(l);fills.push([l,amount]);
  };
  // Ordinary asphalt, narrow continuous sidewalk and selectively recessed shops.
  S(asphalt,92,.17,7.8,-19,base-.15,0);
  S(paving,93,.14,1.5,-19,base-.09,4.62);S(paving,93,.14,1.48,-19,base-.09,-4.6);
  const asphaltPatch=mat('#4c4a4a',.98);
  for(let i=0;i<42;i++){
    const x=-65+i*2.15;
    S(darker,2.105,.16,.24,x,base-.028,3.96);S(darker,2.105,.16,.24,x,base-.028,-3.96);
    if(i%4===0)S(asphaltPatch,2.5,.007,.33,x,base-.060,-1.4+(i%3)*1.2);
  }
  for(const side of [-1,1]){
    for(let i=0;i<16;i++){
      const x=-64+i*5.6,w=5.32;
      if(side===1&&Math.abs(x-A)<14)continue;
      const z=side*6.8,h=3.15+(i%5)*.62;
      const wall=i%5===0?gray:(i%3===0?darker:plaster);
      S(wall,w,h,3.95,x,base+h*.5,z+side*1.25);
      S(darker,w+.19,.17,4.16,x,base+h,z+side*1.22);
      for(const sx of [-1,1]){
        S(wood,1.47,2.06,.18,x+sx*1.06,base+1.3,z-side*.84);
        S((i+side)%7===0?warm:glass,1.31,1.86,.05,x+sx*1.06,base+1.3,z-side*.949);
        S(darker,1.64,.15,.31,x+sx*1.06,base+.24,z-side*.99);
        for(let k=-1;k<=1;k++)S(wood,.04,1.78,.06,x+sx*1.06+k*.28,base+1.3,z-side*.99);
      }
      if(i%5===2){
        S(wall,w+.035,1.89,3.52,x,base+h+.9,z+side*1.3);
        for(const s of [-1,1])S(glass,.87,1.02,.12,x+s*1.05,base+h+.96,z-side*.49);
      }
    }
  }
  // Three-panel grey-brick street portal, a real dark centre opening and stone cheeks.
  const z=5.85, entrance=2.04,ww=12.82,hh=4.34;
  for(const side of [-1,1]){
    const cx=A+side*(ww*.25+entrance*.25);
    S(brickGray,(ww-entrance)/2,hh,.65,cx,base+hh/2,z);
    S(stone,.16,hh-.30,.17,A+side*(entrance*.5+.14),base+hh*.49,z-.39);
    S(stone,.23,hh-.22,.14,A+side*(ww*.5-.32),base+hh*.50,z-.41);
    S(stone,2.23,.70,.16,A+side*3.49,base+2.86,z-.41);
    S(darker,1.85,.42,.20,A+side*3.49,base+2.86,z-.46);
    S(gray,5.62,3.35,5.0,A+side*9.28,base+1.675,z+2.53);
    roof(5.50,5.15,.62,A+side*9.25,base+3.38,z+2.4);
    S(wood,2.75,2.74,.22,A+side*9.25,base+1.38,z-.02);
    for(let i=0;i<9;i++) S(glass,.16,2.15,.06,A+side*9.25+(i-4)*.24,base+1.42,z-.157);
    for(let step=0;step<3;step++)S(stone,2.84,.11,.34,A+side*9.25,base+.09+step*.12,z-.57+step*.32);
  }
  S(brickGray,ww,1.44,.65,A,base+3.60,z);
  S(stone,2.68,.38,.22,A,base+2.92,z-.428);
  roof(ww+.4,4.74,.57,A,base+hh,z+1.86);
  label('梦溪园',2.12,.45,A,base+3.33,z-.548);
  for(let i=0;i<4;i++)S(stone,2.37,.12,.36,A,base+.08+i*.122,z-1.09+i*.34);
  for(const side of [-1,1]){
    put(stone,new THREE.CylinderGeometry(.34,.34,.24,14).rotateZ(Math.PI/2).rotateY(Math.PI/2)
        .translate(A+side*1.43,base+.54,z-.88));
  }
  // Limited dry courtyard. The circular opening and rails follow the 2013
  // documented restoration, not evidence of a surviving Song-period structure.
  S(paving,22,.18,27,A,base-.08,20);
  for(let i=0;i<19;i++)for(let j=0;j<7;j++){
    const x=A-6+(i+.5)*.63,z=7.1+j*.82;
    S(i%3===0?stone:paving,.61,.055,.79,x,base+.03,z);
  }
  const moonZ=13.1,moonTop=4.34,moonR=1.27,c=1.93;
  const wall=new THREE.Shape([new THREE.Vector2(-5.1,0),new THREE.Vector2(5.1,0),new THREE.Vector2(5.1,moonTop),new THREE.Vector2(-5.1,moonTop)]);
  const hole=new THREE.Path();hole.absarc(0,c,moonR,0,Math.PI*2,true);wall.holes.push(hole);
  const gate=new THREE.ExtrudeGeometry(wall,{depth:.65,bevelEnabled:false,curveSegments:40});
  gate.translate(A,base,moonZ);put(gray,gate);
  roof(10.43,1.0,.19,A,base+moonTop,moonZ+.30);
  for(let j=0;j<30;j++){
    const a=j*Math.PI*2/30+.012,b=(j+1)*Math.PI*2/30-.012;
    const p=(q,r)=>new THREE.Vector2(Math.cos(q)*r,Math.sin(q)*r+c);
    const ring=new THREE.ExtrudeGeometry(new THREE.Shape([p(a,moonR),p(a,moonR+.19),p(b,moonR+.19),p(b,moonR)]),
      {depth:.14,bevelEnabled:false});ring.translate(A,base,moonZ-.10);put(stone,ring);
  }
  label('梦溪园',1.94,.46,A,base+3.60,moonZ-.128);
  for(let k=0;k<5;k++){
    const tz=moonZ-2.7+k*.51, y=base+.10+k*.142;
    S(stone,3.94,.17,.52,A,y,tz);
    if(k%2===0)for(const s of [-1,1]){
      S(stone,.16,.88,.17,A+s*1.82,y+.43,tz);
      S(stone,.24,.13,.19,A+s*1.82,y+.87,tz);
    }
    for(const s of [-1,1]){
      put(stone,box(.13,.16,.56).rotateX(-.24).translate(A+s*1.82,y+.75,tz));
    }
  }
  for(const side of [-1,1]){
    S(gray,.34,2.71,18.0,A+side*9.06,base+1.35,20.6);
    S(M.mxTile,.55,.17,18.3,A+side*9.06,base+2.73,20.6);
    S(earth,4.2,.12,9.6,A+side*5.67,base+.04,20.37);
  }
  // Memorial front: dark wooden long panels, a simple grey lower apron and
  // a recessed gallery. Exhibits are modest stylised panels, not photographs.
  const hz=27.9;
  S(gray,13.8,.56,6.92,A,base+.26,hz);
  S(plaster,13.62,3.23,.32,A,base+1.75,hz+3.2);
  for(const side of [-1,1]){
    S(plaster,.30,3.38,6.70,A+side*6.82,base+1.71,hz);
    for(let i=0;i<24;i++){
      const x=A+side*(1.80+i*.195);
      S(wood,.043,2.67,.08,x,base+1.9,hz-3.39);
    }
    S(glass,4.76,2.36,.04,A+side*4.11,base+1.91,hz-3.30);
    S(wood,.22,3.4,.23,A+side*1.5,base+1.94,hz-3.67);
    S(wood,.24,3.34,.24,A+side*6.68,base+1.92,hz-3.62);
    S(wood,4.92,.26,.23,A+side*4.12,base+3.03,hz-3.43);
    for(const y of [.92,1.48,2.46])S(wood,4.82,.075,.092,A+side*4.10,base+y,hz-3.43);
  }
  roof(14.3,7.32,1.18,A,base+3.79,hz);
  label('沈括纪念室',3.27,.62,A,base+3.29,hz-3.72);
  addSeatedShenKuo(group,A,base+.54,hz+1.38);
  for(let i=0;i<5;i++){
    if(i===2) continue; // The central rear bay holds the documented figure; exhibits flank it.
    const x=A+(i-2)*2.12;
    S(wood,1.67,2.16,.15,x,base+1.67,hz+2.79);
    S(paving,1.43,1.93,.042,x,base+1.70,hz+2.694);
    for(let line=0;line<6;line++)S(darker,1.07-line*.048,.025,.033,x,base+2.13-line*.145,hz+2.667);
  }
  const display=new THREE.Group();display.name='interpretive display only';group.add(display);
  S(wood,2.19,.77,.74,A+4,base+.74,28.52);
  S(glass,2.24,.26,.80,A+4,base+1.24,28.52);
  const border=new THREE.Group();border.name='no exterior water or replica Song park';group.add(border);
  function shrubs(x,z,cap=1){
    for(let i=0;i<16;i++){
      const a=i*2.39996,r=(.19+((i*.618)%1)*.61)*cap;
      put(foliage,new THREE.IcosahedronGeometry(.126+((i*.72)%1)*.22,1)
             .scale(1.2,.62,.97).translate(x+r*Math.cos(a),base+.37+((i*.337)%1)*.54*cap,z+r*Math.sin(a)));
    }
  }
  for(const [xx,zz,r] of [[A-3.2,4.7,1.2],[A+3.3,4.7,1.2],[A-6.3,19,1.2],[A+5.9,20.5,1.3],
    [A-1.8,21.8,.74],[A-6,24,1.12],[A+6.4,23.1,.92]])shrubs(xx,zz,r);
  for(const [x,y,z,v] of [[-47,5.8,-1.4,73],[-29,5.4,2.1,48],[A-4,5.1,2.6,57],[A+4,4.6,2.3,46],
    [A-.3,4.7,11.5,26],[A+3.7,5.5,24.3,58],[A+.6,4.2,27.6,29]])lamp(x,y,z,v);
  flush();scene.add(group);
  const streetFinish={enabled:true,set(v){
    streetFinish.last=v;
    asphalt.roughness=1-Math.min(v,1.5)*.040;
    paving.roughness=.99-Math.min(v,1.5)*.065;
    asphalt.metalness=Math.min(v,1.5)*.016;
  }};
  const lamps=[{pos:[A-5.5,4.9,5.42],kind:'alley',big:false},{pos:[A+4.8,4.8,24.12],kind:'yard',big:false}];
  return {group,anchors:{lamps,paths:[]},streetFinish,setLights(v){for(const [l,amount] of fills)l.intensity=amount*Math.min(v,1.5);}, fills};
}
