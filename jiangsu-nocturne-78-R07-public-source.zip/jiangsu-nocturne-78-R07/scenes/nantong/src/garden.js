/**
 * 园林要素与岸线：沿河步道、驳岸、荷池、石梁桥、假山、亭、水榭、紫藤架、
 *  path 与树。园子按"园馆一体"的读法排：墙内一线树影，池与桥做前庭，
 * 馆舍退在后面 —— 从河上看过来，先看见的是树梢和屋脊。
 */
import * as THREE from 'three';
import { box, boxM, pyramidalRoof, barrelRoof, rr, pick } from './kit.js';
import { Batch, place, balustrade, ironFence, tree, pergola, rockPile, scholarStone, lampPost, gardenLamp, lantern, lotusRemnant, glowKey } from './parts.js';
import { YUAN, RIVER } from './data.js';

export function buildGarden(scene) {
  const group = new THREE.Group();
  group.name = 'garden';
  scene.add(group);
  const B = new Batch();
  const anchors = [];
  const { pool } = YUAN;
  const zw = YUAN.wallZ;

  /* ------------------------------------------------------------ 沿河步道 */
  const road0 = RIVER.southZ + 1.2;      // 河坎
  const road1 = zw - 0.6;               // 墙根
  B.add('paving', boxM(YUAN.halfWidth * 2 + 40, 0.5, road1 - road0, 0, -0.5, (road0 + road1) / 2, 1));
  // 河坎石驳岸：一道压顶石 + 岸壁，把水面与步道的接缝盖住
  B.add('stone', boxM(YUAN.halfWidth * 2 + 60, 0.34, 1.1, 0, 0.16, road0 - 0.3, 1));
  B.add('stoneDark', boxM(YUAN.halfWidth * 2 + 60, 1.5, 0.8, 0, -1.6, road0 - 1.0, 1));
  balustrade(B, { from: [-YUAN.halfWidth - 10, road0 - 0.5], to: [YUAN.halfWidth + 10, road0 - 0.5], h: 0.92, gap: 1.6 });
  // 行道树与路灯：一整条沿河的绿线
  for (let i = 0; i < 26; i++) {
    const x = -YUAN.halfWidth - 6 + (i / 25) * (YUAN.halfWidth * 2 + 12);
    if (Math.abs(x + 10) < 6) continue;    // 门口让开
    if (i % 2 === 0) lampPost(B, { x, z: road0 + 0.6, h: 5.6, arms: 2 });
    tree(B, { x: x + rr(-1.2, 1.2), z: road1 - 1.1, h: rr(8.4, 11.5), kind: pick(['plane', 'plane', 'willow']) });
    anchors.push({ pos: [x, 1.4, road0 + 0.6], color: '#ffc78a', width: 2.6, depth: 15 + rr(0, 7), intensity: 0.55 });
  }

  /* ------------------------------------------------------------ 园内地坪 */
  // 四块围出荷池，留出池面（倒影要能从池子里看穿）
  const pN = pool.cz - pool.hz, pS = pool.cz + pool.hz, pW = pool.cx - pool.hx, pE = pool.cx + pool.hx;
  const hw = YUAN.halfWidth, far = zw + 300;
  const modern = YUAN.modernBasin;
  const cuts=[
    {x0:pW,x1:pE,z0:pN,z1:pS},
    {x0:modern.cx-modern.hx,x1:modern.cx+modern.hx,z0:modern.cz-modern.hz,z1:modern.cz+modern.hz},
  ];
  const zCuts=[zw+.6,...cuts.flatMap(c=>[c.z0,c.z1]),far].sort((a,b)=>a-b);
  for(let i=1;i<zCuts.length;i++){
    const z0=zCuts[i-1],z1=zCuts[i],c=cuts.find(c=>(z0+z1)/2>c.z0&&(z0+z1)/2<c.z1);
    const spans=c?[[-hw-12,c.x0],[c.x1,hw+12]]:[[-hw-12,hw+12]];
    for(const [x0,x1] of spans)B.add('gravel',boxM(x1-x0,.5,z1-z0,(x0+x1)/2,-.5,(z0+z1)/2,1));
  }
  // 草坪
  for (const [cx, cz, w, d] of [
    [-72, 40, 62, 26], [96, 44, 44, 22], [-96, 84, 46, 40], [8, 88, 60, 30], [99, 121, 57, 40], [-111, 151, 34, 31],
  ]) B.add('lawn', boxM(w, 0.14, d, cx, 0, cz, 1));
  // 主路：进门一条正路，再横向一条绕池
  B.add('paving', boxM(6.4, 0.16, 44, -10, 0.02, zw + 22, 1));
  B.add('paving', boxM(150, 0.16, 5.2, 4, 0.02, zw + 5.4, 1));
  B.add('paving', boxM(5.2, 0.16, 60, pE + 5, 0.02, pool.cz + 22, 1));
  // One dry promenade joins the historic pavilions; a separate terrace
  // meets the 2005 wing without touching the historical lily pond.
  B.add('paving',boxM(6.9,.13,123,44,.005,86.5,1));
  for(const z of [70,118,135])B.add('paving',boxM(38,.12,4.2,44,.006,z,1));
  B.add('paving',boxM(10,.13,55,-53,.005,111,1));
  const mn=modern.cz-modern.hz,ms=modern.cz+modern.hz;
  for(const [w,d,x,z] of [[38,9,-58,mn-4.55],[modern.hx*2+.58,.31,modern.cx,mn-.17],
    [modern.hx*2+.58,.31,modern.cx,ms+.17],[.31,modern.hz*2,modern.cx-modern.hx-.17,modern.cz],
    [.31,modern.hz*2,modern.cx+modern.hx+.17,modern.cz]])B.add('paving',boxM(w,.27,d,x,.006,z,1));
  for(let i=0;i<3;i++){
    B.add('stoneDark',boxM(10.8-i*1.05,.12,.46,-65.45,.11+i*.06,mn-1.75-i*.43,1));
  }
  for(const [x,z] of [[39,133],[49,133],[35,79],[51,81],[-70,139],[-43,138]]){
    B.add('stoneDark',box(.23,.31,.24,x,.14,z));
    B.add(glowKey('#eac184',.82),box(.105,.065,.03,x,.38,z-.129));
  }
  for (let i = 0; i < 9; i++) {
    const x = -66 + i * 16;
    gardenLamp(B, { x, z: zw + 5.4 + (i % 2 ? 3.4 : -3.4), h: 0.86 });
    anchors.push({ pos: [x, 0.9, zw + 5.4], color: '#ffcf94', width: 1.6, depth: 5.5, intensity: 0.3 });
  }

  /* 谦亭与水禽罧 photo: soft banks, small rock points and a small
     still pool; not a large bridge crossing between school galleries. */
  for(const [x,z,w,h,d,chunks] of [
    [pW+.35,pN+.35,3.7,1.07,2.1,9],[pW+1.38,pS-1.21,3.6,1.25,2.8,11],
    [pE-.29,pN+1.68,3.6,1.03,4.7,9],[pE-.42,pS-.59,3.8,1.47,2.3,13],
    [pW+6.9,pN+.12,4.9,.63,1.5,9],[pE-6.1,pS+.02,7.3,.75,1.71,12],
  ])rockPile(B,{x,z,w,h,d,chunks});
  for(let i=0;i<16;i++){
    const bank=i%2===0?pW+rr(.7,3.2):pE-rr(.8,3.0);
    lotusRemnant(B,{x:bank,z:rr(pN+.7,pS-.7),y:.14});
  }
  for(const [x,z] of [[pW-1.5,pS-2.8],[pE+.45,pN-1.4],[pE+.24,pS+1.7]]){
    tree(B,{x,z,h:rr(4.4,6.2),kind:'plane'});
  }
  // Low heterogeneous foliage footprints instead of spherical trees lined
  // across the horizon. Keep the main eastern historic route clear.
  const shrub=(x,z,rx,rz,h,seed=0)=>{
    for(let k=0;k<13;k++){
      const a=(k*2.39996+seed),rr0=.22+.68*((k*.618)%1);
      const r=.21+((k*.317)%1)*.43;
      B.add(k%3===0?'museumGreenCool':'museumGreen',place(new THREE.IcosahedronGeometry(r,1),{
        x:x+Math.cos(a)*rx*rr0,y:h*(.30+.38*(1-rr0)),z:z+Math.sin(a)*rz*rr0,
        sx:.9+rx*.29,sy:h*.9,sz:.9+rz*.25,ry:a,
      }));
    }
  };
  for(const [x,z,w,d,h] of [[29.6,143,2.8,1.8,1.7],[31.8,138.8,2.6,1.4,1.2],
     [32.7,131.9,3.1,2.0,1.1],[57.1,136.5,3.8,2.0,1.34],[57.8,143.7,3.5,2.8,1.4],
     [31.8,87.8,3.4,2.9,.77],[56.2,92.1,3.5,2.7,.86],[58.3,85.3,3.7,2.0,.65],
     [82.2,74.6,2.4,1.8,1.21],[82.6,85.4,2.8,1.8,1.38],[102.1,75.4,2.5,2.4,1.28],
     [104.4,81.1,2.3,1.9,1.33],[99,88.55,2.9,1.6,.89],[87,88.6,2.5,.92,1.05],
     [-79,157.7,3.0,1.15,.55],[-39,143.5,3.2,1.55,.68]])shrub(x,z,w,d,h,x*.5);
  // Fine dry paths and a modest scalloped arrival apron outside the South Hall.
  for(let j=0;j<7;j++)for(let k=-3;k<=3;k++){
    if(Math.abs(k)<3 || j>1)B.add('museumGranite',boxM(1.06,.04,.55,44+k*1.09,.157,131.4+j*.57,1));
  }
  for(let j=0;j<4;j++)for(let k=0;k<14;k++){
    B.add((j+k)%3===0?'museumGranite':'stoneDark',boxM(1.49,.027,1.49,-75+2.45*k,.277,134.0+j*1.50,1));
  }

  /* ------------------------------------------------------------ 假山与石 */
  rockPile(B, { x: -44, z: 32, w: 26, h: 8.2, d: 15, chunks: 34 });
  rockPile(B, { x: -62, z: 24, w: 14, h: 4.6, d: 10, chunks: 16 });
  rockPile(B, { x: 92, z: 34, w: 18, h: 5.4, d: 12, chunks: 20 });
  rockPile(B, { x: -95, z: 119, w: 14, h: 4.3, d: 9, chunks: 12 });
  scholarStone(B, { x: -30, z: 21, h: 3.4 });
  scholarStone(B, { x: 76, z: 26, h: 2.6 });

  /* 谦亭及水禽罧实景的低台红栏木廊；不主张精确分期或平面复测。 */
  {
    const sx = pool.cx + 2.7, sz = pS + 2.4;
    B.add('stone',boxM(13.7,.52,5.2,sx,.02,sz,1));
    B.add('tile',barrelRoof(14.1,5.6,1.0,sx,3.08,sz,{overhang:.55}));
    for(let i=0;i<=6;i++)for(const side of [-1,1]){
      const x=sx+(i-3)*2.02,z=sz+side*2.13;
      B.add('museumTrim',box(.15,2.77,.15,x,.52,z));
    }
    B.add('museumTrim',boxM(12.78,.104,.16,sx,1.40,sz-2.26,1));
    B.add('museumTrim',boxM(12.78,.094,.14,sx,.66,sz-2.26,1));
    for(let i=0;i<33;i++){
      B.add('museumTrim',box(.055,.74,.06,sx+(i-16)*.38,.68,sz-2.26));
    }
    lantern(B,{x:sx-2.1,y:2.7,z:sz-1.68,r:.14,color:'#ffb96c'});
    anchors.push({pos:[sx-2.1,.55,sz-2.15],color:'#f8b970',width:1.6,depth:4.8,intensity:.26});
  }
  /* -------------------------------------------------------------- 方亭 */
  {
    const tx = -74, tz = 62;
    B.add('stone', boxM(6.2, 0.45, 6.2, tx, 0.02, tz, 1));
    for (const ox of [-2.1, 2.1]) for (const oz of [-2.1, 2.1]) {
      B.add('timber', box(0.22, 2.9, 0.22, tx + ox, 0.47, tz + oz));
    }
    B.add('timber', box(4.9, 0.24, 0.24, tx, 3.1, tz - 2.1));
    B.add('timber', box(4.9, 0.24, 0.24, tx, 3.1, tz + 2.1));
    B.add('timber', box(0.24, 0.24, 4.9, tx - 2.1, 3.1, tz));
    B.add('timber', box(0.24, 0.24, 4.9, tx + 2.1, 3.1, tz));
    B.add('tile', pyramidalRoof(4.4, 2.5, tx, 3.34, tz, { overhang: 0.8, lift: 0.5 }));
    B.add('timber', box(0.12, 0.6, 0.12, tx, 5.84, tz));
    for (const s of [-1, 1]) balustrade(B, { from: [tx - 2.6, tz + s * 2.6], to: [tx + 2.6, tz + s * 2.6], h: 0.66, gap: 1.2 });
    gardenLamp(B, { x: tx - 3.6, z: tz, h: 1.6 });
  }

  /* ------------------------------------------------------------ 紫藤架 */
  pergola(B, { x: -88, z: 26, w: 17, d: 5.4, h: 3.05, baysX: 5, baysZ: 2 });
  pergola(B, { x: 62, z: 148, w: 13, d: 4.6, h: 2.95, baysX: 4, baysZ: 2 });

  /* -------------------------------------------------------------- 杂树 */
  const spots = [
    [-150, 30, 'plane'], [-138, 58, 'fir'], [-120, 96, 'plane'], [-148, 120, 'willow'],
    [-104, 46, 'plane'], [-66, 106, 'plane'], [-112, 150, 'fir'], [-58, 168, 'plane'],
    [-18, 118, 'plane'], [16, 132, 'fir'], [29, 60, 'plane'], [74, 62, 'plane'],
    [112, 46, 'plane'], [148, 34, 'fir'], [160, 74, 'plane'], [132, 96, 'plane'],
    [156, 128, 'plane'], [108, 152, 'willow'], [62, 178, 'plane'], [6, 196, 'plane'],
    [-70, 196, 'fir'], [-128, 186, 'plane'], [150, 176, 'plane'], [23, 157, 'plane'],
  ];
  for (const [x, z, kind] of spots) tree(B, { x, z, h: rr(8.5, 14), kind });
  // 别业前的小乔木列：退到机位之后，不然正好糊在镜头与门廊之间
  for (let i = 0; i < 6; i++) tree(B, { x: 100 + i * 9, z: 104 + (i % 2) * 5, h: rr(7, 9), kind: 'plane' });
  // 北岸外的绿带（对岸的环城林）
  for (let i = 0; i < 30; i++) {
    tree(B, { x: -300 + i * 20 + rr(-5, 5), z: RIVER.northZ - 5 - rr(0, 4), h: rr(8, 12), kind: pick(['plane', 'willow', 'fir']) });
  }

  /* ------------------------------------------------------------ 侧界墙 */
  for (const s of [-1, 1]) {
    ironFence(B, { from: [s * YUAN.halfWidth, zw + 1.6], to: [s * YUAN.halfWidth, zw + 46], wallH: 0.85, barH: 1.05 });
  }
  for (const sx of [-1, 1]) {
    B.add('brick', boxM(0.8, 2.2, 12, sx * (YUAN.halfWidth - 1), 0, zw + 7, 1));
  }

  const meshes = B.flush(group);
  return { group, meshes, anchors };
}
