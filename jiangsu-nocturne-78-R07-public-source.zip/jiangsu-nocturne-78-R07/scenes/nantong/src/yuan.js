/**
 * 苑区建筑群：中馆(1906)、南馆(1906)、北楼(1911)、濠南别业(1914-15) 与 苑门围墙。
 * 形制按可核查的文字记载建模（开间数、层数、平面形状、屋面材料），总平面位置
 * 与相互间距按画面构图排布 —— 这不是实测总图，帮助面板里已经这样声明。
 */
import * as THREE from 'three';
import { box, boxM, poly, M, gableRoof, xieshanRoof, pyramidalRoof, barrelRoof } from './kit.js';
import { Batch, place, windowRun, doorway, colonnade, ironFence, steps, archTop, glowKey } from './parts.js';
import { BUILDINGS, YUAN } from './data.js';

/** 西式山花：三棱柱，底边沿 X 张开，depth 沿 Z */
function pediment({ cx, cz, w, h, y, depth, cornice = 0.3 }) {
  const hw = w / 2, f = cz - depth / 2, b = cz + depth / 2;
  return poly([
    [[cx - hw, y, f], [cx + hw, y, f], [cx, y + h, f]],
    [[cx + hw, y, b], [cx - hw, y, b], [cx, y + h, b]],
    [[cx - hw, y, f], [cx, y + h, f], [cx, y + h, b], [cx - hw, y, b]],
    [[cx, y + h, f], [cx + hw, y, f], [cx + hw, y, b], [cx, y + h, b]],
    [[cx - hw, y, b], [cx - hw, y, f], [cx + hw, y, f], [cx + hw, y, b]],
    [[cx - hw, y + h, f], [cx - hw, y, f], [cx + hw, y, f], [cx + hw, y + h, f]],
  ]).clone().translate(0, cornice, 0);
}

export function buildYuan(scene) {
  const group = new THREE.Group();
  group.name = 'yuan';
  scene.add(group);

  const B = new Batch();
  /** 需要被泛光滑块控制的灯 */
  const floods = [];
  /** 建筑外墙上真实存在的灯位，交给水面光柱 */
  const anchors = [];
  const litMeshes = [];


  M.museumGreen = new THREE.MeshStandardMaterial({color:0x344435,roughness:.98,emissive:0x18241a,emissiveIntensity:.35});
  M.museumGreenCool = new THREE.MeshStandardMaterial({color:0x3b5140,roughness:.98,emissive:0x19271e,emissiveIntensity:.33});
  M.museumSand = new THREE.MeshStandardMaterial({color:0xb4a286,roughness:.93});
  M.museumCream = new THREE.MeshStandardMaterial({color:0xc5bdaa,roughness:.94});
  M.museumTrim = new THREE.MeshStandardMaterial({color:0x763e35,roughness:.73});
  M.museumCharcoal = new THREE.MeshStandardMaterial({color:0x393d46,roughness:.74});
  M.museumGranite = new THREE.MeshStandardMaterial({color:0x777d78,roughness:.89});
  M.museumGlass = new THREE.MeshStandardMaterial({color:0x293b44,roughness:.28,metalness:.29,
    emissive:0x172128,emissiveIntensity:.34});
  M.museumGlassWarm = new THREE.MeshStandardMaterial({color:0x8b846b,roughness:.35,metalness:.15,
    emissive:0xb3874a,emissiveIntensity:.42});
  const stone=(key,w,h,d,x,y,z)=>B.add(key,boxM(w,h,d,x,y,z,1));
  /* Historic middle hall, reconstructed from the black-and-white archive.
     Low gable visually separate from the observation room's small hip. */
  {
    const {x,z}=BUILDINGS.zhong;
    const w=15.4,d=11.2,base=.37,h=3.5,n=z-d/2;
    stone('stone',w+1.0,base,d+.9,x,0,z);
    stone('museumCream',w,h,d,x,base,z);
    B.add('tile',gableRoof(w,d,1.48,x,base+h,z,{overhang:.53,thick:.23,lift:.04}));
    // Archive shows the long raking pediment on the viewing end; a narrow
    // architectural band, not an extra scroll roof pasted in front.
    B.add('museumCream',pediment({cx:x,cz:n-.05,w:w*.94,h:1.35,y:base+h-.15,depth:.47,cornice:0}));
    stone('stoneDark',w-.15,.17,.35,x,base+h-.23,n-.31);
    for(const s of [-1,1]) {
      const theta=s*.17,len=w*.47/Math.cos(theta);
      B.add('stoneDark',box(len,.13,.25).rotateZ(theta).translate(x-s*w*.235,base+h+.47,n-.35));
      stone('museumGranite',.22,3.18,.19,x+s*6.8,base,n-.14);
    }
    steps(B,{cx:x,cz:n-.55,face:'-z',w:4.8,n:3,rise:.11,tread:.36,key:'stone'});
    doorway(B,{cx:x,cz:n,face:'-z',w:2.13,h:2.68,arch:true,frameKey:'museumGranite',panelKey:'timber'});
    for(const face of ['-z','+z']){
      windowRun(B,{cx:x,cz:z+(face==='-z'?-1:1)*d/2,face,length:w-2.1,bays:3,
        w:1.45,h:1.7,arch:true,frameKey:'museumGranite',style:'sash',y0:base,litChance:.1,skip:face==='-z'?['0-1']:[]});
    }
    const tw=5.2,tz=z+1.3,ty=base+h+.61,th=2.6;
    stone('museumCream',tw,th,tw,x,ty,tz);
    stone('timber',tw+.18,.21,tw+.18,x,ty+1.55,tz);
    B.add('tile',pyramidalRoof(tw,.95,x,ty+th,tz,{overhang:.50,lift:.11}));
    for(const face of ['-z','-x','+x']){
      windowRun(B,{cx:face==='-z'?x:(face==='-x'?x-tw/2:x+tw/2),cz:face==='-z'?tz-tw/2:tz,
        face,length:3.8,bays:2,w:.94,h:1.05,frameKey:'timber',y0:ty,sill:1.19,litChance:.08});
    }
    floods.push({pos:[x-5,2.1,n-9],target:[x,3.75,n-.28],angle:.53,color:0xf0cfac,power:150});
  }

  /* South gallery: restrained pale plaster + recessed stacked porch.
     Buildings to either side of the red projecting eaves are not annexes
     of Haonan residence. */
  {
    const {x,z}=BUILDINGS.nan;
    const w=23.5,d=12.6,b=.43,f=4.12,h=7.65,n=z-d/2,p=n-2.7,r=3.85;
    stone('stone',w+1.3,b,d+.86,x,0,z);
    stone('museumSand',w,h,d,x,b,z);
    stone('museumCream',w+.30,.36,d+.22,x,b+h-.40,z);
    stone('museumCream',w+.34,.24,d+.17,x,b+f-.11,z);
    stone('museumCream',w+.58,.19,d+.5,x,b+h+.28,z);
    // Front shallow parapet with red inset rhythm; central red roof rises
    // behind it and the entry itself carries an independent projecting hip.
    stone('museumSand',w,.72,.47,x,b+h-.02,n+.06);
    for(let j=0;j<19;j++){
      stone('museumTrim',.52,.36,.12,x+(j-9)*1.08,b+h+.16,n-.224);
    }
    B.add('ironRoof',gableRoof(w*.58,d*.84,1.65,x,b+h+.55,z+.45,{overhang:.16,thick:.22,lift:0}));
    B.add('ironRoof',pyramidalRoof(8.8,1.39,x,b+h-.14,p-.10,{overhang:.52,lift:.10}));
    stone('museumTrim',8.27,.16,.28,x,b+h-.16,p-3.63);
    // Chamfered balcony and two-storey supports; don't fill the projecting
    // volume with a solid box under its roof.
    const balconyShape=new THREE.Shape();
    for(const [i,[dx,dz]] of [[-3.85,2.85],[3.85,2.85],[3.85,-.68],[2.69,-1.67],[-2.69,-1.67],[-3.85,-.68]].entries()){
      if(i===0)balconyShape.moveTo(dx,-dz);else balconyShape.lineTo(dx,-dz);
    }
    balconyShape.closePath();
    const balcony=new THREE.ExtrudeGeometry(balconyShape,{depth:.29,bevelEnabled:false});
    balcony.rotateX(-Math.PI/2);balcony.translate(x,b+f-.18,p);
    balcony.setIndex(Array.from({length:balcony.attributes.position.count},(_,i)=>i));
    B.add('stone',balcony);
    for(const v of [-1,1])for(const y of [b,b+f]){
      const fy=y===b?f:3.35,px=x+v*3.48;
      stone('museumTrim',.22,fy,.25,px,y,p-.52);
      stone('museumCream',.37,.24,.36,px,y,p-.52);
      stone('museumTrim',.41,.16,.48,px,y+fy-.12,p-.52);
    }
    const railY=b+f+.22;
    for(let i=0;i<23;i++)stone('ironwork',.057,1.04,.055,x+(i-11)*.24,railY,p-1.66);
    stone('museumTrim',5.58,.115,.15,x,railY+1,p-1.66);
    for(const v of [-1,1]){
      for(let i=0;i<7;i++)stone('ironwork',.056,1.01,.054,x+v*(2.71+i*.158),railY,p-1.66+i*.155);
      B.add('museumTrim',box(1.52,.12,.15).rotateY(v*.78).translate(x+v*3.2,railY+1.05,p-1.18));
      for(let k=0;k<4;k++)stone('museumCream',.20,h-.10,.15,x+v*(4.08+k*2.30),b+.06,n-.12);
    }
    steps(B,{cx:x,cz:p-1.31,face:'-z',w:8.4,n:3,rise:b/3,tread:.37,key:'stone'});
    doorway(B,{cx:x,cz:n,face:'-z',w:2.4,h:3.6,arch:true,frameKey:'museumTrim',panelKey:'timber'});
    B.add('glass',place(archTop(1.09,.13),{x,y:b+f+1.88,z:n-.21}));
    stone('timber',2.16,1.56,.21,x,b+f+.33,n-.19);
    for(const side of [-1,1]){
      windowRun(B,{cx:x+side*7.8,cz:n-.03,face:'-z',length:6.1,bays:2,floors:2,floorH:f,
        w:1.12,h:2.05,sill:.97,frameKey:'museumTrim',y0:b,style:'sash',litChance:.19});
      const lx=x+side*10.6,lz=n-4.7;
      B.add('ironRoof',pyramidalRoof(3.65,.74,lx,2.6,lz,{overhang:.35,lift:.1}));
      for(const q of [-1,1])for(const k of [-1,1])stone('museumTrim',.16,2.45,.16,lx+q*1.6,.12,lz+k*1.55);
      stone('stoneDark',3.7,.18,3.55,lx,0,lz);
      floods.push({pos:[x+side*8.3,1.94,p-6.3],target:[x+side*4.8,4.4,n-.44],angle:.61,color:0xffd5a0,power:154});
    }
    for(const side of [-1,1]){
      windowRun(B,{cx:x+side*w/2,cz:z,face:side===1?'+x':'-x',length:d-2.3,bays:3,floors:2,floorH:f,
        w:1.13,h:2.1,frameKey:'museumTrim',y0:b,sill:.86,litChance:.1});
    }
    floods.push({pos:[x+.35,4.3,p-1],target:[x,6.0,n-.2],angle:.86,color:0xffc383,power:56});
  }
  /* ============================================================ 北楼 1911 */
  {
    const { x, z } = BUILDINGS.bei;
    // 五开间二层中式楼房，歇山屋顶
    const W = 25, D = 11.5, plinth = 0.45, f1 = 4.3, f2 = 3.8;
    const cornice = plinth + f1 + f2;
    B.add('stone', boxM(W + 2.2, plinth, D + 2.2, x, 0, z, 1));
    B.add('brick', boxM(W, f1 + f2, D, x, plinth, z, 1));
    B.add('tile', xieshanRoof(W, D, 3.4, x, cornice, z, { overhang: 1.1, lift: 0.7 }));
    // 平座与檐柱（前廊一圈）
    B.add('plaster', boxM(W + 0.5, 0.28, D + 0.5, x, plinth + f1 - 0.28, z, 1));
    B.add('timber', boxM(W + 1.2, 0.34, 0.9, x, plinth + f1 - 0.05, z - D / 2 - 0.6, 1));
    for (let i = 0; i <= 5; i++) {
      const px = x - W / 2 + (W * i) / 5;
      B.add('timber', box(0.3, f2, 0.3, px, plinth + f1, z - D / 2 - 1.0));
    }
    B.add('timber', box(W + 1.2, 0.4, 0.5, x, plinth + f1 + f2 - 0.4, z - D / 2 - 1.0));
    steps(B, { cx: x, cz: z - D / 2 - 1.6, face: '-z', w: 5, n: 3, rise: plinth / 3, tread: 0.38, key: 'stone' });
    doorway(B, { cx: x, cz: z - D / 2, face: '-z', w: 2.6, h: 3.5, frameKey: 'timber', panelKey: 'timber' });
    for (const face of ['-z', '+z']) {
      windowRun(B, {
        cx: x, cz: face === '-z' ? z - D / 2 : z + D / 2, face, length: W - 3,
        floors: 2, floorH: f2 + 0.5, bays: 5, w: 1.7, h: 2.4, style: 'lattice',
        frameKey: 'timber', y0: plinth + 0.15, sill: 0.9, litChance: 0.18,
        skip: face === '-z' ? ['0-2'] : [],
      });
    }
    for (const face of ['-x', '+x']) {
      windowRun(B, { cx: face === '-x' ? x - W / 2 : x + W / 2, cz: z, face, length: D - 2.6, bays: 2, floors: 2, floorH: f2 + 0.5, w: 1.3, h: 2.2, style: 'lattice', frameKey: 'timber', y0: plinth, litChance: 0.2 });
    }
    // 山墙压线
    for (const sx of [-1, 1]) B.add('brick', boxM(0.5, 1.1, D - 1, x + sx * (W / 2 - 0.25), cornice, z, 1));
    anchors.push({ pos: [x, plinth + 0.4, z - D / 2 - 1.8], color: '#ffbf86', width: 5, depth: 14, intensity: 0.5 });
    floods.push({ pos: [x - 7, 1.5, z - D / 2 - 14], target: [x - 3, 7.2, z - 3], angle: 0.55, color: 0xffc07a, power: 560 });
    floods.push({ pos: [x + 9, 1.5, z - D / 2 - 14], target: [x + 4, 7.2, z - 3], angle: 0.55, color: 0xffc07a, power: 560 });
  }

  /* ======================================================= 濠南别业 1914-15 */
  {
    const { x, z } = BUILDINGS.haonan;
    // 英式四层砖木楼：陡红铁皮坡顶、罗马柱门廊、拱形窗楣
    const W = 21, D = 14.5, plinth = 0.7;
    const hh = [4.5, 3.7, 3.4, 3.2];
    const cornice = plinth + hh.reduce((a, b) => a + b, 0);
    B.add('stone', boxM(W + 2.6, plinth, D + 2.6, x, 0, z, 1));
    B.add('brickWarm', boxM(W, cornice - plinth, D, x, plinth, z, 1));
    // 一层基座段与每层腰线（抹灰线脚）
    B.add('plaster', boxM(W + 0.35, 0.9, D + 0.35, x, plinth, z, 1));
    let y = plinth + hh[0];
    for (let i = 1; i < 3; i++) {
      B.add('plaster', boxM(W + 0.4, 0.24, D + 0.4, x, y - 0.12, z, 1));
      y += hh[i];
    }
    B.add('plaster', boxM(W + 0.75, 0.5, D + 0.75, x, cornice - 0.5, z, 1));
    // 陡坡红铁皮屋顶：四面坡（先做前后两坡 + 山墙收头）
    B.add('ironRoof', gableRoof(W, D, 4.6, x, cornice, z, { overhang: 0.75, thick: 0.36, lift: 0.55 }));
    for (const sx of [-1, 1]) {
      B.add('brickWarm', boxM(0.6, 1.5, D - 0.6, x + sx * (W / 2 - 0.3), cornice, z, 1));
    }
    // 老虎窗三座
    for (let i = 0; i < 3; i++) {
      const dx2 = x + (i - 1) * 6.2;
      B.add('brickWarm', boxM(3, 1.9, 2.4, dx2, cornice + 0.9, z - D / 2 - 0.9, 1));
      B.add('ironRoof', gableRoof(3.4, 2.8, 0.75, dx2, cornice + 2.8, z - D / 2 - 0.9, { overhang: 0.28, thick: 0.2 }));
      windowRun(B, { cx: dx2, cz: z - D / 2 - 2.1, face: '-z', length: 3, bays: 1, w: 1.1, h: 1.4, frameKey: 'plaster', y0: cornice + 1.0, litChance: 0.5 });
    }
    // 烟囱
    for (const sx of [-1, 1]) {
      B.add('brickWarm', boxM(1.5, 3.2, 1.5, x + sx * (W / 2 - 3), cornice + 2.2, z + 2, 1));
      B.add('plaster', boxM(1.7, 0.25, 1.7, x + sx * (W / 2 - 3), cornice + 5.4, z + 2, 1));
    }
    // 罗马柱门廊：两层高，柱顶一段檐壁 + 巴洛克山花
    const pz = z - D / 2 - 2.6;
    colonnade(B, { cx: x, cz: pz, along: 'x', len: 8.4, count: 4, h: hh[0] + hh[1] + 0.3, r: 0.36, order: 'roman', key: 'plaster', y0: plinth });
    B.add('plaster', boxM(9.6, 1.1, 1.6, x, plinth + hh[0] + hh[1] + 0.3, pz, 1));
    B.add('plaster', place(archTop(1.8, 1.1), { x, y: plinth + hh[0] + hh[1] + 0.85, z: pz + 0.2 }));
    B.add('glow:#ffd9a6|1.1', box(6.4, 0.1, 0.1, x, plinth + hh[0] + hh[1] + 1.35, pz + 0.75));
    steps(B, { cx: x, cz: pz - 1.3, face: '-z', w: 7, n: 5, rise: plinth / 5, tread: 0.42, key: 'stone' });
    doorway(B, { cx: x, cz: z - D / 2, face: '-z', w: 3, h: 4.1, arch: true, frameKey: 'plaster', panelKey: 'timber', litAbove: true });
    // 拱形窗楣的窗：面河一面最完整
    const floors = 4;
    const yAt = (f) => plinth + hh[0] + (f - 1) * hh[1] + 0.3;
    windowRun(B, { cx: x, cz: z - D / 2, face: '-z', length: W - 4.6, bays: 5, floors, floorH: hh[1] + 0.2, w: 1.5, h: 2.7, arch: true, style: 'sash', frameKey: 'plaster', y0: plinth, sill: 0.95, litChance: 0.24, skip: ['0-2'] });
    windowRun(B, { cx: x, cz: z + D / 2, face: '+z', length: W - 4, bays: 5, floors, floorH: hh[1] + 0.2, w: 1.45, h: 2.5, arch: true, frameKey: 'plaster', y0: plinth, litChance: 0.12 });
    for (const face of ['-x', '+x']) {
      windowRun(B, { cx: face === '-x' ? x - W / 2 : x + W / 2, cz: z, face, length: D - 4, bays: 3, floors, floorH: hh[1] + 0.2, w: 1.35, h: 2.5, arch: true, frameKey: 'plaster', y0: plinth, litChance: 0.18 });
    }
    // 侧翼：三层，往河方向错出来一点，避免立面太平
    const aw = 9, ad = 8.5, ah = hh[0] + hh[1] + hh[2];
    const ax = x - W / 2 - aw / 2 + 1.2, az = z - 1.5;
    B.add('stone', boxM(aw + 1.6, plinth, ad + 1.6, ax, 0, az, 1));
    B.add('brickWarm', boxM(aw, ah - plinth, ad, ax, plinth, az, 1));
    B.add('plaster', boxM(aw + 0.5, 0.42, ad + 0.5, ax, ah - 0.42, az, 1));
    B.add('ironRoof', gableRoof(aw, ad, 3.1, ax, ah, az, { overhang: 0.6, thick: 0.3 }));
    windowRun(B, { cx: ax, cz: az - ad / 2, face: '-z', length: aw - 2, bays: 2, floors: 3, floorH: hh[1], w: 1.3, h: 2.3, arch: true, frameKey: 'plaster', y0: plinth, litChance: 0.26 });
    windowRun(B, { cx: ax - aw / 2, cz: az, face: '-x', length: ad - 2.4, bays: 2, floors: 3, floorH: hh[1], w: 1.25, h: 2.2, arch: true, frameKey: 'plaster', y0: plinth, litChance: 0.2 });
    anchors.push({ pos: [x, plinth + 0.6, pz - 1.4], color: '#ffd2a0', width: 7, depth: 20, intensity: 0.7 });
    anchors.push({ pos: [ax, plinth + 0.5, az - ad / 2 - 1], color: '#ffcf9a', width: 4, depth: 14, intensity: 0.5 });
    floods.push({ pos: [x - 6, 1.6, pz - 17], target: [x - 2, 9.5, z - 4], angle: 0.52, color: 0xffb877, power: 640 });
    floods.push({ pos: [x + 7, 1.6, pz - 17], target: [x + 2, 9.5, z - 4], angle: 0.52, color: 0xffb877, power: 640 });
    floods.push({ pos: [ax + 4, 1.4, az - ad / 2 - 14], target: [ax, 7, az - 2], angle: 0.55, color: 0xffb877, power: 430 });
  }

  /* 2005 new wing; no borrowed classical verandas, colour-changing
     outlines or fabricated calligraphy from published exterior images. */
  {
    const {x,z}=BUILDINGS.modern;
    const curtain=(cx,cz,w,h,key='museumGlass')=>{
      stone(key,w,h,.09,cx,.15,cz);
      for(let i=0;i<=Math.round(w/1.19);i++){
        stone('museumCharcoal',.077,h,.15,cx-w/2+w*i/Math.round(w/1.19),.15,cz-.045);
      }
      for(const y of [.19,2.5,3.86,h+.11].filter(y=>y<h+.15))stone('museumCharcoal',w,.078,.14,cx,y,cz-.047);
    };
    const volume=(cx,cz,w,d,h)=>{
      stone('museumCharcoal',w,h,d,cx,0,cz);
      for(let row=0;row<5;row++){
        stone(row%2===0?'museumGranite':'museumCream',w-.37,.65,.15,cx,.33+row*.79,cz-d/2-.04);
        for(const side of [-1,1])stone('museumGranite',.19,.65,d-.18,cx+side*w/2,.33+row*.79,cz);
      }
      stone('museumCharcoal',w+.75,.37,d+.67,cx,h-.01,cz);
      B.add('stoneDark',gableRoof(w+.12,d+.16,.46,cx,h+.18,cz,{overhang:.16,thick:.15,lift:0}));
    };
    volume(x-14,z+2,9.4,12.7,4.6);
    volume(x+13,z+3.9,13.0,13.6,5.64);
    stone('museumCharcoal',17,4.08,6.7,x-1.5,.12,z-.48);
    curtain(x-2.45,z-4.05,17.5,4.14);
    curtain(x-4.35,z-4.13,7.9,2.23,'museumGlassWarm');
    stone('museumCharcoal',18.18,.34,7.3,x-2.0,4.20,z-.55);
    stone('paving',16.5,.20,3.96,x-2.0,.08,z-5.4);
    const plaqueWallZ=z+3.9-13.6/2-.142;
    stone('museumCream',9.62,3.01,.08,x+13,.92,plaqueWallZ);
    // The carved slab is plain in this interpretation, with only its seams.
    for(let j=-1;j<=1;j++)stone('museumGranite',.025,2.9,.04,x+13+j*2.4,.98,plaqueWallZ-.052);
    for(const [ox,oz,Y] of [[-14.5,.1,4.98],[.6,-1.2,4.62],[13.05,1.70,6.03]]){
      stone('museumCharcoal',1.55,.12,1.55,x+ox,Y,z+oz);
      stone('showcase',1.06,.78,1.06,x+ox,Y+.09,z+oz);
      for(const side of [-1,1])stone('museumCharcoal',.05,.80,1.10,x+ox+side*.55,Y+.09,z+oz);
      stone('museumCharcoal',1.29,.13,1.28,x+ox,Y+.89,z+oz);
    }
    for(const ob of [-25,-22.5,-20]){
      stone('museumCharcoal',.30,3.56,.33,x+ob,.1,z-4.3);
    }
    stone('museumCharcoal',5.4,.24,3.18,x-22.52,3.62,z-3.2);
    floods.push({pos:[x-3,2.1,z-9.4],target:[x+1,2.82,z-4.05],angle:.76,color:0xffdfba,power:110});
    floods.push({pos:[x+13,2.3,z-9],target:[x+13,3.9,z-2.45],angle:.55,color:0xf4e1ca,power:46});
  }

  /* ============================================================ 苑门与围墙 */
  {
    const zw = YUAN.wallZ, hw = YUAN.halfWidth, gx = -10;
    // 门楼：两座砖墩 + 石额 + 小瓦顶（形制为写意，真实门楼样式未逐处核实）
    const pierH = 5.0, pierW = 2.3, gapW = 7.4;
    for (const sx of [-1, 1]) {
      const px = gx + sx * (gapW / 2 + pierW / 2);
      B.add('brick', boxM(pierW, pierH, pierW * 0.9, px, 0, zw, 1));
      B.add('stone', boxM(pierW + 0.4, 0.35, pierW + 0.4, px, 0, zw, 1));
      B.add('plaster', boxM(pierW + 0.5, 0.6, pierW + 0.5, px, pierH, zw, 1));
      B.add('tile', pyramidalRoof(pierW + 0.9, 1.35, px, pierH + 0.6, zw, { overhang: 0.35, lift: 0.3 }));
    }
    B.add('brick', boxM(gapW + pierW * 2, 0.8, 1.1, gx, pierH - 0.8, zw, 1));
    B.add('plaster', boxM(gapW + pierW * 2 - 1.2, 1.5, 0.4, gx, pierH - 0.6, zw - 0.75, 1));
    B.add('tile', gableRoof(gapW + pierW * 2 + 0.8, 2.6, 1.1, gx, pierH, zw, { overhang: 0.55, thick: 0.26 }));
    // 匾：夜里只剩一圈描边光
    B.add(glowKey('#e6c084', 1.05), box(6.2, 1.14, 0.1, gx, pierH - 0.4, zw - 0.95));
    // 电动栅栏门（关着）
    for (let i = 0; i < 12; i++) {
      const px = gx - gapW / 2 + (gapW * i) / 12 + 0.2;
      B.add('ironwork', box(0.09, 2.5, 0.09, px, 0.05, zw));
    }
    B.add('ironwork', box(gapW, 0.14, 0.12, gx, 2.5, zw));
    B.add('ironwork', box(gapW, 0.1, 0.1, gx, 1.25, zw));
    // 两侧围墙：砖矮墙 + 铁栅，一段段排过去
    for (const [a, b] of [[-hw, gx - gapW / 2 - pierW], [gx + gapW / 2 + pierW, hw]]) {
      ironFence(B, { from: [a, zw], to: [b, zw], wallH: 0.85, barH: 1.15 });
    }
    // 门房（守房）：一进小房，窗里留一盏夜灯
    const hx = gx + gapW / 2 + pierW + 5.5;
    B.add('brick', boxM(5, 3.1, 4, hx, 0, zw + 3.2, 1));
    B.add('tile', gableRoof(5.6, 4.6, 1.2, hx, 3.1, zw + 3.2, { overhang: 0.45, thick: 0.22 }));
    B.add('litWindow', box(1.1, 1.2, 0.06, hx - 1.2, 1.4, zw + 1.2 - 0.03));
    anchors.push({ pos: [gx, 0.9, zw - 1.2], color: '#ffcf94', width: 3, depth: 9, intensity: 0.45 });
    floods.push({ pos: [gx, 1.1, zw - 15], target: [gx, 4.6, zw + 1], angle: 0.5, color: 0xffcb92, power: 360 });
  }

  /* ------------------------------------------------------------ 收尾 */
  const meshes = B.flush(group);
  for (const key of ['litWindow', 'litCool', 'showcase']) {
    const m = meshes.get(key);
    if (m) litMeshes.push(m);
  }

  // 泛光灯：真正的上照灯从地面向打，砖缝与瓦垄才有影
  const spots = [];
  for (const f of floods) {
    const sp = new THREE.SpotLight(f.color, f.power, 130, f.angle, 0.62, 2);
    sp.position.set(...f.pos);
    sp.target.position.set(...f.target);
    scene.add(sp, sp.target);
    spots.push(sp);
  }

  // 园内地坪由 garden.js 分块铺（避开荷池）：这里再压一整块板，
  // 就会盖住池面，把倒影在出水面的第一米深度掉。
  return {
    group,
    meshes,
    litMeshes,
    spots,
    anchors,
    setFlood(v) {
      for (const sp of spots) sp.intensity = sp.userData.base * v;
    },
    init() {
      for (const sp of spots) sp.userData.base = sp.intensity;
    },
  };
}
