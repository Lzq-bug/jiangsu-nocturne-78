/**
 * 正桥：9 墩 10 孔的双层钢桁梁、上下两层桥面、栏板与 202 块浮雕。
 * 坐标按 data.js 的桥轴（+z 为南岸），高程一律走 GIRDER 与 roadY/railY。
 */
import * as THREE from 'three';
import {
  PIERS, PIER, GIRDER, MAIN_END, ABUT, SPANS, RELIEF,
} from './data.js';
import { M, box, member, mesh, loft, remat } from './kit.js';

const { bottomY, trussH, trussX, deckW, railDeckW, trackX, panel } = GIRDER;
const topY = bottomY + trussH;
const ROAD = GIRDER.roadY;
const RAILD = GIRDER.railY;
const L = MAIN_END * 2;

/** 桁架节点：沿桥轴每 panel 米一个，正桥范围内连续（节间长为写意） */
function panelPoints() {
  const zs = [];
  const n = Math.round(L / panel);
  for (let i = 0; i <= n; i++) zs.push(-MAIN_END + i * panel);
  return zs;
}

/** 支撑点 z：南桥台 — 9 墩 — 北桥台 */
export const SUPPORTS = [ABUT, ...PIERS, -ABUT];

/* ------------------------------------------------------------------ 钢桁梁 */

// Scalloped lower outline beneath the railway deck, deeper at the supports.
function chordY(z) {
  const support = Math.min(...SUPPORTS.map(p => Math.abs(p - z)));
  return bottomY + 4.1 * Math.sin(Math.min(1, support / 64) * Math.PI / 2);
}
function trussGeometry() {
  const main = [], fittings = [], bearings = [], top = ROAD - .7;
  const zs = panelPoints();
  for (const x of [-trussX, trussX]) {
    main.push(box(1.24, .96, L, x, top - .5, 0));
    main.push(box(1.36, .56, L, x, RAILD -.52, 0));
    for(let i=0; i<zs.length-1; i++) {
      const a=zs[i], b=zs[i+1], za=chordY(a), zb=chordY(b);
      main.push(member([x,za,a],[x,zb,b],.87,1.16));
      main.push(member([x,Math.min(za,RAILD-.1),a],[x,top,a],.56,.64));
      main.push(member([x,i%2 ? Math.min(za+.35,RAILD) : top,a],
                       [x,i%2 ? top : Math.min(zb+.35,RAILD),b],.64,.72));
      if(i%2===0){
        for(const z of [a,b]) {
          fittings.push(box(.22,1.42,1.42,x + Math.sign(x)*.54,top-.72,z));
          fittings.push(box(.24,1.15,1.35,x + Math.sign(x)*.48,RAILD-.55,z));
        }
      }
      if(x>0){
        main.push(box(trussX*2,.43,.44,0,top-.52,a));
        if(i%2===0) main.push(box(trussX*2,.46,.56,0,RAILD-.78,a));
      }
    }
  }
  for(const z of SUPPORTS) {
    bearings.push(box(1.95,.76,2.9,-trussX,bottomY-1.1,z));
    bearings.push(box(1.95,.76,2.9,trussX,bottomY-1.1,z));
    bearings.push(box(22.9,.72,1.9,0,bottomY-.88,z));
  }
  return {main,fittings,bearings};
}

/* ------------------------------------------------------------------ 两层桥面 */
function upperDeck() {
  return [box(deckW,.51,L,0,ROAD-.51,0)];
}
function sidewalks() {
  return [-1,1].map(s=>box(GIRDER.walkW,.15,L,s*(deckW/2-GIRDER.walkW/2),ROAD,0));
}
function lanePaint() {
  const parts=[];
  for(const [x,w] of [[0,.12],[-7.37,.12],[7.37,.12]]) parts.push(box(w,.027,L,x,ROAD+.007,0));
  for(const x of [-3.75,3.75]) for(let z=-MAIN_END+4;z<MAIN_END-4;z+=13)
    parts.push(box(.13,.025,5.9,x,ROAD+.007,z));
  return parts;
}
function lowerDeck() {
  const parts=[box(railDeckW,.48,L,0,RAILD-.48,0)];
  parts.push(box(1.3,.16,L,railDeckW/2+.95,RAILD-.06,0));
  return parts;
}
function railHeads() {
  const parts=[];
  for(const x of [-trackX,trackX]) for(const d of [-.75,.75])
    parts.push(box(.105,.18,L,x+d,RAILD+.03,0));
  return parts;
}

/* ------------------------------------------------------------------ 栏板与浮雕 */

/**
 * 202 块浮雕：南北两侧沿正桥各 98 块，另 6 块"工农兵"放在桥头。
 * 块数可考，排列与间距无记载，取均匀排布（写意）。
 */
function railings() {
  const posts = [], pickets = [];
  const sun = [];
  const scene = [];
  const worker = [];
  const base = ROAD + 0.14;
  const perSide = RELIEF.sunflower;
  const step = L / perSide;
  for (const sx of [-deckW / 2, deckW / 2]) {
    // 下槛 + 扶手 + 每块栏板两端一根立柱：中间是空的，浮雕才看得见
    posts.push(box(0.25,0.18,L,sx,base,0));
    posts.push(box(0.2, 0.16, L, sx, base + RELIEF.panelH + 0.1, 0));
    for(let z=-MAIN_END+1.2;z<MAIN_END;z+=1.2) {
      const d=((z+MAIN_END)%step)-step/2;
      if(Math.abs(d)>RELIEF.panelW*.51) pickets.push(box(.078,1.02,.095,sx,base+.15,z));
    }
    for (let i = 0; i <= perSide; i++) {
      posts.push(box(0.28, RELIEF.panelH + 0.14, 0.30, sx, base, -MAIN_END + i * step));
    }
  }
  for (let side = 0; side < 2; side++) {
    const sx = side === 0 ? -deckW / 2 : deckW / 2;
    for (let i = 0; i < perSide; i++) {
      const z = -MAIN_END + (i + 0.5) * step;
      const g = new THREE.BoxGeometry(0.2, RELIEF.panelH, RELIEF.panelW);
      g.translate(sx, base + RELIEF.panelH / 2 + 0.2, z);
      (i % 2 === 0 ? sun : scene).push(g);
    }
    for (let i = 0; i < 3; i++) {
      const z = (side === 0 ? -1 : 1) * (MAIN_END - 6 - i * 3.2);
      const g = new THREE.BoxGeometry(0.22, RELIEF.panelH, RELIEF.panelW);
      g.translate(sx, base + RELIEF.panelH / 2 + 0.2, z);
      worker.push(g);
    }
  }
  return { posts, pickets, sun, scene, worker };
}

/* ------------------------------------------------------------------ 桥墩 */

function roundedRect() {
  const r = 0.34, c = 1 - r, pts = [];
  const arc = (sx, sz, a0, a1) => {
    for (let i = 0; i <= 3; i++) {
      const a = a0 + ((a1 - a0) * i) / 3;
      pts.push([sx * c + r * Math.cos(a), sz * c + r * Math.sin(a)]);
    }
  };
  pts.push([-c, -1]);
  arc(1, -1, -Math.PI / 2, 0);
  arc(1, 1, 0, Math.PI / 2);
  arc(-1, 1, Math.PI / 2, Math.PI);
  arc(-1, -1, Math.PI, Math.PI * 1.5);
  pts.pop();
  return pts;
}

function pierGeometry() {
  const parts = [], caps = [], plinth = [], trim=[];
  for (const z of PIERS) {
    const base = -3.4;
    const top = bottomY - 1.35;
    const steps = 6;
    const lv = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      lv.push({
        y: base + (top - base) * t, cx: 0, cz: z,
        sx: (PIER.cross / 2) * (1 - 0.19 * t),
        sz: (PIER.along / 2) * (1 - 0.17 * t),
      });
    }
    parts.push(loft(lv, roundedRect(), { uvScale: 4.2 }));
    caps.push(loft([{y:top-2.6,cx:0,cz:z,sx:6.4,sz:4.03},{y:top-1.35,cx:0,cz:z,sx:9.3,sz:4.3},{y:top+.24,cx:0,cz:z,sx:11.7,sz:4.5}],roundedRect(),{uvScale:2.8}));
    // 水线附近的潮湿带
    if(z===16 || z===176 || z===-144) trim.push(loft([{y:.13,cx:0,cz:z,sx:8.65,sz:4.85},{y:.49,cx:0,cz:z,sx:8.65,sz:4.85}],roundedRect(),{uvScale:4}));
    plinth.push(loft([{y:-.6,cx:0,cz:z,sx:8.6,sz:4.8},{y:.85,cx:0,cz:z,sx:8.6,sz:4.8},{y:1.15,cx:0,cz:z,sx:7.56,sz:4.13}],roundedRect(),{uvScale:3}));
  }
  return {parts,caps,plinth,trim};
}

/* ------------------------------------------------------------------ 桥台 */

function abutmentGeometry() {
  const parts = [];
  for (const z of [ABUT, -ABUT]) {
    const sgn = Math.sign(z);
    parts.push(box(PIER.cross + 2.2, topY - 0.4, 6.0, 0, -1.6, z));
    parts.push(box(deckW + 1.4, 3.4, 4.0, 0, bottomY - 1.4, z + sgn * 3.6));
  }
  return parts;
}

/* ------------------------------------------------------------------ 装配 */

export function buildMainBridge(scene) {
  const grp = new THREE.Group();
  grp.name = 'main-bridge';

  const pier=pierGeometry();
  const body=mesh(pier.parts,M.pier);body.name='nine-tapered-piers'; grp.add(body);
  grp.add(mesh(pier.caps,M.concrete));
  const plinth=mesh(pier.plinth,M.pierWet);plinth.name='pier-waterline-plinths';grp.add(plinth);
  grp.add(mesh(pier.trim,new THREE.MeshStandardMaterial({color:'#773e31',roughness:.94,emissive:'#3e1b13',emissiveIntensity:.1})));
  grp.add(mesh(abutmentGeometry(), M.concreteDark));
  grp.add(mesh(lowerDeck(), remat(M.ballast, 1, 58)));
  const truss=trussGeometry();
  const steel=mesh(truss.main,M.steel);steel.name='bolted-variable-depth-truss';grp.add(steel);
  grp.add(mesh(truss.fittings,M.steelDark),mesh(truss.bearings,M.steelDark));
  grp.add(mesh(railHeads(),M.steel));
  grp.add(mesh(sidewalks(),remat(M.curb,1,690)));
  grp.add(mesh(lanePaint(),new THREE.MeshStandardMaterial({color:'#92928b',roughness:.94})));

  const road = mesh(upperDeck(), remat(M.asphalt, 1, 1050));
  road.name = 'road-deck';
  grp.add(road);
  grp.add(mesh([box(0.2, 0.5, L, -(deckW / 2 - 0.1), ROAD - 0.7, 0),
    box(0.2, 0.5, L, deckW / 2 - 0.1, ROAD - 0.7, 0)], M.curb));

  const rail = railings();
  grp.add(mesh(rail.posts, M.railing),mesh(rail.pickets,M.steelDark));
  grp.add(mesh(rail.sun, M.reliefSun));
  grp.add(mesh(rail.scene, M.reliefScene));
  grp.add(mesh(rail.worker, M.reliefWorker));

  /* 层间的一圈边缘光：不是考据里的灯具，只为让双层在夜里读得出来（写意） */
  const edge = new THREE.Group();
  edge.name = 'bridge-outline';

  // Subtle maintenance/decorative light points only; none on the chord itself.
  const accents=[];
  for(const z of PIERS) for(const x of [-9.8,9.8])
    accents.push(box(.32,.09,.48,x,bottomY-.59,z));
  edge.add(mesh(accents,M.outlineCold));
  grp.add(edge);

  scene.add(grp);

  return {
    group: grp,
    edge,
    topY,
    bottomY,
    roadTop: ROAD,
    railTop: RAILD,
    spans: SPANS,
    setOutline(on) { edge.visible = on; },
  };
}
