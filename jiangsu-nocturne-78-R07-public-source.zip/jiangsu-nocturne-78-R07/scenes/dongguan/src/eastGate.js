// 东门城楼：东面广场向西穿单券进街，另于河岸留东关古渡。
import * as THREE from 'three';
import { STREET, EAST_GATE } from './data.js';
import { M, lit, box, mesh, quad, floorQuad, glow } from './kit.js';
import * as T from './textures.js';
const y0=STREET.deck;
const X=EAST_GATE;
const w=23.4, depth=7.4, ry=3.65, mid=4.45, H=12.45;
const point=(u,y,x)=>[x,y+y0,u];
const q=(p,n,scale=1)=>quad(p,{dir:n,uv:p.map(([x,y,z])=>[n[2]?x*scale:z*scale,n[1]?x*scale:y*scale])});
const gbox=(cx,y,z,sx,h,sz)=>box(sx,h,sz,cx,y+y0,z);
const hash=(i)=>.5+.5*Math.sin(i*37.749+Math.cos(i*93.79));
function brickmap(tone){
  const c=document.createElement('canvas');c.width=c.height=512;const ctx=c.getContext('2d');
  ctx.fillStyle='#36383b';ctx.fillRect(0,0,512,512);
  for(let y=0;y<16;y++)for(let x=-1;x<10;x++){
    const i=y*43+x,t=73+Math.floor(hash(i)*34)+tone;
    const u=x*56+(y%2)*27;ctx.fillStyle=`rgb(${t-4},${t},${t+3})`;ctx.fillRect(u,y*32+1,54,29);
    ctx.fillStyle='#76818b42';ctx.fillRect(u,y*32+1,54,2);
    ctx.fillStyle='#25282b60';ctx.fillRect(u,y*32+28,54,2);
    for(let n=0;n<30;n++){
      ctx.fillStyle=n%3?'#6d707527':'#25232c28';ctx.fillRect(u+hash(5*i+n*12)*52,y*32+2+25*hash(11*i+n*17),2+6*hash(i+n),1+hash(i+3*n)*2);
    }
  }
  const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=4;return t;
}
function signText(){
  const c=document.createElement('canvas');c.width=512;c.height=176;
  const x=c.getContext('2d');x.fillStyle='#474943';x.fillRect(0,0,512,176);x.strokeStyle='#a99b75';x.lineWidth=8;x.strokeRect(11,11,490,154);
  x.textAlign='center';x.textBaseline='middle';x.font='700 114px "Noto Serif CJK SC", serif';x.fillStyle='#d2b98c';
  // Viewer-left to viewer-right; plaque is traditionally read right to left.
  x.fillText('關',174,93);x.fillText('東',338,93);
  const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;
}
function curve(u){return mid+Math.sqrt(Math.max(0,ry*ry-u*u));}
function brickPlatform(group){
  const face=[],arch=[],ringVariation=[],coping=[],walls=[],inner=[];
  for(const side of [-1,1]){
    const xx=side*depth/2;
    const outward=[side,0,0];
    // Split at both jambs, never fill the opening with a masked plane.
    for(const k of [-1,1]){
      const lo=k*ry,hi=k*(w-.75);
      face.push(q([point(lo,0,xx),point(hi,0,xx),point(hi-k*.74,H,xx),point(lo,H,xx)],outward,.38));
      const w2=k*(w-.75),w1=k*(w-1.49);
      walls.push(q([point(w2,0,-depth/2),point(w2,0,depth/2),point(w1,H,depth/2),point(w1,H,-depth/2)],[0,0,k],.38));
    }
    const N=28;
    for(let i=0;i<N;i++){
      const a=Math.PI*(1-i/N),b=Math.PI*(1-(i+1)/N),u=ry*Math.cos(a),v=ry*Math.cos(b);
      face.push(q([point(u,curve(u),xx),point(v,curve(v),xx),point(v,H,xx),point(u,H,xx)],outward,.38));
      const rr=ry+.37,x=xx+side*.056;
      const t=.010, aa=a-t,bb=b+t;
      (i%4===0||i%7===1?ringVariation:arch).push(q([point(ry*Math.cos(aa),curve(ry*Math.cos(aa)),x),point(ry*Math.cos(bb),curve(ry*Math.cos(bb)),x),point(rr*Math.cos(bb),mid+rr*Math.sin(bb),x),point(rr*Math.cos(aa),mid+rr*Math.sin(aa),x)],outward,.42));
      if(side===1){
        const under=[0,-Math.sin((a+b)/2),-Math.cos((a+b)/2)];
        inner.push(q([point(u,curve(u),-depth/2),point(v,curve(v),-depth/2),point(v,curve(v),depth/2),point(u,curve(u),depth/2)],under,.46));
      }
    }
    for(const s of [-1,1]){
      arch.push(q([point(ry*s,0,xx+side*.056),point((ry+.37)*s,0,xx+side*.056),point((ry+.37)*s,mid,xx+side*.056),point(ry*s,mid,xx+side*.056)],outward,.42));
      if(side===1)inner.push(q([point(ry*s,0,-depth/2),point(ry*s,0,depth/2),point(ry*s,mid,depth/2),point(ry*s,mid,-depth/2)],[0,0,-s],.42));
    }
    coping.push(gbox(xx,H-.16,0,.48,.26,2*(w-1.0)),gbox(xx,H+.12,0,.57,.26,2*(w-1.28)));
    // Low, closely spaced crenellations, distinct from lit eaves above.
    for(let i=0;i<29;i++){
      const z=(i-14)*1.48;
      coping.push(gbox(xx,H+.30,z,.51,.56,.78),gbox(xx,H+.79,z,.64,.12,.94));
    }
    const b=new THREE.Mesh(new THREE.PlaneGeometry(2.3,.78),new THREE.MeshBasicMaterial({map:signText(),color:0x96918a,toneMapped:false}));
    b.position.set(xx+side*.067,y0+9.23,0);b.rotation.y=side*Math.PI/2;group.add(b);
  }
  const mat=lit('#869197',{map:brickmap(0),rough:.92,emissive:'#333f53',ei:.68,side:THREE.DoubleSide});
  const voussoir=lit('#828d8e',{map:brickmap(16),rough:.89,emissive:'#3f4448',ei:.38,side:THREE.DoubleSide});
  const stone=lit('#62676b',{map:brickmap(-10),rough:.96,emissive:'#303138',ei:.38,side:THREE.DoubleSide});
  const base=mesh(face,mat);base.name='east-gate-gray-rampart';
  const portal=mesh(inner,stone);portal.name='east-gate-open-vault';
  const head=mesh(arch,voussoir);head.name='east-gate-single-voussoir-ring';
  group.add(base,portal,head,mesh(ringVariation,lit('#96948a',{map:brickmap(17),rough:.92,emissive:'#4a4747',ei:.48,side:THREE.DoubleSide})),mesh(walls,mat),mesh(coping,stone),mesh([gbox(0,H-.25,0,depth+.45,.32,(w-1.3)*2)],stone));
  for(const side of [-1,1]){
    // A slight stepped buttress against the plain dark wall on each end.
    const ties=[];
    for(let k=0;k<4;k++)ties.push(gbox(.4,0,side*(w+.6+k*.86),depth*1.45,.8+H-2.5-k*.81,1.9));
    group.add(mesh(ties,stone));
  }
}
function roofSpan(cx,y,ww,dd,rise){
  const pos=[],uv=[],idx=[],trim=[],nu=60,nv=18,es=[];
  for(let i=0;i<=nv;i++)for(let j=0;j<=nu;j++){
    const x=((i/nv)*2-1)*dd*.5,z=((j/nu)*2-1)*ww*.5,u=Math.abs(x)/(dd*.5),v=Math.abs(z)/(ww*.5);
    const hip=Math.max(0,(v-.74)/.26);
    const t=Math.max(u,hip*.89);
    const lift=Math.pow(u,7)*Math.pow(v,8)*rise*.44;
    const h=rise*(1-Math.sqrt(t)) + lift;
    pos.push(cx+x,y+y0+h,z);uv.push(z/13,t*.93);
    if(i===0||i===nv)es.push([cx+x,y+h,z]);
  }
  for(let i=0;i<nv;i++)for(let j=0;j<nu;j++){const a=(nu+1)*i+j,b=a+nu+1;idx.push(a,a+1,b,b,a+1,b+1);}
  const geom=new THREE.BufferGeometry();geom.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geom.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geom.setIndex(idx);geom.computeVertexNormals();
  const lip=[];
  for(let s=0;s<2;s++){
    for(let j=1;j<=nu;j++){
      const a=es[s*(nu+1)+j-1],b=es[s*(nu+1)+j];
      lip.push(gbox(a[0],Math.min(a[1],b[1])-.06,(a[2]+b[2])/2,.14,.10,Math.abs(b[2]-a[2])+.014));
      if(j%2===0)trim.push(gbox(a[0]+(s?1:-1)*.025,Math.min(a[1],b[1])-.02,b[2],.15,.037,.053));
    }
  }
  return {geom,lip,trim};
}
function tower(group){
  const columns=[],bal=[],trim=[],tiles=[],woods=[],screens=[],beams=[],caps=[],lamps=[];
  const brown=lit('#664637',{map:M.wood.map,rough:.88,emissive:'#4d2d15',ei:.32});
  const shadow=lit('#3d2a20',{map:M.wood.map,rough:.94,emissive:'#392514',ei:.3});
  const cool=lit('#544e49',{rough:.89,emissive:'#353641',ei:.28});
  const disk=lit('#615b58',{map:M.roof.map,rough:.89,emissive:'#51433f',ei:.39,side:THREE.DoubleSide});
  const luminous=lit('#b37443',{emissive:'#e6a65d',ei:1.32,rough:.9});
  for(const tier of [
    {b:13.23,top:17.1,len:23,deep:9.9,roofW:27.7,roofD:12.0,r:2.42,slots:6},
    {b:17.9,top:20.25,len:19.5,deep:7.2,roofW:22.8,roofD:9.2,r:2.12,slots:7},
  ]){
    const {b,top,len,deep,roofW,roofD,r,slots}=tier;
    woods.push(gbox(0,b-.1,0,deep+1.5,.20,len+1.15));
    for(const s of [-1,1]){
      const x=s*(deep/2-.48);
      beams.push(gbox(x,top-.41,0,.43,.52,len+.26));
      caps.push(gbox(x,top-.44,0,.64,.11,len+.54));
      for(let i=0;i<=slots;i++){
        const z=-len/2+len*i/slots;
        columns.push(gbox(x,b,z,.32,top-b-.26,.34));
        columns.push(gbox(x,top-.87,z,.62,.19,.68),gbox(x,top-.66,z,.77,.21,.91));
        for(const d of [-1,1])caps.push(gbox(x+d*.16,top-.92,z,.2,.14,.97));
        if(i===slots)continue;
        const p=z+len/slots*.5;
        bal.push(gbox(x,b+.25,p,.11,.48,len/slots-.30));
        woods.push(gbox(x,b+.7,p,.21,.09,len/slots-.28));
        screens.push(gbox(x-s*.75,b+.81,p,.10,top-b-1.27,len/slots-.40));
        for(let j=0;j<10;j++)woods.push(gbox(x-s*.67,b+.98,z+(j+1)*len/(slots*11),.11,top-b-1.61,.046));
        if(b<14&&i%2===1){
          const l=new THREE.SphereGeometry(.187,10,7);l.scale(.92,1.12,1).translate(x+s*.32,y0+top-.81,p);lamps.push(l.toNonIndexed());
          woods.push(gbox(x+s*.33,top-.65,p,.031,.29,.031));
        }
      }
      for(let j=0;j<3;j++)beams.push(gbox(0,top-.39,s*(len/2-.24-j*.13),deep+.65,.15,.14));
    }
    const rf=roofSpan(0,top,roofW,roofD,r);tiles.push(rf.geom);trim.push(...rf.trim);beams.push(...rf.lip);
    caps.push(gbox(0,top+r-.03,0,.25,.26,len*.61),gbox(0,top+r+.10,-len*.314,.28,.35,.49),gbox(0,top+r+.10,len*.314,.28,.35,.49));
  }
  const m=mesh(tiles,disk);m.name='east-gate-double-eaves';
  group.add(m,mesh(beams,brown),mesh(bal,cool),mesh(woods,shadow),mesh(screens,lit('#503426',{emissive:'#805c39',ei:.28})),mesh(columns,brown),mesh(caps,shadow),mesh(trim,luminous));
  const lmat=glow('#d47d37',.97);
  group.add(mesh(lamps,lmat));
  const fixtures=[];
  for(const side of [-1,1]){
    for(const [z,wat] of [[-9,43],[0,48],[9,43]]){
      const l=new THREE.PointLight(0xffbe76,wat,13,1.8);l.position.set(side*6.9,y0+16.35,z);group.add(l);fixtures.push([l,wat]);
    }
    for(const z of [-16.0,-7,9,17.0]){
      const l=new THREE.PointLight(0x9abbdf,33,18,1.72);l.position.set(side*8.9,y0+2.49,z);group.add(l);fixtures.push([l,33]);
    }
    const l=new THREE.PointLight(0xffbd8a,19,10,1.65);l.position.set(side*1.9,y0+4.53,-.85);group.add(l);fixtures.push([l,17]);
  }
  return {fixtures,lmat,lampColor:lmat.color.clone()};
}
export function buildEastGate(scene){
  const g=new THREE.Group();g.position.x=X;g.name='east-gate';scene.add(g);
  brickPlatform(g);
  const {fixtures,lmat,lampColor}=tower(g);
  const plaza=mesh([floorQuad({x0:319,x1:372,z0:-25.8,z1:25.8,y:y0-.026,tile:[11,11],origin:[320,0]})],M.stoneP);
  plaza.name='east-gate-plaza-ground';scene.add(plaza);
  const approach=mesh([floorQuad({x0:337.71,x1:369.72,z0:-3.43,z1:3.43,y:y0+.022,tile:[8,8],origin:[338,0]})],
    lit('#878786',{map:T.blockPaving({base:'#726e67'}),rough:.94,emissive:'#4e4944',ei:.32}));
  approach.name='east-gate-approach-slabs';scene.add(approach);
  return {root:g,setLantern(k){for(const [l,v] of fixtures)l.intensity=v*(.16+.84*k);lmat.color.copy(lampColor).multiplyScalar(.11+.89*k);}};
}
