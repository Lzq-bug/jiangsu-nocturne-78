/**
 * 露天老子铜像：本景主景。
 *
 * 可考的尺只有一套净高：像 33 米、坐像法身 28 米、基座直径 18.8 米、重 106 吨、
 * 226 块特制紫铜板铆焊、1996 动工 1998 落成、2000 年获吉尼斯纪录；座下是老君殿，
 * 身后贴山壁建 120 米东西向文化长廊，两侧为玉皇殿、王母殿，赵朴初题"道法自然"。
 * 坐像的开膝厚袍、长须、扇与捻须手按元符万宁宫照片和景区资料；细衣纹和面相为数字演绎；
 * "81 米／33.33 米／取意八十一章／朝向／设计者"无据，模型与文案都不采用。
 */
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { M, glow, lit, mesh, box, chineseRoof, pillarGeo, plaqueMesh, registerOccluder, rand } from '../../src/kit.js';
import * as TX from '../../src/textures.js';
import * as T from './textures.js';
import { LAOZI } from './data.js';
import { padTop } from './relief.js';
import { hall } from './buildings.js';

const scaled = (geo, sx, sy, sz, x = 0, y = 0, z = 0) => {
  geo.scale(sx, sy, sz);
  geo.translate(x, y, z);
  return geo;
};

// Portrait-facing +Z: fan is on the photograph's left, raised hand near beard.
// Cross sections keep the visual continuity of a single draped hollow casting;
// costume folds are independent relief, not bright concentric bands.
const V = (x,y,z)=>new THREE.Vector3(x,y,z);
const sph=(x,y,z,w,h,d)=>scaled(new THREE.SphereGeometry(1,20,13),w,h,d,x,y,z);
function stroke(points,r=.18){
  return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>V(...p))),22,r,8,false);
}
function bodyShell(sections){
  const pos=[],uv=[],idx=[];const n=40;
  for(const [j,[y,cx,cz,rx,rz,fold]] of sections.entries()){
    for(let k=0;k<=n;k++){
      const a=k*Math.PI*2/n, d=1+(fold||0)*(.55*Math.cos(a*7+.22*y)+.45*Math.sin(a*4-.14*y));
      pos.push(cx+Math.cos(a)*rx*d,y,cz+Math.sin(a)*rz*d);uv.push(k/n,j/(sections.length-1));
    }
  }
  for(let j=0;j<sections.length-1;j++)for(let k=0;k<n;k++){
    const a=j*(n+1)+k,b=a+n+1;idx.push(a,b,a+1,a+1,b,b+1);
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();return g;
}
function fanParts(parts, relief){
  const outline=new THREE.Shape();
  outline.moveTo(0,-2);outline.bezierCurveTo(-.6,-1.2,-1.9,-.2,-2.3,1.0);
  outline.bezierCurveTo(-3,2.55,-2.0,3.15,-1.2,3.54);
  outline.bezierCurveTo(-.7,4.15,.28,3.46,.8,3.74);
  outline.bezierCurveTo(1.98,3.69,2.71,3.0,2.32,1.58);
  outline.bezierCurveTo(2.1,.73,1.2,-.8,0,-2);
  const fan=new THREE.ExtrudeGeometry(outline,{depth:.31,bevelEnabled:true,bevelThickness:.14,bevelSize:.16,bevelSegments:3,curveSegments:18,steps:1});
  const head=new THREE.Matrix4().compose(V(-6.95,16.4,4.9),new THREE.Quaternion().setFromEuler(new THREE.Euler(-.17,.21,.44)),V(1.13,1.14,1));
  parts.push(fan.applyMatrix4(head));
  for(let q=-4;q<=4;q++){
    const l=q/4;
    relief.push(stroke([[0,-1.57,.49],[l*.82,.6,.5],[l*1.6,2.22,.5],[l*1.87,2.84-.43*Math.abs(l),.48]],.057).applyMatrix4(head));
  }
  relief.push(stroke([[-2.48,10,4.6],[-4.6,11.9,4.88],[-5.67,13.2,5.13],[-6.35,14.78,5.25]],.17));
}
function figureGeo() {
  const parts=[], relief=[];
  parts.push(bodyShell([
    [.04,0,.14,8.05,4.75,.04],[.48,0,.14,8.56,4.75,.07],[1.37,0,.3,8.28,4.86,.09],
    [2.56,0,.11,8.18,4.60,.08],[3.8,-.05,-.08,7.69,4.29,.10],[5.1,-.12,-.26,6.08,3.83,.09],
    [6.42,-.06,-.23,4.92,3.29,.09],[9.1,.04,-.37,4.64,3.06,.05],
    [12.6,0,-.43,4.23,2.99,.04],[15.57,0,-.54,4.55,2.88,.08],
    [17.05,0,-.44,4.25,2.68,.05],[18.5,.18,-.30,3.26,2.30,.04],[19.6,.23,-.18,2.12,1.72,.03],
  ]));
  parts.push(sph(-6.2,3.15,1.0,2.29,2.21,2.47),sph(6.34,3.22,.82,2.22,2.17,2.38));
  parts.push(sph(-2.35,1.55,4.14,1.73,.9,1.35),sph(2.36,1.35,4.55,1.8,.84,1.1));
  // Asymmetric sleeves: left descends to fan grip and right curls up toward beard.
  for(const [x,y,z,w,h,d,ang] of [
    [-4.20,14.85,.61,1.72,3.22,1.75,-.29],[-5.03,12.7,1.8,1.62,2.47,1.41,-.56],[-3.76,11.15,3.25,1.31,2.16,1.24,-.81],
    [4.10,14.78,.45,1.75,3.65,1.56,.28],[5.13,12.62,1.44,1.44,2.4,1.51,.26],
    [4.26,13.42,2.89,1.4,2.38,1.48,-.38],[3.1,15.44,3.51,1.04,1.71,1.05,-.36],
  ]){
    const ell=new THREE.SphereGeometry(1,20,14).scale(w,h,d).rotateZ(ang).translate(x,y,z);parts.push(ell);
  }
  parts.push(sph(-4.2,11.88,4.37,.84,.68,.69),sph(2.31,16.9,4.15,.78,1.04,.65));
  for(let i=0;i<4;i++){
    const k=i*.24;
    relief.push(stroke([[2.27+k,16.39,4.48],[2.23+k*.5,17.05+.15*i,4.66],[1.92+k*.42,17.60-.14*i,4.58]],.13));
    relief.push(stroke([[-4.40+k,11.37,4.76],[-4.52+k,11.77,4.94],[-4.66+k,12.02,4.9]],.13));
  }
  // Human portrait proportions, brow/lids, moustache and beard as cast relief.
  parts.push(sph(.17,19.91,.12,1.67,1.68,1.29),sph(.20,22.53,.22,2.22,2.71,2.16),
    sph(.2,21.61,.95,1.75,1.83,1.7),sph(.17,23.45,.86,2,1.28,1.74),
    sph(.18,21.98,2.52,.40,1.02,.57),sph(.17,21.38,2.61,.56,.32,.55));
  for(const a of [-1,1]){
    parts.push(sph(.2+a*2.05,21.98,.5,.39,.87,.46),sph(.2+a*1.17,21.66,1.88,.52,.63,.53));
    relief.push(stroke([[.2+a*.37,22.72,2.30],[.2+a*.88,22.79,2.50],[.2+a*1.41,22.67,2.28]],.13));
    relief.push(stroke([[.2+a*.51,22.40,2.52],[.2+a*.91,22.34,2.65],[.2+a*1.35,22.36,2.39]],.082));
    relief.push(stroke([[.2+a*.23,21.13,2.87],[.2+a*.69,20.96,3.03],[.2+a*1.16,20.61,2.88],[.2+a*1.42,20.22,2.59]],.15));
  }
  parts.push(bodyShell([[15.64,.26,3.42,.10,.13],[16.57,.22,3.60,.36,.23,.09],[18.16,.20,3.18,.73,.45,.15],
    [19.34,.20,2.80,1.09,.49,.13],[20.26,.20,2.45,1.28,.59,.14],[20.93,.2,2.11,1.38,.36,.1]]));
  for(let i=0;i<7;i++){
    const q=(i-3)/3;
    relief.push(stroke([[.2+q*1.26,20.6,2.82],[.15+q*.91,19.45,3.13],[.23+q*.63,18.23,3.61],[.25+q*.22,16.54+Math.abs(q)*.52,3.8]],.095));
  }
  parts.push(sph(.19,24.26,.14,1.91,1.36,1.87),sph(.17,25.48,-.29,.96,1.29,1.16),sph(.18,26.78,-.34,.73,1.22,.77));
  // Folds follow the knees and the opening of the crossed, diagonally hung robe.
  for(const [k,P] of [
    [0,[[3.52,18.8,1.18],[2.62,16.24,2.13],[.61,12.28,2.83],[-2.20,9.14,2.74],[-4.12,5.39,3.36],[-6.8,3.26,3.3]]],
    [1,[[-2.43,18.83,1.96],[-1.73,16.13,2.24],[-.33,12.93,2.86],[1.4,10.20,2.73],[3.72,6.95,2.96],[6.85,3.04,3.91]]],
    [2,[[-7.9,2.91,1.14],[-7.35,3.44,2.69],[-5.39,3.54,3.74],[-3.98,3.12,4.48],[-2.6,2.52,4.76],[.60,1.81,5.13]]],
    [3,[[7.88,2.81,1.26],[7.26,3.33,2.75],[5.94,3.13,4.03],[4.62,2.72,4.58],[2.55,2.23,4.83],[.28,1.48,5.04]]],
    [4,[[5.3,12.72,3.61],[4.73,11.79,3.83],[4.12,10.86,3.71],[3.61,9.35,3.21],[3.83,7.13,3.24]]],
    [5,[[-5.26,14.04,3.12],[-4.57,12.92,3.63],[-3.62,12.30,3.83],[-2.91,11.61,3.04]]],
  ])relief.push(stroke(P,k<4?.18:.14));
  fanParts(parts,relief);
  const merge = arr=>mergeGeometries(arr.map(g=>g.index?g.toNonIndexed():g));
  return {body:merge(parts).scale(1.06,1,1.04),details:merge(relief).scale(1.06,1,1.04)};
}

/** See 2017 front pixels: clipped-corner stepped stone below bronzed body. */
function podiumGeo(d,h){
  const r=d/2;
  const p=[];
  for(const [rb,rt,hh,y] of [[r,r,.45,.225],[r-.28,r-.4,.55,.72],[r-.46,r-.63,h-2.9,(h-2.9)/2+1],[r-.22,r-.17,.48,h-1.61],[r-.15,r-.42,.66,h-1.1],[r-.58,r-.68,.57,h-.42]]){
    p.push(new THREE.CylinderGeometry(rt,rb,hh,8,1,false,Math.PI/8).translate(0,y,0));
  }
  return mergeGeometries(p);
}

function buildGallery(site) {
  // 身后贴山壁的 120 米东西向文化长廊：列柱 + 墙身 + 屋顶，墙上是分段的壁面灯
  const g = new THREE.Group();
  const len = site.gallery.len, h = site.gallery.h;
  const back = mesh(box(len, h, 1.2, 0, h / 2, -1.6), lit('#7e8795', { map: TX.stone('#6d7583'), rough: 0.94, emissive: '#12161d', ei: 0.34 }));
  g.add(back);
  const seg = 11;
  for (let i = 0; i < seg; i++) {
    const x = -len / 2 + (len * (i + 0.5)) / seg;
    const panel = new THREE.Mesh(new THREE.PlaneGeometry((len / seg) * 0.74, h * 0.56),
      new THREE.MeshBasicMaterial({ map: TX.lattice(4, 3, '#3b2a18', '#ffcf92'), toneMapped: false, transparent: true, opacity: 0.9 }));
    panel.position.set(x, h * 0.46, -0.9);
    g.add(panel);
    const c = new THREE.Mesh(pillarGeo(h, 0.34), M.pillar);
    c.position.set(-len / 2 + (len * i) / seg, 0, 1.3);
    g.add(c);
  }
  const roof = new THREE.Mesh(chineseRoof({ width: len + 2, depth: 5.2, height: 1.8, ridgeRatio: 0.98, curve: 0.55, eaveLift: 0.4, segU: 60, segV: 10 }), M.roof);
  roof.position.y = h;
  g.add(roof);
  g.position.set(site.x, padTop(site.pad), site.z + site.gallery.dz);
  return g;
}

export function buildLaozi(scene, anchors = {}) {
  const grp = new THREE.Group();
  const y0 = padTop(LAOZI.pad);
  const bronze = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#b19672'), map: T.bronzePanels(),
    roughness: 0.62, metalness: 0.52,
    emissive: new THREE.Color('#49341d'), emissiveIntensity: 0.43,
  });

  const pod = new THREE.Mesh(podiumGeo(LAOZI.podiumD, LAOZI.podiumH),
    lit('#a8aeb9', { map: TX.stone('#8a909c'), rough: 0.9, emissive: '#0e1218', ei: 0.32 }));
  pod.position.set(0, 0, 0);
  grp.add(pod);

  const reliefBronze=lit('#7f624b',{rough:.77,metal:.49,emissive:'#2b2118',ei:.23});
  const drapeBase = new THREE.Mesh(new THREE.CylinderGeometry(8.24,8.55,.68,36),reliefBronze);
  drapeBase.position.y=LAOZI.podiumH+.26;grp.add(drapeBase);
  const geo=figureGeo();
  const fig=new THREE.Mesh(geo.body,bronze);
  const relief=new THREE.Mesh(geo.details,reliefBronze);
  fig.position.y=relief.position.y=LAOZI.podiumH+.49;
  fig.name='maoshan-laozi-seated-fan';relief.name='maoshan-laozi-chasing';grp.add(fig,relief);

  const D=LAOZI.podiumD/2-.59;
  const surround=mesh(box(7.55,5.75,.76,0,2.85,D-.04),M.stoneDressed);
  grp.add(surround);
  const door = new THREE.Mesh(new THREE.PlaneGeometry(4.25,4.5),lit('#422517',{rough:.8,emissive:'#613417',ei:.32}));
  door.position.set(0,2.54,D+.38);grp.add(door);
  for(const x of [-2.12,0,2.12])grp.add(mesh(box(.10,4.54,.12,x,2.54,D+.44),M.pillar));
  const motto = plaqueMesh('道法自然',6.1,1.44,{bg:'#23232a',fg:'#eac687',dir:'h'});
  motto.position.set(0,5.2,D+.41);grp.add(motto);
  const key=new THREE.PointLight('#eed0aa',1790,107,2);key.position.set(-13,24,18);grp.add(key);
  const fill=new THREE.PointLight('#f2cdae',650,89,2);fill.position.set(12,19,15);grp.add(fill);
  key.name='oldmaster-face-key';fill.name='oldmaster-face-fill';
  grp.position.set(LAOZI.x, y0, LAOZI.z);
  grp.rotation.y = LAOZI.facing;
  scene.add(registerOccluder(grp, 14, new THREE.Vector3(LAOZI.x, 0, LAOZI.z)));

  // 两侧玉皇殿、王母殿（名可考，形制写意）
  for (const f of LAOZI.flanks) {
    const b = hall({ w: 11, d: 7.4, h: 6.4, bays: 3, name: f.name }, { palette: 'gray' });
    b.position.set(LAOZI.x + f.dx, y0, LAOZI.z + 6);
    scene.add(b);
  }
  scene.add(buildGallery(LAOZI));

  // 像前的拜坛与长明灯位
  const altar = mesh(box(7, 1.1, 3.4, 0, 0.55, 0), M.stoneDressed);
  altar.position.set(LAOZI.x, y0, LAOZI.z + 15);
  scene.add(altar);
  anchors.laozi = { x: LAOZI.x, y: y0 + LAOZI.podiumH + LAOZI.bodyH + .49, z: LAOZI.z, base: y0 };
  anchors.laoziFeet = [LAOZI.x, y0 + LAOZI.podiumH + 1.2, LAOZI.z];
  anchors.lampRing = Array.from({ length: 10 }, (_, i) => {
    const a = Math.PI * (0.12 + 0.76 * (i / 9));
    return [LAOZI.x + Math.sin(a) * 14, y0 + 0.9, LAOZI.z + Math.cos(a) * 14];
  });
  return {grp,bronze,figure:fig,modelLights:[{light:key,power:1790},{light:fill,power:650}],metrics:{bodyHeight:28,fan:true,beardHand:true,podiumDiameter:18.8}};
}
