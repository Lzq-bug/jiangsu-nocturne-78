import * as THREE from 'three';
import { WATER_Y } from './water.js';

const positions = [0, -0.63, -0.94];

/** Teaching overlay at the north face of the existing stone arch. */
export function buildArchGauge(scene, arch) {
  const root = new THREE.Group();
  root.name = 'jiangcun-clearance-gauge';
  root.visible = false;
  scene.add(root);
  const teal = new THREE.MeshBasicMaterial({ color: '#62e8cd' });
  const cream = new THREE.MeshBasicMaterial({ color: '#ffe2a5' });
  const soft = new THREE.MeshBasicMaterial({ color: '#d9fff5' });
  const rod = new THREE.Mesh(new THREE.BoxGeometry(.075,1,.075), teal);
  const foot = new THREE.Mesh(new THREE.BoxGeometry(.65,.055,.16), cream);
  const tip = new THREE.Mesh(new THREE.SphereGeometry(.17,16,10), cream);
  const notch = new THREE.BoxGeometry(1,.035,.060);
  const ticks = Array.from({length: 12}, (_,i)=>{
    const line = new THREE.Mesh(notch, soft);
    line.scale.x = i%2===0?.39:.25;
    return line;
  });
  root.add(rod,foot,tip,...ticks);
  root.position.z=arch.at+arch.half+.24;
  return {
    close() { root.visible=false; },
    place(i) {
      const x=arch.opening * positions[i];
      const h=arch.clearanceAt(x)-WATER_Y;
      root.position.x=x;
      foot.position.y=WATER_Y+.085;
      tip.position.y=WATER_Y+h-.12;
      rod.position.y=WATER_Y+h*.5;
      rod.scale.y=h-.10;
      ticks.forEach((line,j)=>{
        const y=.32+j*.38;
        line.visible=y<h-.30;
        line.position.y=WATER_Y+y;
      });
      root.visible=true;
      return Math.round(h/(arch.clearanceAt(0)-WATER_Y)*100);
    },
  };
}
