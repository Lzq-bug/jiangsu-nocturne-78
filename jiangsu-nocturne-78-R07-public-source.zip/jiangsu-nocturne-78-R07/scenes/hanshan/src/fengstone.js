import * as THREE from 'three';
import { M, box, mesh, plaqueMesh } from './kit.js';
import { CANAL } from './data.js';

/** Granite arch generated as a genuine full-width clear opening, with keyed
 * voussoirs, stepped deck, two elevations, and an unbroken east landing. */
export function graniteCrossing({ id, title, z, span, rise, half, opening, spring, crown, gateX }) {
  const g = new THREE.Group();
  g.name = id + '-granite';
  const Q = CANAL.deckY;
  const edge = span + 0.38;
  const top = x => Q + 0.18 + rise * Math.max(0, 1 - (Math.abs(x) / span) ** 1.48) ** 1.15;
  const ell = (a, pad = 0) => [Math.cos(a) * (opening + pad), spring + Math.sin(a) * (crown - spring + pad)];
  const face = new THREE.Shape();
  face.moveTo(-edge, -0.28);
  face.lineTo(-opening, -0.28);
  face.lineTo(-opening, spring);
  for (let j = 1; j <= 52; j++) face.lineTo(...ell(Math.PI - j * Math.PI / 52));
  face.lineTo(opening, -0.28);
  face.lineTo(edge, -0.28);
  for (let j = 0; j <= 52; j++) {
    const x = edge - (2 * edge * j) / 52;
    face.lineTo(x, top(x) - 0.14);
  }
  face.closePath();
  const solid = new THREE.ExtrudeGeometry(face, { depth: half * 2, bevelEnabled: false });
  solid.translate(0, 0, z - half);
  const bridge = new THREE.Mesh(solid, M.stoneDressed);
  bridge.castShadow = bridge.receiveShadow = true;
  g.add(bridge);

  const masonry = [0x737777, 0x777977, 0x676c6a, 0x7f817d, 0x70716e].map(color =>
    new THREE.MeshStandardMaterial({ color, roughness: 0.94 }));
  const faceStones = masonry.map(() => []);
  const treads = [];
  const count = id === 'fengqiao' ? 34 : 28;
  for (let i = 0; i < count; i++) {
    const dx = 2 * span / count, x = -span + (i + .5) * dx;
    treads.push(box(dx + .012, .16, half * 2 - .24, x, top(x) + .04, z));
  }
  g.add(mesh(treads, M.stone));

  for (const side of [-1, 1]) {
    const zz = z + side * half;
    const n = id === 'fengqiao' ? 25 : 21;
    for (let j = 0; j < n; j++) {
      const a = j * Math.PI / n + .009, b = (j + 1) * Math.PI / n - .009;
      const width = id === 'fengqiao' ? .44 : .30;
      const wedge = new THREE.Shape();
      wedge.moveTo(...ell(a));
      for (let k = 1; k <= 3; k++) wedge.lineTo(...ell(a + (b - a) * k / 3));
      for (let k = 3; k >= 0; k--) wedge.lineTo(...ell(a + (b - a) * k / 3, width));
      wedge.closePath();
      const geom = new THREE.ExtrudeGeometry(wedge, { depth: .11, bevelEnabled: false });
      geom.translate(0, 0, zz - (side < 0 ? .105 : .005));
      faceStones[(j * 9 + (side > 0 ? 1 : 2)) % masonry.length].push(geom);
    }
    const rail = [];
    const segs = 26;
    for (let i = 0; i < segs; i++) {
      const dx = 2 * span / segs, x = -span + i * dx, nx = x + dx;
      const y = (top(x) + top(nx)) / 2;
      const zRail = z + side * (half - .14);
      const length = Math.hypot(dx, top(nx) - top(x));
      const rotation = new THREE.Matrix4().makeRotationZ(Math.atan2(top(nx) - top(x), dx));
      const h = id === 'fengqiao' ? .73 : .54;
      const panel = new THREE.BoxGeometry(length * .995, h, .28);
      panel.applyMatrix4(rotation).translate(x + dx / 2, y + h * .47, zRail);
      rail.push(panel);
      const cap = new THREE.BoxGeometry(length * 1.04, .11, .36);
      cap.applyMatrix4(rotation).translate(x + dx / 2, y + h * .95, zRail);
      rail.push(cap);
      if ([0, 6, 12, 18, 25].includes(i)) rail.push(box(.27, h + .18, .39, x, top(x) + h * .52, zRail));
    }
    g.add(mesh(rail, id === 'fengqiao' ? M.stoneDark : M.stoneDressed));

    // Stone courses on the plain wings, positioned only outside the arch or above a full ring.
    for (let row = 0; row < 11; row++) for (let col = -10; col <= 10; col++) {
      const x = (col + .5 * (row % 2)) * 1.43;
      const y = .39 + row * .52;
      if (Math.abs(x) + .68 >= edge || y + .27 > Math.min(top(x - .69), top(x + .69)) - .12) continue;
      const inner = Math.max(0, Math.abs(x) - .70), radius = opening + .51;
      const exclusion = inner >= radius ? -1 : spring + (crown - spring + .51) * Math.sqrt(1 - (inner / radius) ** 2);
      if (y - .25 <= exclusion) continue;
      const stone = box(1.408, .50, .095, x, y, zz + side * .015);
      faceStones[(col * 8 + row * 7 + 95) % masonry.length].push(stone.toNonIndexed());
    }

    const plaque = plaqueMesh(title, 1.28, .40, { dir: 'h', bg: '#575750', fg: '#cbc3ab' });
    plaque.position.set(0, (top(0) + crown) / 2, zz + side * .075);
    plaque.rotation.y = side > 0 ? 0 : Math.PI;
    g.add(plaque);
  }
  for (let i = 0; i < masonry.length; i++) {
    const m = mesh(faceStones[i], masonry[i]);
    m.receiveShadow = true;
    g.add(m);
  }

  // The bridge approach aligns with the gate pass centerline on the east bank,
  // rather than ending at the water edge or teleporting to a separate outpost.
  if (gateX) {
    const dist = gateX - edge;
    const y = top(edge);
    const paved = mesh(box(dist + .48, .46, 2 * half, (gateX + edge) / 2, y - .14, z), M.stoneDressed);
    paved.receiveShadow = true;
    g.add(paved);
    for (const side of [-1, 1]) {
      const low = mesh(box(dist, .49, .35, (gateX + edge) / 2, y + .22, z + side * (half - .13)), M.stone);
      g.add(low);
    }
  }

  // The recessed soffit has arch courses across its actual width,
  // rather than a flat stripe stuck onto the river-facing elevation.
  const lining = [];
  const bands = id === 'fengqiao' ? 10 : 7;
  const subdivisions = 16;
  for (let q = 0; q < bands; q++) for (let j = 0; j < subdivisions; j++) {
    const a = Math.PI * (j + .017) / subdivisions;
    const b = Math.PI * (j + .983) / subdivisions;
    const part = new THREE.Shape();
    part.moveTo(...ell(a, -.075 - .020 * (q % 3)));
    part.lineTo(...ell((a + b)/2, -.075 - .020 * (q % 3)));
    part.lineTo(...ell(b, -.075 - .020 * (q % 3)));
    part.lineTo(...ell(b, .12));
    part.lineTo(...ell((a + b)/2, .12));
    part.lineTo(...ell(a, .12));
    part.closePath();
    const depth = half * 2 / bands;
    lining.push(new THREE.ExtrudeGeometry(part, {depth: depth - .022, bevelEnabled: false})
      .translate(0, 0, z - half + q * depth + .011));
  }
  const soffit = mesh(lining, M.stoneDark);
  soffit.receiveShadow = true;
  g.add(soffit);
  return { group: g, deckY: top, crownY: top(0), at: z, span, half, opening,
    clearanceAt: x => spring + (crown - spring) * Math.sqrt(Math.max(0, 1 - (x / opening) ** 2)) };
}
