/** Build only the 寒山寺 release bundle, using the collection's canonical calibrators
 * on a scratch copy so unrelated native scene lanes are never rewritten. */
import { mkdtemp, copyFile, readdir, rename, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const here = dirname(fileURLToPath(import.meta.url));
const repo = resolve(here, '../../..');
const sceneDir = join(repo, 'public/pano');
const scratch = await mkdtemp(join(tmpdir(), 'hanshan-calibration-'));
const asset = join(sceneDir, 'hanshan.html');
const run = (...args) => execFileSync(process.execPath, args, { cwd: repo, stdio: 'inherit' });
const output = asset + '.build.tmp';
try {
  const names = (await readdir(sceneDir)).filter(name => name.endsWith('.html') && name !== 'hanshan.html');
  await Promise.all(names.map(name => copyFile(join(sceneDir, name), join(scratch, name))));
  run(join(here, 'build-single.mjs'), join(scratch, 'hanshan.html'));
  run(join(repo, 'scenes/tools/refine-native-panorama-look.mjs'), scratch);
  run(join(repo, 'scenes/tools/guard-native-panorama-mode.mjs'), scratch);
  await copyFile(join(scratch, 'hanshan.html'), output);
  await rename(output, asset);
} finally {
  await rm(scratch, { recursive: true, force: true });
  await rm(output, { force: true });
}
