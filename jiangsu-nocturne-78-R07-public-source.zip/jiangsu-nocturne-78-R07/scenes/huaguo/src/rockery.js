import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { SITE, groundAt, SEA } from './data.js';
import { lit, mesh, box, quadGrid, blobGeometry, inscribed, rand, rr } from './kit.js';
import * as T from './textures.js';

/**
 * 西壁的一段：水帘洞的崖、人字形裂隙、崖刻群、娲遗石与一线天，加上海蚀的
 * 崖脚。水帘是一张可以从中间拉开的幕，拉开才看得见洞门与刻石。
 * 坡面往东是往上去的，所以洞腔朝 +X 走，帘挂在洞口以西、落进潭里。
 */

const FACE = lit('#9aa0a3', {
  map: T.rockFace({ meters: 16 }), rough: 0.94, side: THREE.DoubleSide,
  emissive: '#1a232c', ei: 0.5,
});
const BOULDER = lit('#94978f', {
  map: T.granite({ meters: 7 }), rough: 0.93, side: THREE.DoubleSide,
  emissive: '#0b1014', ei: 0.24,
});

const HIGH = 66;           // 崖顶在台地以上多高
const MOUTH_W = 7.2;       // 人字洞口的半宽
const MOUTH_H = 9.4;

export function buildHill(scene) {
  const grp = new THREE.Group();
  grp.name = 'cliff';
  const anchors = [];
  const carvings = [];

  const cave = SITE.cave;
  const mx=cave.x, mz=cave.z+2.5, floorY=155.5;
  const carved=[];
  const lightRock=lit('#a5a196',{map:T.granite({meters:9}),rough:.98,side:THREE.DoubleSide,emissive:'#29313c',ei:.37});
  const shell=lit('#252c34',{rough:.96,side:THREE.DoubleSide,emissive:'#141922',ei:.29});
  const ground=lit('#465050',{rough:.98,side:THREE.DoubleSide,emissive:'#182320',ei:.43});
  const walkway=lit('#9d9b96',{map:T.paving({meters:2.3,base:'#8a897e'}),rough:.91,emissive:'#2a2628',ei:.27});
  const fence=lit('#756148',{rough:.81,emissive:'#32261b',ei:.32});
  // Surround the two joints with an irregular front rock wall; the dark negative
  // space is a geometric opening, with a separate chamber and tiered drainage.
  const rock=(x,y,z,rx,ry,rz,seed,rzRot=.1)=>{
    const source=blobGeometry(1,{detail:3,amp:.135,squash:1,seed});
    source.scale(rx,ry,rz).rotateX(rzRot).rotateZ(Math.sin(seed)*.23).translate(x,y,z);
    const g=source.index?source.toNonIndexed():source;
    const a=g.attributes.position,b=g.attributes.uv,norm=g.attributes.normal,xyz=[],uv=[],normals=[];
    for(let j=0;j<a.count;j+=3){
      const px=(a.getX(j)+a.getX(j+1)+a.getX(j+2))/3;
      const py=(a.getY(j)+a.getY(j+1)+a.getY(j+2))/3;
      const pz=(a.getZ(j)+a.getZ(j+1)+a.getZ(j+2))/3;
      if(px>mx-2.2&&px<mx+20.5&&py>floorY-.42&&py<floorY+8.9&&Math.abs(pz-mz)<7.5-(py-floorY)*.47)continue;
      for(let n=0;n<3;n++){xyz.push(a.getX(j+n),a.getY(j+n),a.getZ(j+n));uv.push(b.getX(j+n),b.getY(j+n));normals.push(norm.getX(j+n),norm.getY(j+n),norm.getZ(j+n));}
    }
    const c=new THREE.BufferGeometry();c.setAttribute('position',new THREE.Float32BufferAttribute(xyz,3));c.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));c.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));
    carved.push(c);
  };
  rock(mx+4,165.1,mz-14,8.2,16.8,10.7,13,-.19);
  rock(mx+6,169.6,mz+15.3,10.2,16,11.02,34,.17);
  rock(mx+5.1,176.1,mz-2.4,8.6,11.5,17.2,41,.20);
  rock(mx+12.8,184.2,mz+.7,14.6,9.7,23.7,61,-.12);
  rock(mx-3.4,160.3,mz-21.4,9.8,11.6,6.3,78,.18);
  rock(mx+1.7,160.3,mz+26.1,11,14.5,8.3,67,.15);
  // Each surface bridges into existing terrain at the back and sides.
  rock(mx+24,175.7,mz-16.7,18.7,25.3,22,81,.15);
  rock(mx+27.4,168.1,mz+17.2,17,24.6,19.4,92,.4);
  rock(mx+23.6,192.2,mz+.9,24.5,26.9,26.9,101,.15);
  grp.add(mesh(carved,lightRock));
  const boundary=[
    [-7.25,0],[-6.3,2.8],[-4.9,4.5],[-2.62,6.77],[-.19,10.05],
    [1.76,7.85],[4.23,5.19],[6.3,2.70],[6.84,.18],
  ];
  const lining=[];
  for(let i=1;i<boundary.length;i++){
    const [z0,y0]=boundary[i-1],[z1,y1]=boundary[i];
    lining.push(quad([mx-.65,floorY+y0,mz+z0],[mx-.65,floorY+y1,mz+z1],
      [mx+14,floorY+y1*.64,mz+z1*.74],[mx+14,floorY+y0*.64,mz+z0*.74]));
  }
  lining.push(quad([mx-2,floorY-.16,mz-7.8],[mx-2,floorY-.16,mz+7.9],[mx+17,floorY,mz+6.1],[mx+18,floorY,mz-6.4]));
  lining.push(quad([mx+18,floorY,mz-7],[mx+18,floorY,mz+7],[mx+18,floorY+8,mz+7],[mx+18,floorY+8,mz-7]));
  const inside=mesh(lining,shell);inside.name='water-curtain-real-cleft';grp.add(inside);
  const sloping=quadGrid((u,v)=>{
     const z=mz-23+u*46, x=mx-22+v*(22.2+1.2*Math.cos(u*7.1));
     const y=146.0+6.45*v + Math.sin(u*Math.PI*2)*1.0+Math.pow(v,3)*(1.2*Math.cos(u*7));
     return [x,y,z];
  },48,27,{spanU:43,spanV:25});
  grp.add(mesh(sloping.clone(),ground));
  // The lower fern-lined apron hides the coarse ground mesh's local opening.
  const fillMeshes=[];
  for(const [x0,x1,z0,z1] of [[-457,-397,105,132],[-452,-397,172,201],[-461,-433,120,190],[-393,-354,103,124],[-394,-357,180,201]]){
    const fill=quadGrid((u,v)=>{
      const x=x0+(x1-x0)*u,z=z0+(z1-z0)*v;
      const w=Math.max(0,1-Math.abs(z-mz)/56)*Math.max(0,1-Math.abs(x-(mx-21))/63);
      return [x,THREE.MathUtils.lerp(groundAt(x,z)-.10,147.5,w*.91),z];
    },22,14,{spanU:x1-x0,spanV:z1-z0});
    fillMeshes.push(fill);
  }
  // Continuous graded banks around the perimeter of the intentional local land cut.
  // The graded middle stays below the cliff and approach, maintaining a real opening.
  for(const [x0,x1,z0,z1,from] of [[-461,-427,104,197,'west'],[-452,-353,100,134,'north'],[-455,-353,175,205,'south'],[-378,-348,106,196,'east']]){
    const collar=quadGrid((u,v)=>{
      const x=x0+(x1-x0)*u,z=z0+(z1-z0)*v;
      const f=from==='west'?u:from==='east'?1-u:from==='south'?1-v:v;
      const k=f*f*(3-2*f);
      const sculpt=from==='east'?151+30*Math.sin(u*.4):143.6+1.06*Math.sin(x*.31)+1.64*Math.sin(z*.71);
      return [x,THREE.MathUtils.lerp(groundAt(x,z)-.38,sculpt,k),z];
    },38,26,{spanU:97,spanV:42});
    fillMeshes.push(collar);
  }
  const sink=quadGrid((u,v)=>{
      const x=-448+86*u,z=113+80*v;
      return [x,141.9-1.8*Math.cos(v*5.2)+Math.sin(u*7.2)*.63,z];
    },42,35,{spanU:85,spanV:80});
  fillMeshes.push(sink);
  grp.add(mesh(fillMeshes,ground));
  const edges=[],plants=[];
  for(let j=0;j<47;j++){
    const side=j%2?1:-1;
    const u=(j%25)/24,x=mx-45+u*57, z=mz+side*(23.8+Math.sin(j*4.9)*4.05);
    const y=151+u*12.5;
    if(Math.hypot(x+430,z-168)<17)continue;
    const g=blobGeometry(4.8+Math.abs(Math.sin(j*3.09))*3.4,{detail:2,amp:.24,squash:.63,seed:j+84});
    g.scale(1.3,.97,.74).translate(x,y-.9,z);edges.push(g);
    plants.push(blobGeometry(1.85+Math.abs(Math.sin(j*2.05))*2.5,{detail:2,amp:.2,squash:.69,seed:j+68}).translate(x,y+2.8,z));
  }
  grp.add(mesh(edges,ground),mesh(plants,lit('#344b41',{rough:.93,emissive:'#203b2e',ei:.34})));
  const pavement=[[-429,150.0,mz+23],[-422,151.3,mz+19],[-414.6,152.9,mz+16.5],[-404.3,154.1,mz+10.5],[-398.2,155.45,mz+5.6],[mx-.7,155.50,mz+2.4]];
  const rail=[],path=[];
  for(let j=0;j<pavement.length-1;j++){
    const a=pavement[j],b=pavement[j+1];
    const d=Math.hypot(a[0]-b[0],a[2]-b[2]);
    const nx=(b[2]-a[2])/d,nz=(a[0]-b[0])/d, w=1.85;
    path.push(quad([a[0]-nx*w,a[1],a[2]-nz*w],[a[0]+nx*w,a[1],a[2]+nz*w],[b[0]+nx*w,b[1],b[2]+nz*w],[b[0]-nx*w,b[1],b[2]-nz*w]));
    const n=Math.ceil(d/2.95), endpoint=(t,k)=>new THREE.Vector3(THREE.MathUtils.lerp(a[0],b[0],t)+nx*1.73, THREE.MathUtils.lerp(a[1],b[1],t)+k, THREE.MathUtils.lerp(a[2],b[2],t)+nz*1.73);
    for(let k=0;k<n;k++) {
      const p=endpoint(k/n,0),q=endpoint((k+1)/n,0);
      rail.push(box(.14,.91,.14,p.x,p.y+.04,p.z));
      for(const y of [.38,.83]){
        const m=p.clone().lerp(q,.5);m.y+=y;
        const dir=q.clone().sub(p);
        const geo=new THREE.BoxGeometry(.115,dir.length(),.145);
        geo.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize()));
        geo.translate(m.x,m.y,m.z);rail.push(geo);
      }
      const under=p.clone().lerp(q,.5);
      path.push(box(1.65,.36,1.3,under.x,under.y-.43,under.z));
    }
  }
  grp.add(mesh(path,walkway),mesh(rail,fence));
  const pool=new THREE.Mesh(new THREE.CircleGeometry(17.2,44).rotateX(-Math.PI/2),lit('#293542',{rough:.39,metal:.16,side:THREE.DoubleSide,emissive:'#10212b',ei:.45}));
  pool.scale.z=.66;pool.position.set(mx-28.3,145.4,mz-8.6);pool.name='water-curtain-base-pool';grp.add(pool);
  const ledge=blobGeometry(1,{detail:4,amp:.12,squash:1,seed:741}).scale(8.7,1.64,8.7);
  ledge.rotateY(.29).translate(mx-12.7,151.25,mz-10.25);
  grp.add(mesh(ledge,lightRock));
  const source={x:mx-2,z:mz-10.7};
  const veil=buildVeil(grp,source,floorY);
  const greens=lit('#3b5343',{rough:.95,emissive:'#192c24',ei:.43});
  const crown=[];
  for(let i=0;i<66;i++){
    const side=i%2?-1:1,x=mx+3.7+Math.sin(i*1.9)*8.4;
    const cz=mz+Math.cos(i*5.2)*14 + side*18.7,y=168.5+Math.sin(i*2.4)*12.4;
    if(Math.abs(cz-mz)>13.7)crown.push(blobGeometry(1.25+1.12*Math.abs(Math.sin(i*1.228)),{detail:1,amp:.24,squash:.58,seed:i*6.4}).translate(x,y,cz));
  }
  const canopy=mesh(crown,greens);canopy.name='cave-edge-fern-fragments';grp.add(canopy);
  const warm=new THREE.PointLight('#e7ae80',856,57,2);warm.position.set(mx-27,169,mz+10);grp.add(warm);
  const blue=new THREE.PointLight('#acc8ea',660,52,2);blue.position.set(mx-19.5,172,mz-17);grp.add(blue);
  const insideFill=new THREE.PointLight('#b2c6de',27,14,2);insideFill.position.set(mx+5.4,floorY+3.3,mz+1);grp.add(insideFill);
  anchors.push([mx-3.2,floorY+.45,mz+21,'caveLamp']);
  for(const [text,w,h,px,py,pz,rot] of [
    ['高山流水',2.8,8.0,mx-4.5,170,mz-19.2,-Math.PI/2-.10],
    ['灵泉',1.3,3.1,mx-3.34,166.8,mz+8.2,-Math.PI/2+.08],
    ['神泉普润',2.7,6.0,mx-4.0,172.8,mz+16.2,-Math.PI/2-.03]
  ]){
    const sheet=inscribed(text,w,h,{vertical:true,ink:'#b95848',size:.8,glow:'#974037',ei:.22});
    sheet.position.set(px,py,pz);sheet.rotation.y=rot;grp.add(sheet);sheet.name='carving';
    carvings.push({mesh:sheet,base:.22});
  }

  /* ------------------------------------------------------ 娲遗石与一线天 */
  const bo = SITE.boulders;
  const parts = [];
  const big = [
    [0, 0, 13, 11, 9], [-9, 5, 10, 9, 8], [8, -7, 11, 10, 7.4], [2, 12, 8, 7, 6], [-4, -12, 9, 8, 7],
  ];
  big.forEach(([dx, dz, r, hh, w], i) => {
    const px = bo.x + dx, pz = bo.z + dz;
    const g = blobGeometry(r, { detail: 2, amp: 0.2, squash: hh / r, seed: i + 3 });
    g.scale(1, 1, w / r);
    g.translate(px, groundAt(px, pz) + hh * 0.4 - r * 0.34, pz);
    parts.push(g);
  });
  {
    const px = bo.x + 3.4, pz = bo.z + 1.6, py = groundAt(px, pz);
    const g = blobGeometry(6.2, { detail: 2, amp: 0.14, squash: 0.78, seed: 9 });
    g.translate(px, py + 5.4, pz);
    parts.push(g);
    const egg = blobGeometry(3.4, { detail: 2, amp: 0.1, squash: 0.62, seed: 14 });
    egg.scale(1.1, 0.72, 1);
    egg.translate(px - 0.5, py + 11.4, pz + 0.4);
    parts.push(egg);
    anchors.push([px - 6, py + 1.1, pz - 3.2, 'stoneLamp']);
  }
  const boulders = mesh(parts, BOULDER);
  boulders.name = 'boulders';
  grp.add(boulders);
  {
    const fx = bo.x - 3.8, fz = bo.z - 1.4, fy = groundAt(fx, fz);
    anchors.push([fx, fy + 0.7, fz, 'crack']);
    grp.add(mesh([
      box(1.7, 0.5, 9.4, fx - 2.7, fy + 7.2, fz),
      box(1.7, 0.5, 9.4, fx + 2.7, fy + 7.2, fz),
    ], BOULDER));
  }

  /* ------------------------------------------------ 海蚀崖脚与坡上乱石 */
  const foot = [], footBlobs = [];
  for (let z = -1160; z <= 1160; z += 26) {
    const x = SEA.oldShore(z) + rr(-4, 8);
    const y = groundAt(x, z);
    if (y > 22 || y < 1) continue;
    foot.push(box(rr(3.4, 9), rr(0.5, 1.7), rr(1.2, 3.2), x, y - 0.2, z).rotateY(rr(-0.3, 0.3)));
    footBlobs.push(blobGeometry(rr(1.2, 2.6), { detail: 1, amp: 0.3, squash: 0.6, seed: rand() * 40 })
      .translate(x + rr(-6, 6), y + 0.2, z + rr(-8, 8)));
  }
  const benchMat = lit('#70746f', {
    map: T.rockFace({ meters: 9 }), rough: 0.97, side: THREE.DoubleSide,
    emissive: '#0a1015', ei: 0.32,
  });
  for (const g of [mergeGeometries(foot), mergeGeometries(footBlobs)]) {
    const m = new THREE.Mesh(g, benchMat);
    m.name = 'wave-bench';
    grp.add(m);
  }

  const scatter = [];
  for (let i = 0; i < 180; i++) {
    const x = rr(-660, 320), z = rr(-900, 900);
    const y = groundAt(x, z);
    if (y < 14) continue;
    const r = rr(1.4, 5.2) * (0.6 + Math.min(1.6, y / 420));
    const g = blobGeometry(r, { detail: 1, amp: 0.32, squash: rr(0.5, 0.85), seed: i });
    g.translate(x, y - r * 0.42, z);
    scatter.push(g);
  }
  const talus = mesh(scatter, BOULDER);
  talus.name = 'talus';
  grp.add(talus);

  scene.add(grp);
  return {
    group: grp, anchors, carvings, veil,
    mouth: {x:mx,z:mz,y:floorY,w:MOUTH_W,h:MOUTH_H},
    cliffTop: floorY+31,
    poolY:145.4,rockScene:true,
  };
}

/** 四边形（四个角点，逆时针） */
function quad(a, b, c, d) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(
    [a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2], d[0], d[1], d[2]], 3));
  const uv = [];
  for (let i = 0; i < 4; i++) uv.push(i % 2, i > 1 ? 1 : 0);
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex([0, 1, 2, 0, 2, 3]);
  g.computeVertexNormals();
  return g;
}

/**
 * 水帘：挂在洞门以西的一张幕，从中间拉开；后面还有两段更高的跌水，
 * 三层叠起来才是"半壁飞泉"。
 */
function buildVeil(grp, cave, floorY) {
  const uni = { uTime: { value: 0 }, uOpen: { value: 0 }, uFlow: { value: 1 } };
  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, side: THREE.DoubleSide, fog: false, uniforms: uni,
    blending: THREE.NormalBlending,
    vertexShader: `
      uniform float uTime; uniform float uOpen;
      varying vec2 vUv; varying vec3 vWp;
      void main(){
        vUv = uv;
        vec3 p = position;
        p.z += sin(p.y * .69 + uTime * 3.1) * .14 + sin(uTime * 1.7) * .12;
        vec4 wp = modelMatrix * vec4(p, 1.0);
        vWp = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }`,
    fragmentShader: `
      uniform float uTime; uniform float uOpen; uniform float uFlow;
      varying vec2 vUv; varying vec3 vWp;
      void main(){
        float u = vUv.x, v = vUv.y;
        float gap = uOpen * 0.46;
        float parted = smoothstep(0.5 - gap - 0.08, 0.5 - gap, u)
                     * (1.0 - smoothstep(0.5 + gap, 0.5 + gap + 0.08, u));
        float curtain = 1.0 - parted;
        // 细水线只在近处给，远处退成一层柔白纱，否则满屏摩尔纹
        float det = clamp(1.0 - (length(cameraPosition - vWp) - 60.0) / 190.0, 0.0, 1.0);
        float strands = 0.0;
        for (int i = 0; i < 3; i++) {
          float f = float(i);
          float fr = (11.0 + f * 9.0) * (0.45 + 0.55 * det);
          strands += pow(abs(sin((u * fr + sin(v * 3.1 + uTime * 0.9 + f) * 1.6 - uTime * (3.4 + f * 1.9)) * 3.1416)), 5.0) / (1.0 + f);
        }
        // 水线之间要有过渡，不然是一排白条
        float body = 0.42 + 0.20 * sin(u * 41.0 + uTime * 1.4) * sin(v * 7.0 - uTime * 3.2);
        float streak = clamp(strands * 0.42 + body * 0.55, 0.0, 1.0);
        float fall = pow(1.0 - v, 0.42);
        float side = smoothstep(0.0, 0.10, u) * (1.0 - smoothstep(0.90, 1.0, u));
        float a = curtain * (0.12+0.88*uFlow) * (0.07 + 0.55 * streak) * (0.55 + 0.45 * fall) * side;
        if (a < 0.004) discard;
        // 背光的水：整体一层冷白，水线处提亮，底部起雾
        vec3 col = vec3(.24,.29,.35) + vec3(.53,.57,.63) * pow(streak,1.44);
        col += vec3(0.14, 0.12, 0.08) * (1.0 - v) * 0.7;
        gl_FragColor = vec4(col, a);
      }`,
  });

  const sheet = (zFrom, zTo, yBottom, yTop, xTop, xBottom, nu = 34, nv = 20) =>
    quadGrid((u, v) => {
      const z = zFrom + u * (zTo - zFrom);
      const y = yBottom + v * (yTop - yBottom);
      const x = lerpN(xBottom,xTop,v) + .28*Math.sin(u*Math.PI) + .27*Math.sin(v*5.5);
      return [x, y, z];
    }, nu, nv, {spanU:1,spanV:1});

  const mouthZ = cave.z;
  // 一整挂到底：分三段接起来必错位，看着就成了拧着的绸子
  const pieces = [
    sheet(mouthZ-3.6,mouthZ+3.85,floorY-2.8,floorY+23.4,cave.x-1.6,cave.x-12.8,36,24),
    sheet(mouthZ-5.0,mouthZ-1.1,floorY-10.0,floorY-1.74,cave.x-12.8,cave.x-20.7,26,20),
    sheet(mouthZ-.46,mouthZ+3.3,floorY-10.25,floorY-1.49,cave.x-12.6,cave.x-18.9,28,20),
  ];
  const m = new THREE.Mesh(mergeGeometries(pieces), mat);
  m.name = 'water-veil';
  m.renderOrder = 7;
  grp.add(m);

  const N = 81, pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    pos.set([cave.x-rr(17,23),floorY-rr(7.0,10.2),mouthZ+rr(-4.15,4.0)], i * 3);
  }
  const pg = new THREE.BufferGeometry();
  pg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const sm = new THREE.Points(pg, new THREE.PointsMaterial({
    size: .77, map: T.softGlow('236,246,255', 0.02), transparent: true, depthWrite: false,
    blending: THREE.AdditiveBlending, opacity: .23, fog: false,
  }));
  sm.name = 'spray';
  sm.frustumCulled = false;
  grp.add(sm);

  return {
    mesh: m, points: sm, uni,
    setOpen(v) { uni.uOpen.value = Math.max(0, Math.min(1, v)); },
    setFlow(v) { uni.uFlow.value = Math.max(0, v); m.visible = v > 0.02; sm.visible = v > 0.06; },
    update(t, flow) {
      uni.uTime.value = t;
      uni.uFlow.value = flow;
      m.visible = flow > 0.02;
      sm.visible = flow > 0.06;
    },
  };
}

const lerpN = (a, b, t) => a + (b - a) * t;
