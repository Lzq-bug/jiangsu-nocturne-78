import * as THREE from 'three';
import { WATER_Y } from './water.js';

const START_X = 9.2;
const START_Z = -42.4;
const DRIFT_SECONDS = 7.5;

/** One visitor-owned lotus lantern, separate from the decorative light field. */
export function buildGuestLantern(scene, columns) {
  const lamp = new THREE.Group();
  lamp.name = 'yunitou-visitor-lotus-lantern';
  const leaf = new THREE.MeshStandardMaterial({ color: '#3d5b45', roughness: 0.84 });
  const petal = new THREE.MeshStandardMaterial({
    color: '#dc7856', emissive: '#cc4527', emissiveIntensity: 0.24, roughness: 0.66,
    side: THREE.DoubleSide,
  });
  const cup = new THREE.MeshStandardMaterial({
    color: '#ffbe65', emissive: '#ff9e3c', emissiveIntensity: 0.95, roughness: 0.62,
    side: THREE.DoubleSide,
  });
  const wick = new THREE.MeshBasicMaterial({ color: new THREE.Color('#ffe5ad').multiplyScalar(1.65) });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.27, 0.065, 16), leaf);
  lamp.add(base);

  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.bezierCurveTo(-0.22, 0.17, -0.20, 0.46, 0, 0.57);
  shape.bezierCurveTo(0.20, 0.46, 0.22, 0.17, 0, 0);
  const blade = new THREE.ShapeGeometry(shape, 8);
  for (let i = 0; i < 12; i++) {
    const layer = i % 2;
    const axis = new THREE.Group();
    axis.rotation.y = i * Math.PI / 6;
    const mesh = new THREE.Mesh(blade, layer ? cup : petal);
    mesh.position.set(0, 0.012, layer ? 0.06 : 0.17);
    mesh.rotation.x = layer ? 0.38 : 0.87;
    mesh.scale.setScalar(layer ? 0.64 : 1);
    axis.add(mesh);
    lamp.add(axis);
  }
  const flame = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), wick);
  flame.position.y = 0.22;
  flame.scale.set(0.76, 1.46, 0.76);
  lamp.add(flame);
  lamp.position.set(START_X, WATER_Y + 0.1, START_Z);
  lamp.visible = false;
  scene.add(lamp);
  const glint = columns.add(lamp.position, '#ff9f57', 0.49, 2.7, 0.94);
  columns.setOn(glint, false);
  let started = 0;

  const api = {
    reset() {
      started = performance.now();
      lamp.visible = false;
      columns.setOn(glint, false);
      return false;
    },
    toggle() {
      if (lamp.visible) return api.reset();
      started = performance.now();
      lamp.visible = true;
      api.update();
      columns.setOn(glint, true);
      return true;
    },
    update() {
      if (!lamp.visible) return;
      const age = (performance.now() - started) / 1000;
      const progress = Math.min(1, age / DRIFT_SECONDS);
      const drift = progress * (2 - progress);
      lamp.position.set(
        START_X - drift * 3.1,
        WATER_Y + 0.1 + Math.sin(age * 2.15) * 0.033,
        START_Z - drift * 7.1,
      );
      lamp.rotation.set(Math.sin(age * 1.7) * 0.06, age * 0.2, Math.sin(age * 2) * 0.055);
      columns.setPos(glint, lamp.position);
    },
  };
  return api;
}
