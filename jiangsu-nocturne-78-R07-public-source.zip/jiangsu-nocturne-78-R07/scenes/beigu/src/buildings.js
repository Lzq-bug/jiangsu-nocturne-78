import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  M, mesh, lit, glow, rr, box, cyl, loft, roundedSection, quadGrid, blobGeometry, inscribed,
} from './kit.js';
import * as T from './textures.js';
import { gabledRoof, pavilionRoof } from './roofs.js';
import { SITES, terrainHeight, TOP, TOP_Y, FEATURES, PLAIN } from './data.js';

/**
 * 后峰顶上的诸迹与山门口的牌楼、前峰下的铁瓮城标识。
 * 每座屋子都把"楼面高 / 平座高 / 顶高"回写进 built，机位从这些数里取站脚
 * （见 main.js resolveStations），所以改了形制，机位自己跟着挪。
 */

let TILE, TILEW;

export function buildArchitecture(scene) {
  // Materials are created by boot; before this point these aliases are undefined.
  TILE=M.roof; TILEW=M.roofWarm;
  const group = new THREE.Group();
  group.name = 'architecture';
  const built = {};
  const lamps = [];      // 挂灯点：{x,y,z,kind,t,group}
  const windows = [];    // 发光窗片（材质分组用）

  built.temple = buildTemple(group, lamps, windows);
  built.duoJing = buildDuoJing(group, lamps, windows);
  built.beiguLou = buildBeiguLou(group, lamps, windows);
  built.ironTower = buildIronTower(group, lamps, windows);
  built.jiangTing = buildJiangTing(group, lamps);
  built.stele = buildSteleCorridor(group, lamps);
  built.stones = buildStones(group);
  built.gate = buildGate(group, lamps);
  built.tiebeng = buildTieBeng(group, lamps);

  scene.add(group);
  const modeledLights=[];
  group.traverse(o=>{
    if(!o.isPointLight || o.userData.beiguLamp===undefined)return;
    modeledLights.push({light:o,level:o.userData.beiguLamp,base:o.intensity});
  });
  return { group, built, lamps, windows, modeledLights };
}

/* ------------------------------------------------------------------ 甘露寺 */

/**
 * 山门—前殿—大雄宝殿一串，纵轴略斜；四面黄墙把顶平台围出一院。
 * 形制取江南寺观通例，殿名与匾额为补配（1010 年诏徙峰顶这件事是可核的）。
 */
function buildTemple(grp, lamps, windows) {
  const S = SITES.temple;
  const g = new THREE.Group();
  g.position.set(S.x, 0, S.z);
  g.rotation.y = S.rot;
  const deck = S.y + 0.14;

  // 台基（两层须弥座）
  const base = [
    box(46, 0.9, 58, 0, deck - 0.75, 0),
    box(44, 0.7, 56, 0, deck + 0.15, 0),
  ];
  g.add(mesh(base, M.stone));
  const floorY = deck + 0.85;

  /* 黄墙围院：东西两长墙 + 南墙开门 */
  const wallParts = [];
  const wallH = 5.2;
  wallParts.push(box(46, wallH, 1.0, 0, floorY, 28));                 // 北墙（临江一侧）
  for (const sx of [-1, 1]) wallParts.push(box(1.0, wallH, 56, sx * 22.5, floorY, 0));
  wallParts.push(box(17, wallH, 1.0, -14.5, floorY, -28));
  wallParts.push(box(17, wallH, 1.0, 14.5, wallH * 0 + floorY, -28));
  const wallMat = M.templeWall;
  const wallM = mesh(wallParts, wallMat);
  wallM.name = 'temple-wall';
  wallM.castShadow = true; wallM.receiveShadow = true;
  g.add(wallM);
  // 墙顶黛瓦压顶
  const cap = [];
  for (const [w, d, x, z] of [[48, 1.6, 0, 28], [1.6, 58, -22.5, 0], [1.6, 58, 22.5, 0], [18, 1.6, -14.5, -28], [18, 1.6, 14.5, -28]]) {
    cap.push(box(w, 0.5, d, x, floorY + wallH, z));
  }
  g.add(mesh(cap, TILE));

  /* 山门（门楼高耸） */
  const gate = new THREE.Group();
  gate.position.set(0, floorY, -27);
  const gd = [box(15, 6.4, 6.2, 0, 0, 0), box(16.6, 0.8, 7.4, 0, 6.4, 0)];
  gate.add(mesh(gd, M.templeWall));
  for (const sx of [-5.4, 5.4]) gate.add(mesh([cyl(0.34, 0.3, 6.2, 10, sx, 0, -3.4)], M.timberDark));
  const gateRoof = gabledRoof({ span: 17.6, depth: 8.6, rise: 3.0, eaveY: 7.2, lift: 0.5, cornerOut: 0.9 });
  gate.add(mesh(gateRoof.surface, TILE));
  if (gateRoof.ridge) gate.add(mesh(gateRoof.ridge, TILEW));
  const gatePlaque = inscribed('古甘露禅寺', 5.6, 1.5, { ink: '#f0e2c4', size: 0.8, glow: '#4a3a16', ei: 0.5 });
  gatePlaque.position.set(0, 4.6, -3.5);
  gatePlaque.rotation.y = Math.PI;
  gate.add(gatePlaque);
  g.add(gate);
  lamps.push({ x: S.x, y: floorY + 5.4, z: S.z - 27, kind: 'lantern', t: 0.06, g: 'gate' });

  /* 前殿（天王殿）与大雄宝殿 */
  const hall = buildHall({ w: 21, d: 13, h: 7.4, rise: 3.9, name: 'qian' });
  hall.position.set(0, floorY, -8);
  g.add(hall);
  windows.push(...hall.userData.windows);

  const main = buildHall({ w: 25, d: 15, h: 8.6, rise: 4.4, name: 'daxiong', bigger: true });
  main.position.set(0, floorY, 12);
  g.add(main);
  windows.push(...main.userData.windows);

  // 殿前月台与香炉
  const terrace = [box(27, 0.6, 24, 0, floorY + 0.3, 2)];
  g.add(mesh(terrace, M.paving));
  const incense = new THREE.Group();
  incense.add(mesh([
    cyl(1.0, 0.8, 0.5, 12, 0, 0.9, 0),
    cyl(1.3, 1.3, 0.35, 12, 0, 0.6, 0),
    box(0.3, 0.9, 0.3, -1.2, 0.9, 0), box(0.3, 0.9, 0.3, 1.2, 0.9, 0),
  ], M.bronze));
  incense.position.set(0, floorY + 0.6, -1);
  g.add(incense);

  // 两殿之间的庭院灯与墙上的漏光
  for (const sx of [-1, 1]) {
    lamps.push({ x: S.x + sx * 15, y: floorY + 3.0, z: S.z + 2, kind: 'lantern', t: 0.2, g: 'temple' });
  }
  lamps.push({ x: S.x, y: floorY + 7.0, z: S.z + 12, kind: 'flood', t: 0.24, g: 'temple' });

  grp.add(g);
  return { group: g, floorY, deck: deck, hallY: floorY + 8.6, center: [S.x, S.z] };
}

/** 一座殿：柱网 + 墙体 + 门窗 + 屋顶，窗片回写 userData.windows */
function buildHall({ w, d, h, rise, name, bigger = false }) {
  const g = new THREE.Group();
  g.name = `hall-${name}`;
  const cols = [], walls = [], win = [];
  const nx = Math.max(3, Math.round(w / 5.4)), nz = Math.max(2, Math.round(d / 5.4));
  for (let i = 0; i <= nx; i++) {
    for (let j = 0; j <= nz; j++) {
      const x = -w / 2 + i * (w / nx), z = -d / 2 + j * (d / nz);
      cols.push(cyl(0.42, 0.36, h, 10, x, 0, z));
    }
  }
  // 墙（后墙与山墙实砌，前墙开门窗）
  walls.push(box(w + 0.6, h, 0.7, 0, h / 2, d / 2));
  for (const sx of [-1, 1]) walls.push(box(0.7, h, d, sx * (w / 2), h / 2, 0));
  walls.push(box(w * 0.34, h * 0.42, 0.6, 0, h * 0.21, -d / 2));
  for (const sx of [-1, 1]) walls.push(box(w * 0.2, h * 0.55, 0.6, sx * w * 0.34, h * 0.275, -d / 2));
  g.add(mesh(cols, M.timberDark));
  g.add(mesh(walls, M.plaster));

  // 门窗：发光片贴在洞口后
  const doorH = h * 0.62;
  for (let i = 0; i < 3; i++) {
    const x = (i - 1) * w * 0.2;
    const pane = new THREE.Mesh(
      new THREE.PlaneGeometry(w * 0.14, doorH * 0.86),
      lit('#f6dcb4', { rough: 0.9, emissive: '#ffb977', ei: 0.42 }),
    );
    pane.position.set(x, doorH * 0.44, -d / 2 - 0.34);
    pane.userData.kind = 'window';
    win.push(pane);
  }
  for (const sz of [-1, 1]) {
    for (const sx of [-1, 1]) {
      const lat = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.5), M.latticeLight);
      lat.position.set(sx * (w / 2 - 1.2), h * 0.55, sz * (d / 2 - 1.6));
      lat.rotation.y = Math.PI / 2;
      lat.userData.kind = 'window';
      win.push(lat);
    }
  }
  for (const p of win) g.add(p);

  // 额枋 + 屋顶
  g.add(mesh([box(w + 1.4, 0.7, 0.8, 0, h - 0.35, -d / 2 - 0.3)], M.timber));
  const roof = gabledRoof({ span: w + 2.6, depth: d + 2.6, rise, eaveY: h, lift: 0.46, cornerOut: bigger ? 1.1 : 0.8 });
  g.add(mesh(roof.surface, TILE));
  if (roof.ridge) g.add(mesh(roof.ridge, TILEW));
  for (const sx of [-1, 1]) {
    const end = quadGrid((u, v) => {
      const zz = (u - 0.5) * (d + 1.2);
      const top = h + rise * Math.max(0.06, 1 - Math.abs(zz / ((d + 1.2) / 2)) * 0.8);
      return [sx * (w / 2 + 0.35), v * 0 + THREE.MathUtils.lerp(0, top, v), zz];
    }, 12, 2, { spanU: d, spanV: h + rise });
    g.add(mesh(end, M.plaster));
  }
  const plaque = inscribed(bigger ? '大雄宝殿' : '天王殿', 3.4, 1.0, { ink: '#efe4c8', size: 0.78, glow: '#3d3212', ei: 0.4 });
  plaque.position.set(0, h * 0.78, -d / 2 - 0.55);
  plaque.rotation.y = Math.PI;
  g.add(plaque);

  g.userData.windows = win;
  return g;
}

/* ------------------------------------------------------------------ 多景楼 */

/**
 * 二层、回廊四通、面面皆景（诸源只给这一句，通高属写意）。
 * 周圈平座与四向回廊是这一站要拍的东西。
 */
// Historic architectural names have overlapped, but these are separate extant
// volumes. Plan limits and dedicated fixtures are interpretive, not a survey.
function terraceRail(w, d, y, gate = 0) {
  const a = [], addLine = (L, point, along) => {
    for (let j = 0, n = Math.ceil(L / 1.22); j < n; j++) {
      const u = (j+.5)*L/n-L/2;
      if (gate && along && Math.abs(u)<gate && point(0)[1]>0) continue;
      const [x,z] = point(u);
      a.push(box(.12,.75,.12,x,y,z),box(along?L/n:.14,.13,along?.14:L/n,x,y+.67,z));
    }
  };
  for (const t of [-1,1]) {
    addLine(w,u=>[u,t*d/2],true);
    addLine(d,u=>[t*w/2,u],false);
  }
  return a;
}
function lodgeRoof(g, w,d,y,rise, lift=.6, crown=false) {
  const A=gabledRoof({span:w,depth:d,eaveY:y,rise,lift,cornerOut:1.05,withRidge:crown});
  const B=gabledRoof({span:d,depth:w,eaveY:y,rise:rise*(crown?.92:.86),lift,cornerOut:1.05,withRidge:crown});
  B.surface.rotateY(Math.PI/2);
  g.add(mesh([A.surface,B.surface],TILE));
  if (A.ridge&&B.ridge) g.add(mesh([A.ridge,B.ridge.rotateY(Math.PI/2)],TILEW));
}
function wallLattice(g, W, D, y, bays, windows, tone) {
  const lattice=[],wood=[];
  const darkWood=lit('#614231',{rough:.82,emissive:'#1d0f08',ei:.11});
  const paper=lit(tone,{rough:.89,emissive:'#8f5d2b',ei:.22});
  for(const [sx,sz] of [[1,0],[-1,0],[0,1],[0,-1]]) {
    const span=sx ? D:W, step=span/bays, front=sx?W/2:D/2;
    function detail(boxW,h,depth,u,bottom,offset){
      return sx?box(depth,h,boxW,sx*(front+offset),bottom,u):box(boxW,h,depth,u,bottom,sz*(front+offset));
    }
    for(let j=0;j<bays;j++) {
      const c=(j+.5)*step-span/2, a=step*.68;
      const pane=mesh(detail(a,1.34,.045,c,y+.42,.015),paper);
      pane.userData.kind='window';windows.push(pane);g.add(pane);
      for(let k=-3;k<=3;k++)lattice.push(detail(.09,1.45,.095,c+k*a/6,y+.37,.05));
      for(let k=0;k<=3;k++)lattice.push(detail(a,.09,.10,c,y+.36+k*.45,.053));
      wood.push(detail(step*.96,.34,.13,c,y+.08,.055));
    }
  }
  g.add(mesh(lattice,darkWood),mesh(wood,M.timberDark));
}

function buildDuoJing(grp, lamps, windows) {
  const S=SITES.duoJing;
  const g=new THREE.Group();
  g.name='duojing-lodge';
  g.position.set(S.x,0,S.z);g.rotation.y=S.rot;
  const f=S.y+.24;
  const beam=lit('#7d5541',{rough:.8,emissive:'#492413',ei:.34});
  const plank=lit('#4d392a',{rough:.88,emissive:'#1e130a',ei:.2});
  const softStone=lit('#877469',{rough:.91,emissive:'#3d3430',ei:.11});
  g.add(mesh([box(23.2,.85,16.8,0,f-.7,0),box(22.8,.22,16.4,0,f+.08,0)],softStone));
  g.add(mesh([box(14.2,3.12,8.4,0,f+.27,0),box(13.6,2.1,7.9,0,f+3.75,-.2)],beam));
  g.add(mesh([box(19.8,.27,13.4,0,f+3.48,0)],plank));
  const cols=[];
  for (const q of [-1,1]){
    for(let i=0;i<7;i++)cols.push(box(.23,3.35,.24,(i-3)*3.18,f+.28,q*6.12));
    for(let i=0;i<3;i++)cols.push(box(.23,3.35,.24,q*9.54,f+.28,(i-1)*3.05));
    for(let i=0;i<6;i++)cols.push(box(.18,2.22,.18,(i-2.5)*2.98,f+3.73,q*4.74));
    for(let i=0;i<3;i++)cols.push(box(.18,2.22,.18,q*7.46,f+3.73,(i-1)*3.1));
  }
  g.add(mesh(cols,beam));
  g.add(mesh(terraceRail(20.25,13.5,f+.34,2.1).filter(geo=>{geo.computeBoundingBox();const bb=geo.boundingBox;return !(bb.min.x<-10 && bb.min.z>-2 && bb.max.z<2)}),beam));
  g.add(mesh(terraceRail(17.6,10.9,f+3.75),beam));
  const skirt=gabledRoof({span:21.6,depth:15.1,eaveY:f+3.55,rise:1.22,lift:.57,cornerOut:.7,withRidge:false});
  const upper=gabledRoof({span:18.7,depth:12.5,eaveY:f+6.12,rise:2.05,lift:.61,cornerOut:.75});
  g.add(mesh(skirt.surface,TILE),mesh(upper.surface,TILE),mesh(upper.ridge,TILEW));
  wallLattice(g,14.23,8.43,f+.57,5,windows,'#b58c62');
  wallLattice(g,13.63,8.32,f+3.72,5,windows,'#a87d54');
  const board=inscribed('多景楼',3.2,.75,{board:'#2b251f',ink:'#dfc695',size:.78,glow:'#51381d',ei:.35});
  board.position.set(0,f+2.96,6.31);g.add(board);
  // A timber connector to a small covered outlook, not the stone 祭江亭.
  const link=new THREE.Group();link.position.set(-10.65,0,-.1);link.rotation.y=Math.PI/2;
  const supports=[];
  for(let j=0;j<8;j++) {
    const z=-1.5-j*1.42;
    const surface=f+.25+(.8*Math.sin(j*.41));
    supports.push(box(3.2,.13,1.48,0,surface,z));
    for(const x of [-1.5,1.5])supports.push(box(.15,1.04,.15,x,surface,z),box(.16,.12,1.45,x,surface+.88,z));
    for(const x of [-.9,.9])supports.push(box(.22,Math.max(.42,surface-terrainHeight(S.x+z-10,S.z)+.1),.24,x,Math.min(surface-.42,terrainHeight(S.x+z-10,S.z)-.1),z));
  }
  link.add(mesh(supports,plank));g.add(link);
  const outlook=new THREE.Group();outlook.position.set(-24.6,0,-.1);g.add(outlook);
  const od=f+.32,posts=[];
  for(const x of [-2.63,2.63])for(const z of [-2.63,2.63])posts.push(box(.23,2.82,.23,x,od,z));
  outlook.add(mesh([box(6.1,.55,6.1,0,od-.55,0)],softStone),mesh(posts,beam),mesh(terraceRail(5.6,5.6,od),beam));
  lodgeRoof(outlook,6.95,6.95,od+2.8,1.72,.6,true);
  for (const z of [S.z-6.7,S.z+5.9])lamps.push({x:S.x,y:f+2.34,z,kind:'lantern',t:.52,g:'duojing'});
  const soffit=new THREE.PointLight('#ffc991',36,23,2.05);soffit.position.set(2.8,f+2.4,5.4);soffit.userData.beiguLamp=.52;g.add(soffit);
  const loftFill=new THREE.PointLight('#f2c088',25,16,2);loftFill.position.set(-4.1,f+5.45,5.7);loftFill.userData.beiguLamp=.55;g.add(loftFill);
  grp.add(g);
  return {group:g,floorY:f+3.75,deck:f+.27,roofY:f+8.22,soffit};
}

/* ------------------------------------------------------------------ 北固楼 */

function buildBeiguLou(grp, lamps, windows) {
  const S=SITES.beiguLou;
  const g=new THREE.Group();g.name='beigu-lou';g.position.set(S.x,0,S.z);g.rotation.y=S.rot;
  const baseY=S.y-.18, f=baseY+.89;
  const warmWood=lit('#714133',{rough:.81,emissive:'#321712',ei:.15});
  const textureWall=lit('#77604b',{rough:.95,emissive:'#32241b',ei:.08});
  // The downhill end is supported in the slope; cap stone stays low to the eye.
  g.add(mesh([box(25,3.75,21.2,0,baseY-3.75,0),box(25.5,.47,21.8,0,baseY,0),box(24.2,.43,20.6,0,baseY+.47,0)],M.stone));
  const floors=[
    {y:f,w:17.8,d:13.2,h:5.15,sw:22.8,sd:18.8,rise:1.7},
    {y:f+5.65,w:15.2,d:11.8,h:4.65,sw:20.0,sd:16.4,rise:1.75},
    {y:f+10.82,w:11.9,d:9.8,h:4.75,sw:16.9,sd:14.0,rise:2.64},
  ];
  for(const [i,s] of floors.entries()){
    g.add(mesh([box(s.w-.38,s.h,s.d-.38,0,s.y,0)],textureWall));
    g.add(mesh([box(s.w+2.6,.35,s.d+2.6,0,s.y-.36,0),box(s.sw-.85,.25,s.sd-.85,0,s.y+s.h-.34,0)],warmWood));
    const vertically=[];
    for(const q of [-1,1]){
      for(let j=0;j<6;j++)vertically.push(cyl(.26,.21,s.h,8,(j-2.5)*s.w/5,s.y,q*(s.d/2+.72)));
      for(let j=0;j<4;j++)vertically.push(cyl(.24,.20,s.h,8,q*(s.w/2+.64),s.y,(j-1.5)*s.d/3));
    }
    g.add(mesh(vertically,warmWood));
    g.add(mesh(terraceRail(s.w+2.15,s.d+2.12,s.y),warmWood));
    wallLattice(g,s.w,s.d,s.y+.82,i?4:5,windows,i===2?'#94735a':'#b7926b');
    lodgeRoof(g,s.sw,s.sd,s.y+s.h,s.rise,.72,i===2);
    for(const [x,z] of [[-s.w*.30,s.d*.58],[s.w*.3,-s.d*.58]]) {
      const wash=new THREE.PointLight('#f7c385',i===2?17:21,16,2);
      wash.position.set(x,s.y+s.h-.79,z);wash.userData.beiguLamp=.99;g.add(wash);
    }
  }
  const yTop=baseY+19.9;
  g.add(mesh([cyl(.32,.20,.75,10,0,yTop-.75,0)],M.gold));
  const board=inscribed('北固楼',3.2,.93,{board:'#2d221b',ink:'#e8c897',size:.77,glow:'#60452a',ei:.41});
  board.position.set(0,f+4.22,-7.15);board.rotation.y=Math.PI;g.add(board);
  const approach=inscribed('北固楼',3.2,.93,{board:'#2d221b',ink:'#e8c897',size:.77,glow:'#60452a',ei:.41});
  approach.position.set(0,f+4.22,7.15);g.add(approach);
  for(const [yy,zz] of [[f+3.15,-7.6],[f+3.15,7.4],[f+9,-5.9]])lamps.push({x:S.x,y:yy,z:S.z+zz,kind:'lantern',t:1,g:'lou'});
  const soffit=new THREE.PointLight('#f3bf88',34,21,2.05);soffit.position.set(-3,f+3.5,6.3);soffit.userData.beiguLamp=.98;g.add(soffit);
  grp.add(g);
  return {group:g,floorY:f+10.82,deck:f+5.65,baseY:f,topY:yTop,overall:yTop-baseY,center:[S.x,S.z],soffit};
}

/* ------------------------------------------------------------------ 铁塔 */

/**
 * 今存四层：一、二层宋物，三、四层明铸（诸源说唐宝历始、宋元丰九级、明七级）。
 * 层数可照志书摆，尺寸与塔身细部属写意；tier 由 props 逐层点亮。
 */
function buildIronTower(grp, lamps, windows) {
  const S = SITES.ironTower;
  const g = new THREE.Group();
  g.position.set(S.x, 0, S.z);
  const f = S.y + 0.12;

  const parts = [];
  const tiers = [];
  let y = f;
  let half = 2.6;
  const H = [1.75, 1.55, 1.35, 1.15];
  for (let i = 0; i < 4; i++) {
    parts.push(box(half * 2, H[i], half * 2, 0, y, 0));
    // 每层檐：一圈外挑的窄板
    parts.push(box(half * 2 + 1.0, 0.26, half * 2 + 1.0, 0, y + H[i], 0));
    tiers.push({ y0: y, y1: y + H[i] + 0.26, half });
    y += H[i] + 0.26;
    half *= 0.82;
  }
  parts.push(cyl(0.34, 0.2, 1.1, 8, 0, y, 0));
  const 塔 = mesh(parts, M.ink);
  塔.name = 'iron-tower';
  g.add(塔);
  const spire = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), M.bronze);
  spire.position.set(0, y + 1.3, 0);
  g.add(spire);

  // 龛影：每层四面一小片发光面（由 tier 控制）
  const glows = [];
  for (let i = 0; i < tiers.length; i++) {
    const t = tiers[i], cy = (t.y0 + t.y1) / 2;
    for (const [sx, sz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const p = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 0.8),
        lit('#cfd8dc', { rough: 0.9, emissive: '#ffca8e', ei: 0.3 }));
      p.position.set(sx * (t.half + 0.02), cy, sz * (t.half + 0.02));
      p.rotation.y = sx ? Math.PI / 2 : 0;
      p.userData.kind = 'tier';
      p.userData.level = i;
      glows.push(p); g.add(p);
    }
  }

  // 清晖亭：塔旁一座小方亭
  const qh = new THREE.Group();
  qh.position.set(-6.4, f, 3.6);
  const qc = [];
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) qc.push(cyl(0.24, 0.22, 3.1, 8, sx * 2.0, 0, sz * 2.0));
  qh.add(mesh(qc, M.timber));
  qh.add(mesh([box(4.8, 0.3, 4.8, 0, 0.15, 0)], M.stone));
  const qroof = pavilionRoof({ half: 3.2, rise: 1.8, eaveY: 3.1, lift: 0.8, cornerOut: 0.7, sides: 4, perSide: 5, nv: 7 });
  qh.add(mesh(qroof.surface, TILE));
  g.add(qh);

  lamps.push({ x: S.x, y: f + 1.2, z: S.z + 4.4, kind: 'flood', t: 0.40, g: 'tower' });

  grp.add(g);
  return { group: g, tiers, topY: y + 1.7, glows, floorY: f };
}

/* ------------------------------------------------------------------ 祭江亭 */

/** 石柱方亭：崖嘴上的一块小台，柱子是真石头（旧志："石柱方亭"） */
function buildJiangTing(grp, lamps) {
  const S = SITES.jiangTing;
  const g = new THREE.Group();
  g.position.set(S.x, 0, S.z);
  g.rotation.y = S.rot;
  const f = S.y + 0.1;

  g.add(mesh([box(8.6, .7, 8.6, 0, f - .35, 0), box(9.5, .46, 9.5, 0, f - .81, 0)], M.stone));
  const cols = [];
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) cols.push(box(.57,3.5,.57,sx*2.9,f,sz*2.9),box(.75,.31,.75,sx*2.9,f,sz*2.9));
  g.add(mesh(cols, M.stone));
  lodgeRoof(g,7.7,7.7,f+3.54,2.12,1.04,true);
  const name=inscribed('祭江亭',2.52,.65,{board:'#282823',ink:'#e9d9a5',size:.75,glow:'#574631',ei:.25});
  name.position.set(0,f+3.14,3.02);g.add(name);
  const side=name.clone();side.position.set(-3.04,f+2.99,0);side.rotation.y=-Math.PI/2;g.add(side);
  g.add(mesh([box(8.3,4.2,8.2,0,f-4.65,0)],M.stone));
  const stoneCap=lit('#9f9790',{rough:.92,emissive:'#333631',ei:.15});
  g.add(mesh([box(7.7,.3,7.7,0,f-.02,0)],stoneCap));
  const 宝 = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 8), M.stone);
  宝.position.set(0, f + 3.5 + 2.1 + 0.3, 0);
  g.add(宝);
  // 栏
  const rail = [];
  for (const sx of [-1, 1]) rail.push(box(0.18, 0.75, 8.2, sx * 4.1, f + 0.35, 0));
  for (const sz of [-1, 1]) rail.push(box(8.2, 0.75, 0.18, 0, f + 0.35, sz * 4.1));
  g.add(mesh(rail, M.stone));
  const fill=new THREE.PointLight('#e7d3aa',27,15,2);fill.position.set(-1.9,f+2.63,1.8);fill.userData.beiguLamp=.34;g.add(fill);

  lamps.push({ x: S.x, y: f + 2.4, z: S.z, kind: 'lantern', t: 0.34, g: 'temple' });
  lamps.push({ x: S.x, y: f - 0.4, z: S.z + 2.4, kind: 'uplight', t: 0.36, g: 'temple' });

  grp.add(g);
  return { group: g, floorY: f, deck: f };
}

/* ---------------------------------------------------------- 第一江山 廊壁 */

/** 寺东一字长廊，壁上嵌一方石刻；灯不是照字，是贴着壁横扫 */
function buildSteleCorridor(grp, lamps) {
  const S = SITES.steleWall;
  const g = new THREE.Group();
  g.position.set(S.x, 0, S.z);
  g.rotation.y = S.rot;
  const f = S.y + 0.1;
  const L = 26, H = 4.4;

  g.add(mesh([box(L, H, 0.9, 0, f + H / 2, 0)], M.templeWall));
  g.add(mesh([box(L + 1.2, 0.55, 1.7, 0, f + H, 0)], TILE));
  const cols = [];
  for (let i = 0; i <= 6; i++) cols.push(cyl(0.26, 0.24, H - 0.6, 8, -L / 2 + i * (L / 6), f, -1.9));
  g.add(mesh(cols, M.timber));
  const roof = gabledRoof({ span: L + 1.6, depth: 4.2, rise: 1.5, eaveY: f + H + 0.5, lift: 0.4, cornerOut: 0.6 });
  g.add(mesh(roof.surface, TILE));
  if (roof.ridge) g.add(mesh(roof.ridge, TILEW));

  // 石刻：一块嵌在壁上的石碑 + 四字
  const slab = mesh([box(6.4, 2.5, 0.34, 0, f + 2.2, -0.62)], M.stele);
  g.add(slab);
  const word = new THREE.Mesh(
    new THREE.PlaneGeometry(5.8, 1.9),
    new THREE.MeshBasicMaterial({
      map: T.calligraphy('第一江山', { vertical: false, cols: 1, w: 1024, h: 340, ink: '#e6ecec', size: 0.84 }),
      transparent: true, color: new THREE.Color('#a7b1b2'),
    }),
  );
  word.material.toneMapped = false;
  word.position.set(0, f + 2.2, -0.82);
  word.rotation.y = Math.PI;
  g.add(word);

  lamps.push({ x: S.x - 7.5, y: f + 0.6, z: S.z - 2.6, kind: 'rake', t: 0.30, g: 'stele' });
  lamps.push({ x: S.x + 7.5, y: f + 0.6, z: S.z - 2.6, kind: 'rake', t: 0.32, g: 'stele' });

  grp.add(g);
  return { group: g, word, floorY: f };
}

/* -------------------------------------------------------------- 狠石与试剑石 */

function buildStones(grp) {
  const S = SITES.henStone;
  const g = new THREE.Group();
  g.position.set(S.x, S.y, S.z); // boulders are the exception: their local geometry starts at zero

  // 伏羊：一块横卧的巨石，头朝东
  const 羊 = blobGeometry(2.4, { detail: 2, amp: 0.22, squash: 0.6, seed: 31 });
  羊.scale(1.5, 1, 1.05);
  羊.translate(0, 0.9, 0);
  const head = blobGeometry(1.05, { detail: 2, amp: 0.2, squash: 0.8, seed: 77 });
  head.translate(3.4, 1.5, 0);
  const 羊m = mesh([羊, head], M.rockPlain);
  羊m.name = 'hen-shi';
  羊m.castShadow = true;
  g.add(羊m);
  // 腹上刻"狠石"
  const tag = new THREE.Mesh(
    new THREE.PlaneGeometry(1.3, 0.7),
    new THREE.MeshBasicMaterial({
      map: T.calligraphy('狠石', { vertical: false, cols: 1, w: 420, h: 200, ink: '#dfe6e6', size: 0.84 }),
      transparent: true, color: new THREE.Color('#93a09f'),
    }),
  );
  tag.material.toneMapped = false;
  tag.position.set(0.4, 1.85, 1.32);
  tag.rotation.x = -0.55;
  g.add(tag);

  // 试剑石：一分为二，缝平如削
  for (const sx of [-1, 1]) {
    const b = blobGeometry(2.2, { detail: 2, amp: 0.24, squash: 0.72, seed: 120 + sx * 13 });
    b.scale(1.05, 1, 0.86);
    b.translate(sx * 1.28, 1.3, -7.4);
    g.add(mesh(b, M.rockHill));
  }
  grp.add(g);
  return { group: g };
}

/* ------------------------------------------------------------------ 牌楼 */

/** 上山口的石牌楼：额书"北固山"（山名可核，牌楼形制与额书者皆补配） */
function buildGate(grp, lamps) {
  const S = SITES.gate;
  const g = new THREE.Group();
  g.position.set(S.x, 0, S.z);
  g.rotation.y = S.rot;
  const f = terrainHeight(S.x, S.z) + 0.1;

  const parts = [];
  for (const sx of [-8.2, -2.8, 2.8, 8.2]) parts.push(box(1.1, 6.8, 1.1, sx, f, 0));
  parts.push(box(19.4, 1.0, 1.3, 0, f + 6.8, 0));
  parts.push(box(15.0, 0.8, 1.2, 0, f + 8.4, 0));
  for (const sx of [-9.9, 9.9]) parts.push(box(1.4, 1.5, 1.4, sx, f + 7.8, 0));
  g.add(mesh(parts, M.stone));
  const roof = gabledRoof({ span: 20.4, depth: 2.6, rise: 1.2, eaveY: f + 7.8, lift: 0.5, cornerOut: 0.8 });
  g.add(mesh(roof.surface, TILE));
  const r2 = gabledRoof({ span: 16.0, depth: 2.2, rise: 1.1, eaveY: f + 9.2, lift: 0.5, cornerOut: 0.7 });
  g.add(mesh(r2.surface, TILE));
  const plaque = inscribed('北固山', 4.2, 1.4, { ink: '#e9eef0', size: 0.82, board: '#20262c', glow: '#20262c', ei: 0.3 });
  plaque.position.set(0, f + 7.4, -0.8);
  plaque.rotation.y = Math.PI;
  g.add(plaque);

  lamps.push({ x: S.x - 6, y: f + 5.4, z: S.z, kind: 'lantern', t: 0.06, g: 'gate' });
  lamps.push({ x: S.x + 6, y: f + 5.4, z: S.z, kind: 'lantern', t: 0.06, g: 'gate' });

  grp.add(g);
  return { group: g, floorY: f };
}

/* -------------------------------------------------------------- 铁瓮城标识 */

/**
 * 城址南北 480 米、东西最宽 300 米（可核），垣在地面下。
 * 这里只沿它的位置压一条低矮的灯沟与一段探沟断面——是标识，不是复原。
 */
function buildTieBeng(grp, lamps) {
  const cx = TOP.x + FEATURES.tiebeng.dx, cz = TOP.z + FEATURES.tiebeng.dz;
  const g = new THREE.Group();
  g.name = 'tiebeng';
  const NX = 480, EW = 300;

  const wall = [];
  const ring = 54;
  for (let i = 0; i < ring; i++) {
    const a = (i / ring) * Math.PI * 2;
    const x = cx + Math.cos(a) * (EW / 2), z = cz + Math.sin(a) * (NX / 2);
    const y = terrainHeight(x, z);
    const seg = new THREE.BoxGeometry(12, 0.55, 3.2);
    seg.rotateY(-a);
    seg.translate(x, y + 0.1, z);
    wall.push(seg);
    lamps.push({ x, y: y + 0.9, z, kind: 'trench', t: 0.14, g: 'gate' });
  }
  g.add(mesh(wall, M.cement));
  // 探沟断面：两条槽
  const cut = [];
  for (const dz of [-90, 60]) {
    cut.push(box(EW * 0.7, 0.5, 6.2, cx, terrainHeight(cx, cz + dz) + 0.05, cz + dz));
  }
  g.add(mesh(cut, M.dark));
  grp.add(g);
  return { group: g, cx, cz };
}
