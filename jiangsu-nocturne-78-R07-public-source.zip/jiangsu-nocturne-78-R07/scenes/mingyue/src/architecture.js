import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { M, box, mesh, rand, rr, chineseRoof, pillarGeo } from '../../src/kit.js';
import * as T from '../../src/textures.js';
import { YARD } from './data.js';
import {
  hallBuilding, yardWall, moonDoorWall, corridor, fanPavilion, gardenPavilion,
  rockMass, shadeTree, bambooClump, featureRock, moonWindow, wallCapGeo, stairGeo,
  plaqueMesh,
} from './parts.js';
import { pondOutline } from './water.js';

const HALL_NAME = '二分明月楼';
const GATE_COUPLET = ['春风阆苑三千客', '明月扬州第一楼'];
/** 园北廊壁今存张若虚《春江花月夜》砖刻，这里取其句 */
const POEM_LINES = [
  '春江潮水连海平',
  '海上明月共潮生',
  '滟滟随波千万里',
  '何处春江无月明',
  '可怜楼上月徘徊',
  '应照离人妆镜台',
];
const WELL_INSCRIPTION = '道光七年杏月员置';

/** 院内的碟瓦波文地：整块方地挖掉池子 */
function yardPaving() {
  const hx = YARD.wall.x - 0.35, hz = YARD.wall.z - 0.35;
  const shape = new THREE.Shape();
  shape.moveTo(-hx, -hz);
  shape.lineTo(hx, -hz);
  shape.lineTo(hx, hz);
  shape.lineTo(-hx, hz);
  shape.closePath();
  const pts = pondOutline(56);
  const hole = new THREE.Path();
  pts.forEach((p, i) => (i ? hole.lineTo(p.x, -p.y) : hole.moveTo(p.x, -p.y)));
  hole.closePath();
  shape.holes.push(hole);
  const geo = new THREE.ShapeGeometry(shape, 22);
  geo.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(geo, M.paving);
  m.position.y = 0.02;
  m.receiveShadow = true;
  m.name = 'paving';
  return m;
}

/** 阶条石：从月洞门斜斜铺到楼前 */
function stoneAxis() {
  const grp = new THREE.Group();
  const slab = new THREE.MeshStandardMaterial({
    color: '#b8bec9', map: T.stone('#949aa6'), roughness: 0.9, emissive: '#0c1120', emissiveIntensity: 0.4,
  });
  slab.map = slab.map.clone();
  slab.map.repeat.set(0.3, 0.22);
  for (let i = 0; i < 8; i++) {
    const t = i / 7;
    const x = -10.6 + t * 9.4;
    const z = 8.8 - t * 14.2;
    const s = mesh(box(2.1, 0.09, 1.5, x, 0.06, z), slab);
    s.rotation.y = -0.55 + Math.sin(i * 1.7) * 0.05;
    s.receiveShadow = true;
    grp.add(s);
  }
  return grp;
}

/** 园门：石券 + 门扇 + 砖雕门罩 + 石额 + 门联 */
function gateStructure() {
  const grp = new THREE.Group();
  const { x: gx, z: gz, w: gw, h: gh } = YARD.gate;

  const frame = [];
  for (const s of [-1, 1]) frame.push(box(0.42, gh, 0.7, gx + s * (gw / 2 + 0.2), gh / 2, gz));
  frame.push(box(gw + 0.9, 0.36, 0.72, gx, gh + 0.18, gz));
  grp.add(mesh(frame, M.stoneDressed));

  const leaves = [], brass = [];
  for (const s of [-1, 1]) {
    leaves.push(box(gw / 2 - 0.05, gh - 0.32, 0.12, gx + s * gw / 4, (gh - 0.32) / 2 + 0.14, gz));
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 3; c++) {
        const g = new THREE.SphereGeometry(0.045, 6, 5);
        g.translate(gx + s * gw / 4 - 0.3 + c * 0.3, 0.62 + r * 0.62, gz - 0.09);
        brass.push(g);
      }
    }
    const kn = new THREE.TorusGeometry(0.11, 0.03, 6, 14);
    kn.rotateY(Math.PI / 2);
    kn.translate(gx + s * 0.34, gh * 0.52, gz - 0.13);
    brass.push(kn);
  }
  const leafMesh = mesh(leaves, M.woodDark);
  leafMesh.castShadow = true;
  grp.add(leafMesh);
  grp.add(mesh(brass, M.gilt));

  // 砖雕门罩：三层叠涩出檐，上覆小瓦
  const tiers = [];
  for (let i = 0; i < 3; i++) {
    tiers.push(box(gw + 1.5 + i * 0.5, 0.34, 0.5 + i * 0.14, gx, gh + 0.62 + i * 0.36, gz - 0.1));
  }
  const canopy = mesh(tiers, M.brickWarm);
  canopy.castShadow = true;
  grp.add(canopy);
  const cap = new THREE.Mesh(wallCapGeo(gw + 2.9), M.wallCap);
  cap.position.set(gx, gh + 1.78, gz - 0.22);
  grp.add(cap);
  grp.add(mesh(
    Array.from({ length: 5 }, (_, i) => box(0.16, 0.5, 0.16, gx + (i - 2) * 0.62, gh + 0.42, gz - 0.36)),
    M.woodDark,
  ));

  const nameSlab = plaqueMesh(HALL_NAME, 0.78, 2.25, { dir: 'v', bg: '#2b3345', fg: '#e8e2d2', border: '#8f97a8' });
  nameSlab.position.set(gx, gh + 1.05, gz - 0.44);
  grp.add(nameSlab);

  GATE_COUPLET.forEach((text, i) => {
    const p = plaqueMesh(text, 0.52, 2.7, { dir: 'v', bg: '#7d1f1c', fg: '#f0d4a2', border: '#b98a45' });
    p.position.set(gx + (i === 0 ? -1 : 1) * (gw / 2 + 1.0), gh * 0.56, gz - 0.38);
    grp.add(p);
  });
  return grp;
}

/** 院墙四面：南门留洞，东墙与西墙开月形窗 */
function walls() {
  const grp = new THREE.Group();
  const { x: wx, z: wz, h } = YARD.wall;
  const g = YARD.gate;
  const gap = g.w / 2 + 1.25;
  grp.add(yardWall({ from: [-wx, wz], to: [g.x - gap, wz], height: h }));
  grp.add(yardWall({ from: [g.x + gap, wz], to: [wx, wz], height: h }));
  grp.add(yardWall({ from: [-wx, -wz], to: [wx, -wz], height: h + 0.3 }));
  grp.add(yardWall({ from: [-wx, -wz], to: [-wx, wz], height: h }));
  grp.add(yardWall({ from: [wx, -wz], to: [wx, wz], height: h }));

  for (const [z, kind, r] of [[2.2, 'full', 0.72], [8.2, 'crescent', 0.66], [-7.6, 'full', 0.6]]) {
    grp.add(moonWindow({ x: wx - 0.3, y: 2.5, z, r, kind, rotY: Math.PI / 2 }));
  }
  for (const [z, kind, r] of [[-2.4, 'crescent', 0.6], [6.0, 'full', 0.55]]) {
    grp.add(moonWindow({ x: -wx + 0.3, y: 2.4, z, r, kind, rotY: -Math.PI / 2 }));
  }
  grp.add(mesh(box(8, 1.3, 0.16, 3.0, 0.65, -wz + 0.36), M.moss));
  return grp;
}

/** 诗廊：西墙内侧一堵直砖墙，嵌六条《春江花月夜》砖刻 */
function poemWall() {
  const grp = new THREE.Group();
  const x = -12.75;
  const body = mesh(box(0.5, 3.5, 10.4, x, 1.75, 7.2), M.brickWarm);
  body.castShadow = true; body.receiveShadow = true;
  grp.add(body);
  grp.add(mesh(box(0.8, 0.22, 10.6, x, 3.6, 7.2), M.wallCap));
  POEM_LINES.forEach((line, i) => {
    const p = plaqueMesh(line, 0.62, 2.5, { dir: 'v', bg: '#3a2f22', fg: '#e7dcc2', border: '#7d6a4c' });
    p.position.set(x + 0.31, 1.95, 11.6 - i * 1.62);
    p.rotation.y = Math.PI / 2;
    grp.add(p);
  });
  return grp;
}

/** 古井：六角井亭 + 井栏刻款 */
function wellStructure() {
  const grp = new THREE.Group();
  const { x, z } = YARD.well;
  const curb = new THREE.Mesh(new THREE.CylinderGeometry(0.56, 0.62, 0.62, 6), M.stoneDressed);
  curb.position.set(x, 0.31, z);
  curb.castShadow = true;
  grp.add(curb);
  const mouth = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.1, 12), new THREE.MeshStandardMaterial({
    color: '#0a0d14', roughness: 0.6, metalness: 0.1, emissive: '#04060c', emissiveIntensity: 0.4,
  }));
  mouth.position.set(x, 0.62, z);
  grp.add(mouth);
  // 井亭：四柱 + 小攒尖
  // 井亭：矮，四柱，小攒尖，别抢主楼的天际线
  const roof = new THREE.Mesh(
    new THREE.ConeGeometry(1.05, 0.62, 4),
    M.wallCap,
  );
  roof.position.set(x, 1.58, z);
  roof.rotation.y = Math.PI / 4;
  roof.castShadow = true;
  grp.add(roof);
  const posts = [];
  for (const [dx, dz] of [[0.55, 0.55], [-0.55, 0.55], [-0.55, -0.55], [0.55, -0.55]]) {
    posts.push(new THREE.CylinderGeometry(0.09, 0.1, 1.24, 7).translate(x + dx, 0.62, z + dz));
  }
  grp.add(mesh(mergeGeometries(posts), M.pillar));
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), M.gilt);
  cap.position.set(x, 1.95, z);
  grp.add(cap);

  // 井栏侧壁的刻款：把它读成一块小石板
  const insc = plaqueMesh(WELL_INSCRIPTION, 0.72, 0.5, { dir: 'h', bg: '#818b98', fg: '#22283a', border: '#5d6673' });
  insc.position.set(x, 0.42, z + 0.66);
  insc.rotation.y = 0;
  grp.add(insc);
  return grp;
}

/** 月牙桥：1996 年复建时新设的那座，圆洞合着水里的倒影成一轮满月 */
function crescentBridge() {
  const grp = new THREE.Group();
  const { x, z, rot } = YARD.crescentBridge;
  grp.name='mingyue-crescent-bridge-at-north-pool';
  const span = 3.49, width = 1.04, rise = .49, archR = .65;
  const shape = new THREE.Shape();
  const hs = span / 2;
  shape.moveTo(-hs, -0.5);
  shape.lineTo(-hs, 0.16);
  const steps = 22;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    shape.lineTo(-hs + span * t, 0.16 + rise * Math.sin(Math.PI * t));
  }
  shape.lineTo(hs, 0.16);
  shape.lineTo(hs, -0.5);
  shape.closePath();
  const hole = new THREE.Path();
  // Low wide arch seen from the southern end of the pond.
  hole.moveTo(-archR,-.46);hole.lineTo(-archR,.075);
  for(let j=0;j<=28;j++){
    const a=Math.PI-j/28*Math.PI;hole.lineTo(Math.cos(a)*archR,.075+Math.sin(a)*.36);
  }
  hole.lineTo(archR,-.46);
  hole.closePath();
  shape.holes.push(hole);
  const g = new THREE.ExtrudeGeometry(shape, { depth: width, bevelEnabled: false, curveSegments: 20 });
  g.translate(0, 0, -width / 2);
  const deck = mesh(g, M.stoneDressed);
  deck.castShadow = true; deck.receiveShadow = true;
  grp.add(deck);
  // 栏杆：低栏板 + 两端望柱，桥身不高，栏子别高过人头
  const rails = [];
  const deckAt = (t) => 0.16 + rise * Math.sin(Math.PI * t);
  for (let i = -2; i <= 2; i++) {
    const t = (i + 2) / 4;
    const px = -hs + (span * t);
    const py = deckAt(t);
    for (const s of [-1, 1]) {
      rails.push(box(span / 4.2, 0.26, 0.07, px, py + 0.2, s * width / 2));
      rails.push(box(0.09, 0.44, 0.09, px, py + 0.26, s * width / 2));
    }
  }
  for (const s of [-1, 1]) {
    for (const t of [-1, 1]) {
      rails.push(box(0.12, 0.62, 0.12, s * (hs - 0.06), deckAt(s > 0 ? 1 : 0) + 0.34, t * width / 2));
    }
  }
  grp.add(mesh(rails, M.stone));
  grp.position.set(x, YARD.pond.y, z);
  grp.rotation.y = rot;
  return grp;
}

/** 2025 年具名照片北楼：低横屋面、七间两层，中心可辨较大木窗；不拿迎月楼当本体。 */
function photoNorthHall() {
  const q=YARD.hall,g=new THREE.Group();g.name='mingyue-seven-bay-northern-main-hall';g.position.set(q.x,0,q.z);
  const w=q.bays*q.bay,d=q.depth,hw=w*.5,hd=d*.5;
  const floor=q.plinth, porch=.99, front=hd+.64, y1=3.85,y2=6.72;
  const shell=mesh([box(w,.10,d,0,.4,0),box(w,y2-.4,.43,0,(y2+.40)*.5,-hd+.22),
    box(.41,y2-.4,d,-hw+.20,(y2+.4)*.5,0),box(.41,y2-.4,d,hw-.20,(y2+.4)*.5,0)],M.brickWarm);
  shell.castShadow=true;g.add(shell);
  const oak=M.woodDark.clone(), beam=M.beam.clone(), fill=M.stoneDressed.clone(), roofMat=M.wallCap.clone();
  oak.color.set('#7f6957');oak.emissive.set('#271c13');oak.emissiveIntensity=.39;
  beam.color.set('#665b50');beam.emissive.set('#2a211a');beam.emissiveIntensity=.3;
  fill.color.set('#9c9a91');roofMat.color.set('#a7aaa3');roofMat.emissive.set('#282d2e');roofMat.emissiveIntensity=.50;
  roofMat.roughness=.92;roofMat.metalness=.0;
  const lit=['#27292b','#3f3832','#695243','#99805d'].map((color,i)=>new THREE.MeshStandardMaterial({
    color,emissive:color,emissiveIntensity:[.02,.055,.11,.24][i],roughness:.89,
  }));
  const wood=[], base=[], bits=[], lattice=[], panes=[[],[],[],[]];
  base.push(box(w+.72,floor,d+2.02,0,floor*.5,.49));
  base.push(box(w+.81,.12,d+2.18,0,floor-.02,.49));
  const col=pillarGeo(y1-floor+.05,.138), upperCol=pillarGeo(y2-y1-.25,.111);
  for(let i=0;i<8;i++){
    const x=-hw+i*q.bay;
    const cc=new THREE.Mesh(col,oak);cc.position.set(x,floor,front+.50);g.add(cc);
    const up=new THREE.Mesh(upperCol,oak);up.position.set(x,y1+.36,front-.12);g.add(up);
    base.push(box(.428,.145,.50,x,floor+.07,front+.50));
    if(i===7)continue;
    const x0=x+q.bay*.50;
    for(const [level,y,h,z] of [[0,2.06,2.83,hd+.066],[1,5.34,2.25,hd+.11]]){
      const isMid=i===3, n=isMid && level===0?5:4, tw=isMid?q.bay*.92:q.bay*.84;
      const wh=h-.32;
      for(let j=0;j<n;j++){
        const c=x0-tw/2+(j+.5)*tw/n;
        const paneWidth=tw/n;
        panes[i===3&&level===0?1:((i+j*2+level)%11===1?3:(i+j+level)%3)].push(box(paneWidth-.036,wh,.052,c,y,z));
        wood.push(box(.049,h,.131,c-paneWidth*.5,y,z+.055));
        if(level===1||!isMid) {
          for(let k=0;k<4;k++) bits.push(box(.022,h*.56,.062,c-.24*paneWidth+k*.16*paneWidth,y+.28,z+.104));
          for(const dy of [.34,.62])lattice.push(box(paneWidth*.92,.024,.043,c,y+dy,z+.109));
        }
      }
      for(const dy of [-.42,-.21,.22,.45])lattice.push(box(tw,.045,.071,x0,y+h*dy,z+.089));
      wood.push(box(tw+.20,.139,.27,x0,y+h*.52,z+.052),box(tw+.22,.10,.22,x0,y-h*.51,z+.051));
    }
    // 偏低的平座靠栏；木皮透出室内暗格，避免一排发亮金纸。
    const railingZ=front+.084;
    wood.push(box(q.bay*.91,.072,.122,x0,y1+.82,railingZ),box(q.bay*.91,.075,.117,x0,y1+.31,railingZ));
    for(let j=0;j<10;j++)bits.push(box(.06,.47,.068,x0+(j-4.5)*q.bay*.085,y1+.55,railingZ));
  }
  base.push(box(w+.53,.18,1.34,0,y1+.09,front-.31));
  wood.push(box(w+.23,.26,.35,0,y1-.17,front+.38),box(w+.29,.233,.30,0,y2-.17,front+.10));
  g.add(mesh(base,fill),mesh(wood,oak),mesh(bits,beam),mesh(lattice,M.woodDark));
  for(let i=0;i<panes.length;i++)g.add(mesh(panes[i],lit[i]));
  // 灰瓦檐横展，无高耸鸱吻。短瓦端各为真实圆柱截面，室外不打满檐灯带。
  function roof(y,z,width,dd,hh) {
    const pane=new THREE.Mesh(chineseRoof({width,depth:dd,height:hh,eaveLift:.27,
      overhang:.43,curve:.59,hip:false,segU:50,segV:16}),roofMat);
    pane.position.set(0,y,z);pane.castShadow=true;g.add(pane);
    const frontEdge=z+dd*.5+.44, trim=[], tiles=[];
    trim.push(box(width+.77,.144,.19,0,y-.055,frontEdge-.02),box(width*.96,.13,.23,0,y+hh+.04,z));
    for(let i=0;i<96;i++){
      const x=-width*.485+(i+.5)*width*.97/96;
      const rib=new THREE.CylinderGeometry(.049,.056,.23,6,1);rib.rotateX(Math.PI/2);
      rib.translate(x,y+.036,frontEdge-.030);tiles.push(rib);
    }
    g.add(mesh(trim,beam),mesh(tiles,roofMat));
  }
  roof(y2,.14,w+.46,d+1.12,1.67);
  roof(y1+.11,hd+.07,w+.35,2.38,.55);
  const board=plaqueMesh(HALL_NAME,2.81,.61,{dir:'h',bg:'#272521',fg:'#d0b293',border:'#8c7050'});
  board.position.set(0,y2-.46,front+.20);g.add(board);
  const steps=mesh(stairGeo(3,.28,floor/3,4.70),fill);steps.rotation.y=Math.PI;
  steps.position.set(0,.016,hd+1.7);g.add(steps);
  g.userData.lamps=[new THREE.Vector3(-q.bay*1.52,2.96,hd+.92),new THREE.Vector3(q.bay*1.46,2.96,hd+.92)];
  return g;
}

/** 2001 具名池廊照片的轻石岸。亭与迎月楼仍是独立单体，廊后粉墙只为它们作衬。 */
function photoPoolWalk() {
  const g=new THREE.Group();g.name='mingyue-west-pool-coping-and-white-corridor';
  const x=-8.42,z0=-1.16,z1=9.90,total=z1-z0;
  const plaster=M.wall.clone();plaster.color.set('#bcb7aa');plaster.emissive.set('#242321');plaster.emissiveIntensity=.34;
  const coping=M.stoneDressed.clone();coping.color.set('#9e9e93');
  const steps=[], bands=[], wetBase=[];
  steps.push(box(2.72,.227,total,x+.48,.14,(z0+z1)*.5));
  bands.push(box(.36,.135,total,-6.72,.20,(z0+z1)*.5));
  wetBase.push(box(.20,.277,total,-6.764,-.027,(z0+z1)*.5));
  for(let i=0;i<13;i++){
    const cz=z0+(i+.5)*total/13;
    steps.push(box(2.57,.015,total/13-.026,x+.36,.264,cz));
    if(i%3===0)bands.push(box(.24,.342,.24,-6.66,-.018,cz));
  }
  const w=mesh(box(.30,2.22,total-.52,-9.56,1.20,(z0+z1)*.5-.19),plaster);
  w.castShadow=true;w.receiveShadow=true;g.add(w);
  for(const z of [-.14,2.47,5.18,7.62]){
    const plaque=mesh(box(.025,.64,.52,-9.39,1.54,z),M.woodDark);g.add(plaque);
  }
  g.add(mesh(wetBase,M.stoneDark),mesh(steps,coping),mesh(bands,M.stoneSlab));
  return g;
}

/** 只在西廊前留一株下垂柳；叶片小而非大块镜面精灵。 */
function galleryWillow(){
  const g=new THREE.Group();g.name='mingyue-willow-waterline';
  const b=M.woodDark.clone();b.color.set('#5a493b');
  const leaf=new THREE.MeshStandardMaterial({color:'#546149',roughness:.89,side:THREE.DoubleSide});
  const V=(x,y,z)=>new THREE.Vector3(x,y,z);
  const treePaths=[
    [[0,0,0],[-.13,1.8,.06],[.17,3.24,-.02],[.39,4.71,.28]],
    [[-.10,2.09,.11],[-.43,3.11,.13],[-.85,3.76,.52],[-1.37,4.02,.81]],
    [[.08,2.61,-.07],[.57,3.36,-.43],[1.32,3.94,-.64],[1.72,4.09,-.47]],
    [[.10,2.48,.1],[.31,3.74,.62],[.65,4.03,1.08],[.79,4.21,1.38]],
    [[.13,2.86,-.13],[.08,4.05,-.74],[.44,4.50,-1.08],[.73,4.48,-1.45]],
  ];
  treePaths.forEach((q,i)=>g.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(q.map(v=>V(...v))),14,i===0?.13:.046,6,false),b)));
  const leaves=new THREE.BufferGeometry();
  leaves.setAttribute('position',new THREE.Float32BufferAttribute([0,-.11,0,-.034,.038,.01,0,.162,0,0,-.11,0,0,.162,0,.034,.03,-.01],3));leaves.computeVertexNormals();
  const N=650, im=new THREE.InstancedMesh(leaves,leaf,N), q=new THREE.Object3D(), color=new THREE.Color();
  for(let i=0;i<N;i++){
    const f=i/N, limb=Math.floor(i/65), k=(i%65)/65,t=i*2.39996;
    const x=Math.cos(limb*.628)*1.32+Math.cos(t)*k*.64, z=Math.sin(limb*.628)*1.48+Math.sin(t)*k*.62;
    q.position.set(x+.28,4.81-k*(2.09+Math.sin(i*.92)*.39)-f*.28,z);
    q.rotation.set(Math.sin(t)*.36,t,Math.cos(t*.39)*.48);
    q.scale.setScalar(.66+(.5+Math.sin(i*1.7)*.5)*.63);q.updateMatrix();im.setMatrixAt(i,q.matrix);
    im.setColorAt(i,color.setRGB(.50+.21*Math.sin(i),.56+.17*Math.cos(i*1.8),.42+.12*Math.sin(t)));
  }
  im.computeBoundingSphere();g.add(im);g.position.set(-6.94,.05,3.21);return g;
}

/** 东侧池墙留小圆漏窗，弱化另立亭廊对中轴主楼的遮挡。 */
function photoEastScreen(){
  const g=new THREE.Group();
  g.name='mingyue-low-east-white-screen';
  const pl=M.wall.clone();pl.color.set('#a9a7a0');pl.emissive.set('#282723');pl.emissiveIntensity=.25;
  const W=4.42,H=2.53, h=new THREE.Shape();
  h.moveTo(-W/2,0);h.lineTo(W/2,0);h.lineTo(W/2,H);h.lineTo(-W/2,H);h.closePath();
  const k=new THREE.Path();k.absarc(.44,1.48,.38,0,2*Math.PI,true);h.holes.push(k);
  const solid=new THREE.ExtrudeGeometry(h,{depth:.28,steps:1,bevelEnabled:false,curveSegments:21});
  solid.translate(0,0,-.14);g.add(mesh(solid,pl));
  const cap=mesh(wallCapGeo(W+.15),M.wallCap);cap.position.y=H;g.add(cap);
  g.add(mesh(box(W+.17,.29,.37,0,.145,0),M.stoneDark));
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.387,.033,6,24),M.stoneDressed);
  ring.position.set(.44,1.48,.146);g.add(ring);
  g.position.set(7.49,0,3.35);g.rotation.y=-Math.PI/2;return g;
}

/** 环院的楼、阁、亭：位置照园中格局 */
function flankingBuildings() {
  const grp = new THREE.Group();
  const dongge = hallBuilding({
    bays: 3, bayW: 2.8, depth: 4.2, floors: 1, h1: 3.6, plinth: 0.5,
    porch: 1.3, roofH: 1.6, x: YARD.dongge.x, z: YARD.dongge.z, facing: -Math.PI / 2,
    plaque: '东阁', windows: 0.7, wallMat: M.brickWarm,
  });
  const xizhao = hallBuilding({
    bays: 3, bayW: 2.9, depth: 4.4, floors: 2, h1: 3.3, h2: 2.7, plinth: 0.42,
    porch: 1.1, roofH: 1.55, x: YARD.xizhao.x, z: YARD.xizhao.z, facing: -Math.PI / 2,
    plaque: '夕照', plaqueOpts: { bg: '#1a2a1e', fg: '#efe6c8', note: '集板桥' },
  });
  const yingyue = hallBuilding({
    bays: 3, bayW: 2.9, depth: 4.4, floors: 2, h1: 3.5, h2: 2.9, plinth: 0.42,
    porch: 1.2, roofH: 1.7, x: YARD.yingyue.x, z: YARD.yingyue.z, facing: Math.PI / 2,
    plaque: '迎月', plaqueOpts: { bg: '#10233c' },
  });
  grp.add(dongge, xizhao, yingyue);
  return { grp, hosts: [dongge, xizhao, yingyue] };
}

/* ------------------------------------------------------------------ 组装 */
export function buildGarden(scene) {
  const group = new THREE.Group();
  group.name = 'garden';

  group.add(yardPaving());
  group.add(stoneAxis());
  group.add(walls());
  group.add(gateStructure());
  group.add(poemWall());
  group.add(wellStructure());
  group.add(moonDoorWall({
    x0: YARD.moonWall.x0, x1: YARD.moonWall.x1, z: YARD.moonWall.z,
    cx: YARD.moonWall.cx, r: YARD.moonWall.r, height: YARD.moonWall.h,
  }));

  const hall = photoNorthHall();
  group.add(hall);

  const flank = flankingBuildings();
  group.add(flank.grp);
  flank.hosts[2].name='mingyue-separate-yingyue-southwest';

  // 黄石假山在园东，三间东阁依山而筑
  const hill = rockMass({ spread: YARD.rockery.spread, peak: YARD.rockery.peak });
  hill.position.set(YARD.rockery.x, 0, YARD.rockery.z);
  group.add(hill);

  // 扇面亭（梅溪吟榭）探进池里
  const fan = fanPavilion({ backR: 2.83, frontR: 1.41, spread: 1.55, pillarH: 2.20, roofH: .82 });
  fan.name = 'mingyue-meixi-south-fan-pavilion';
  fan.position.set(YARD.fanPavilion.x, 0, YARD.fanPavilion.z);
  fan.rotation.y = YARD.fanPavilion.rot;
  group.add(fan);

  // 平廊里的伴月亭
  const banyue = gardenPavilion({ sides: 4, radius: 1.7, pillarH: 2.45, roofH: 1.6, plinth: 0.24, openSide: 2 });
  banyue.position.set(YARD.banyue.x, 0, YARD.banyue.z);
  banyue.rotation.y = Math.PI / 2;
  banyue.name='mingyue-banyue-moon-company-pavilion';
  group.add(banyue);
  const top=new THREE.Group();top.name='mingyue-banyue-raised-eave';
  const upper=new THREE.Mesh(chineseRoof({width:2.43,depth:2.57,height:.92,overhang:.37,curve:.67,eaveLift:1.3,hip:true,ridgeRatio:.15,segU:22,segV:14}),M.wallCap);
  upper.position.y=4.59;top.add(upper);
  const trim=[];
  for(const a of [-1,1])for(const b of [-1,1])trim.push(box(.11,1.05,.11,a*.54,4.12,b*.54));
  top.add(mesh(trim,M.woodDark));banyue.add(top);
  const banyueSlab = plaqueMesh('伴月', 1.4, 0.52, { dir: 'h', bg: '#22301f', fg: '#efe6c8', note: '集金农' });
  banyueSlab.position.set(YARD.banyue.x, 2.38, YARD.banyue.z + 1.62);
  group.add(banyueSlab);

  // 三条廊：入园的平廊、上楼的爬廊、池北的敞廊
  group.add(photoPoolWalk(),galleryWillow());
  group.add(corridor({
    points: [[YARD.flatWalk.x, YARD.flatWalk.zFrom], [YARD.flatWalk.x, YARD.flatWalk.zTo]],
    width: 1.74, bayLen: 2.26, height: 2.53, pillarR:.11, z0:.10,
  }));
  group.add(corridor({
    points: [[-8.57, -.76], [-10.15, -2.60], [-11.91, -4.46], [-11.80, -7.24]],
    ys: [0, 1.5, 3.0, 4.35], width: 2.1, bayLen: 2.3, height: 2.5,
  }));
  group.add(photoEastScreen());

  group.add(crescentBridge());

  // 植栽：竹在墙角，古木压住东与北，树下点石
  const plants = new THREE.Group();
  for (const [x, z, s] of [[-15.4, 10.6, 1.2], [-15.8, -8.6, 0.95], [15.6, 10.2, 1.0], [2.2, 12.2, 0.8]]) {
    const b = bambooClump({ n: 7 + Math.round(rand() * 5), h: 4.2 * s + rr(0, 1) });
    b.position.set(x, 0, z);
    plants.add(b);
  }
  for (const [x, z, h, blossom] of [[-14.6, -11.0, 5.4, false], [9.2, 11.0, 4.2, true], [-8.4, 0.4, 3.6, false]]) {
    const t = shadeTree({ h, crown: h * 0.36, blossom });
    t.position.set(x, 0, z);
    plants.add(t);
  }
  for (const [x, z, s] of [[1.2, 8.6, 1.0], [-6.2, 1.8, 0.8], [6.4, -5.6, 0.7], [10.2, 2.4, 1.1]]) {
    const r = featureRock(s);
    r.position.set(x, s * 0.25, z);
    plants.add(r);
  }
  // 池里的汀屿：旱园水做的另一笔
  for (const [x, z, s] of [[-5.34, 5.85, .59], [4.66, 2.19, .42], [.41, -2.82, .32]]) {
    const isle = featureRock(s);
    isle.position.set(x, -0.02, z);
    plants.add(isle);
  }
  group.add(plants);

  // 楼前的台阶
  const steps = stairGeo(4, 0.42, 0.16, 5.2);
  const sm = mesh(steps, M.stoneDressed);
  sm.position.set(0, 0, YARD.hall.z + YARD.hall.depth / 2 + YARD.hall.plinth + 1.6);
  sm.rotation.y = Math.PI;
  group.add(sm);

  // A little light on posts and sill, not a blanket wall wash mistaken for actual night lighting.
  const gLamp=new THREE.PointLight('#ffd1a0',8,8.6,2);
  gLamp.position.set(-7.7,2.61,3.13);
  const hallLamp=new THREE.PointLight('#d0c4b6',25,17,2);
  hallLamp.position.set(4.35,3.74,-2.72);
  scene.add(group,gLamp,hallLamp);
  group.updateMatrixWorld(true);

  const anchors = [];
  for (const host of [hall, ...flank.hosts, fan, banyue]) {
    for (const lamp of host.userData.lamps || []) {
      const p = lamp.clone().applyMatrix4(host.matrixWorld);
      anchors.push({ p: p.clone(), kind: 'eave' });
      anchors.push({ p: p.clone().setY(p.y - 0.15), kind: 'lantern' });
    }
  }
  return { group, anchors, hall };
}
