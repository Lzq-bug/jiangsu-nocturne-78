import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { M, lit, chineseRoof, pavilion, rr, rand } from './kit.js';

/** 抱山楼实景楼面、前园湖石与低池水口。三处模型各不混名。 */
export function buildBaoshanCourt(spec) {
  const group=new THREE.Group();group.name='抱山楼与北岸廊窗';
  const patches=new Map();
  const V=(x,y,z)=>new THREE.Vector3(x,y,z);
  const cube=new THREE.BoxGeometry(),rock=new THREE.IcosahedronGeometry(1,2);
  const grain=[M.beam,M.pillarDark,M.woodFloor], timber=lit('#6a4a37',{rough:.83,emissive:'#5c3a20',ei:.31});
  const black=lit('#302924',{rough:.91,emissive:'#372719',ei:.26});
  const muslin=lit('#9e7e57',{rough:.94,emissive:'#b48046',ei:.34});
  const muted=lit('#80705d',{rough:.96,emissive:'#75583b',ei:.23});
  const stones=['#7c7d75','#85837a','#969282','#737974','#777571'].map(c=>lit(c,{rough:.94,side:THREE.DoubleSide,emissive:'#2a3540',ei:.34}));
  const leaves=['#28392d','#354337','#414e37'].map(c=>lit(c,{rough:.98,emissive:'#202d29',ei:.27}));
  const lantern=lit('#764c33',{rough:.85,emissive:'#b96330',ei:.46});
  function add(g,m,at=V(0,0,0),s=V(1,1,1),r=0,q){
    const b=g.index?g.toNonIndexed():g.clone();
    b.applyMatrix4(new THREE.Matrix4().compose(at,q??new THREE.Quaternion().setFromAxisAngle(V(0,1,0),r),s));
    if(!patches.has(m))patches.set(m,[]);patches.get(m).push(b);
  }
  const box=(m,w,h,d,x,y,z,r=0)=>add(cube,m,V(x,y,z),V(w,h,d),r);
  function bar(m,a,b,w,d=w){
    const delta=b.clone().sub(a);add(cube,m,a.clone().lerp(b,.5),V(w,delta.length(),d),0,new THREE.Quaternion().setFromUnitVectors(V(0,1,0),delta.normalize()));
  }
  function ellipse(m,x,y,z,w,h,d,turn=0){
    const g=rock.clone(),pos=g.attributes.position;
    for(let i=0;i<pos.count;i++){
      const px=pos.getX(i),py=pos.getY(i),pz=pos.getZ(i);
      const k=1+.22*Math.sin(7.2*px+6.45*py)*Math.cos(4.7*pz-2.8*px)+.08*Math.sin(17*py-3*pz);
      pos.setXYZ(i,px*k,py*(1+.11*Math.sin(px*9.1+pz*7.8)),pz*k);
    }
    g.computeVertexNormals();add(g,m,V(x,y,z),V(w,h,d),turn);g.dispose();
  }
  function light(x,y,z,power,range,color='#ffdab1'){
    const l=new THREE.PointLight(color,power,range,2);l.position.set(x,y,z);group.add(l);
    return l;
  }
  const lx=spec.x,lz=spec.z,W=spec.w,D=spec.d;
  const face=lz+D/2+.49, back=face-1.47;
  // Earth-level footing, a continuous eaves deck, and inset walls instead of two stamped roof objects.
  box(stones[0],W+1.16,.42,D+.94,lx,.17,lz);
  for(let j=0;j<=29;j++){
    box(stones[(j+2)%5],1.025,.241,.116,lx+j*1.023-W*.49,.183,face+.02);
  }
  box(stones[2],W+1.20,.11,D+.97,lx,.398,lz);
  box(timber,W+.30,.21,D+.14,lx,3.52,lz);
  box(grain[2],W+.42,.082,D+.38,lx,3.65,lz);
  box(black,W-.33,5.87,D-2.68,lx,3.34,lz-.70);
  for(let level=0;level<2;level++){
    const y=level===0?.48:3.70,h=level===0?2.92:2.55, spans=level===0?7:11, width=W/spans;
    box(timber,W+.31,.20,.149,lx,y+h-.058,face-.08);
    for(let j=0;j<=spans;j++){
      const x=lx+(j/spans-.5)*W;
      box(level===0?timber:grain[1],.125,h,.126,x,y+h*.5,face-.095);
      box(stones[1],.227,.126,.240,x,y+.062,face-.096);
      for(let k=0;k<3;k++)box(grain[k],.28+k*.095,.084,.21+k*.075,x,y+h-.257+k*.069,face-.125);
      if(j===spans)continue;
      const x0=x+.13,x1=x+width-.13,c=(x0+x1)*.5;
      box(level===0?grain[2]:black,width-.231,.154,.14,c,y+.107,back);
      const bright=(j+level)%3!==1;
      box(bright?muslin:muted,width*.80,h*.52,.078,c,y+h*.54,back);
      for(let k=0;k<8;k++){
        const p=c+(k-3.5)*width*.091;
        box(grain[1],.052,h*.55,.072,p,y+h*.536,back+.045);
        if((j+k)%4===2)box(timber,.040,h*.33,.077,p+.066,y+h*.53,back+.052);
      }
      for(let k=0;k<4;k++)box(timber,width*.84,.043,.083,c,y+h*(.282+k*.153),back+.052);
      if(level>0){
        box(timber,width-.026,.057,.107,x+width*.5,y+.647,face+.035);
        box(grain[1],width-.026,.07,.078,x+width*.5,y+.12,face+.035);
        box(timber,width-.066,.103,.081,x+width*.5,y+.32,face+.035);
        for(let k=0;k<=11;k++)box(grain[k%3],.048,.46,.048,x+width*(k/11),y+.38,face+.086);
      }
    }
  }
  // The single continuous subdued tile crest is what makes the long building readable.
  const roof=chineseRoof({width:W+.59,depth:D+.30,height:2.08,ridgeRatio:.90,overhang:.30,curve:.23,eaveLift:.22,segU:52,segV:18,hip:false});
  add(roof,M.roofDark,V(lx,6.44,lz));roof.dispose();
  box(M.ridge,W+1.17,.12,.19,lx,8.54,lz);
  for(const s of [-1,1]){
    box(black,W+1.15,.148,.103,lx,6.48,lz+s*(D/2+.459));
    for(let j=0;j<51;j++)box(timber,.063,.073,.128,lx+(j-25)*W/50,6.428,lz+s*(D/2+.44));
  }

  // 白底匾，字为项目独立排字，不采原匾的书法图像。
  const canvas=document.createElement('canvas');canvas.width=640;canvas.height=180;
  const ctx=canvas.getContext('2d');
  ctx.fillStyle='#cdc6a9';ctx.fillRect(0,0,640,180);ctx.strokeStyle='#665448';ctx.lineWidth=6;ctx.strokeRect(10,10,620,160);
  ctx.fillStyle='#343029';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='600 104px "Noto Serif CJK SC", "STKaiti",SimSun,serif';
  ['春','自','天','壺'].forEach((c,i)=>ctx.fillText(c,112+i*137,97));
  const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;
  const sign=new THREE.Mesh(new THREE.PlaneGeometry(3.27,.94),new THREE.MeshStandardMaterial({map:tex,roughness:.92,emissive:'#b59059',emissiveIntensity:.21}));
  sign.name='白底壶天自春';sign.position.set(lx+.02,4.07,face+.189);group.add(sign);
  light(lx-.3,4.49,face+1.28,5.7,4.8);
  light(lx+7.3,1.89,face+1.10,5.2,4.2);
  light(lx-6.6,2.37,face+.92,4.9,4.4);

  // A walkable west bank; low islands of layered limestone break up the night highlight instead of a high retaining wall.
  const pocket=[[7.95,-25.7],[7.35,-22],[10.12,-20.12],[14.3,-20],[16.1,-19.7],[19,-19.5],[21.4,-20],[24.5,-22.4],[24.2,-25.6],[21.6,-28.4],[18.6,-29.55],[15.1,-29.7],[12.6,-27.6]];
  for(let k=0;k<pocket.length;k++){
    const [x,z]=pocket[k],[ex,ez]=pocket[(k+1)%pocket.length];
    for(let j=0;j<3;j++){
      const f=(j+rr(.15,.82))/3, xx=THREE.MathUtils.lerp(x,ex,f), zz=THREE.MathUtils.lerp(z,ez,f);
      const s=.28+rand()*.56;ellipse(stones[(j+2*k)%5],xx,.20+s*.43,zz,s,rr(.32,.51)*s+.20,s*.69,rr(0,7));
    }
  }
  // Left and right silhouettes have unequal heights, with shrubs between rather than a row of boulders.
  for(const [x,z,h,k] of [[-13.8,-22.8,1.48,.87],[-15.6,-24.2,1.91,.65],[-11.1,-24.8,1.43,.70],[-17.75,-28.4,1.66,.83],[8.12,-25.46,1.04,.68],[7.13,-21.5,.59,.53],[21.3,-20.2,1.69,.98],[23.6,-24.9,1.76,1.03],[16.1,-29.8,.71,.84]]){
    ellipse(stones[2],x,h*.39,z,k,h*.42,k*.68,rr(0,7));
    ellipse(stones[1],x+rr(-.22,.23),h*.81,z+rr(-.22,.23),k*.64,h*.188,k*.54,rr(0,7));
  }
  for(let j=0;j<42;j++){
    const [cx,cz]=j%3===0?[-14.8,-25.0]:j%3===1?[10.85,-23.2]:[22.9,-27.6];
    const x=cx+rr(-1.26,1.26),z=cz+rr(-1.17,1.17),s=rr(.22,.46);
    add(rock,leaves[j%3],V(x,.24+s*.23,z),V(s,s*.66,s*.91),rr(0,7));
  }

  // Genuine rock aperture, not a black disk. The contour is irregular in every depth slice.
  const ax=-12.69, az=-23.7, ah=1.82;
  const seg=27, xyz=[],uv=[];
  function contour(i,band,dz){
    const t=i/seg*Math.PI*2, c=Math.cos(t),s=Math.sin(t);
    const edge=1+.15*Math.cos(5*t+.6)+.17*Math.sin(2*t-.43)+.055*Math.cos(9*t+1.8);
    const x=ax+c*(band===0?.77:1.40)*edge+.13*s+.041*dz;
    const y=ah+s*(band===0?.90:1.72)*edge+.078*c;
    return V(x,y,az+dz*(band===0?.78:1)+.158*Math.sin(t*2-.38));
  }
  const strip=(a,b,c,d)=>{
    xyz.push(...a,...b,...c,...c,...b,...d);
    uv.push(0,0,1,0,0,1,0,1,1,0,1,1);
  };
  const depths=[-.46,-.15,.14,.49];
  for(let j=0;j<seg;j++){
    strip(contour(j,0,-.46),contour(j+1,0,-.46),contour(j,1,-.46),contour(j+1,1,-.46));
    strip(contour(j,1,.49),contour(j+1,1,.49),contour(j,0,.49),contour(j+1,0,.49));
    for(const band of [0,1])for(let k=0;k<depths.length-1;k++)strip(contour(j,band,depths[k]),contour(j+1,band,depths[k]),contour(j,band,depths[k+1]),contour(j+1,band,depths[k+1]));
  }
  const aperture=new THREE.BufferGeometry();aperture.setAttribute('position',new THREE.Float32BufferAttribute(xyz,3));aperture.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));aperture.computeVertexNormals();
  add(aperture,M.rockLake);aperture.dispose();
  ellipse(stones[2],ax-1,.38,az-.39,.66,.58,.49,.3);
  ellipse(stones[3],ax+1.03,.41,az+.25,.68,.61,.64,1.3);
  ellipse(stones[2],ax+.87,ah+.72,az+.27,.42,.88,.48,.44);
  ellipse(stones[1],ax-.94,ah+.48,az+.06,.34,.54,.49,1.1);
  ellipse(stones[0],ax-.65,ah+1.43,az-.13,.75,.31,.57,2.3);
  light(ax+1.6,.66,az+1.17,3.6,4.8,'#cbd4db');

  // An unlabelled right shore pavilion only; never identify it as another named hall.
  const q=pavilion({shape:'hex',size:2.75,height:2.38,roofH:1.22,posts:6,terrace:.26});
  q.position.set(19.4,.13,-31.53);q.rotation.y=.19;group.add(q);
  box(stones[3],5.96,.24,3.95,19.4,.105,-31.99);
  light(19.5,2.00,-31.04,5.5,4.1);
  box(timber,.073,.36,.078,18.68,2.63,-30.22);
  add(rock,lantern,V(18.68,2.40,-30.22),V(.136,.155,.136));
  for(const [m,all] of patches){
    const g=mergeGeometries(all);if(!g)throw Error('Geyuan court mesh batch layout');
    all.forEach(s=>s.dispose());
    const draw=new THREE.Mesh(g,m);draw.receiveShadow=true;draw.castShadow=m!==muslin&&m!==muted;group.add(draw);
  }
  cube.dispose();rock.dispose();
  return {group,setWindow(k){const a=Math.min(1.65,Math.max(0,k));muslin.emissiveIntensity=.08+.36*a;muted.emissiveIntensity=.04+.22*a;}};
}
