/** Rebuild only Geyuan, preserving collection calibration and mode guards. */
import { mkdtemp, copyFile, readdir, rename, rm, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const repo = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const pano = join(repo, 'public/pano');
const out = process.argv[2] ? resolve(process.argv[2]) : join(pano, 'geyuan.html');
const scratch = await mkdtemp(join(tmpdir(),'geyuan-calibrate-'));
const file = join(scratch,'geyuan.html');
const temporary = out + '.build-' + process.pid;
const run = (...args) => execFileSync(process.execPath,args,{cwd:repo,stdio:'inherit'});
try {
  const names = (await readdir(pano)).filter(x => x.endsWith('.html') && x !== 'geyuan.html');
  await Promise.all(names.map(n => copyFile(join(pano,n),join(scratch,n))));
  run('scenes/tools/build-single.mjs','geyuan/index.html','geyuan/src/main.js',file);
  await writeFile(file,(await readFile(file,'utf8'))
    .replace(/^[ \t]+(?=material = getMaterial\( data\.material \);$)/gm,'\t\t\t\t')
    .replace(/^[ \t]+$/gm,''));
  const calibrators = ['scenes/tools/refine-native-panorama-look.mjs','scenes/tools/guard-native-panorama-mode.mjs'];
  for (const script of calibrators) run(script,scratch);
  for (const script of calibrators) run(script,scratch,'--check');
  await copyFile(file,temporary); await rename(temporary,out);
} finally {
  await rm(scratch,{recursive:true,force:true}); await rm(temporary,{force:true});
}
