/** Rebuild only Jinshan, preserving collection calibration and mode guards. */
import { mkdtemp, copyFile, readdir, rename, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const repo = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const pano = join(repo, 'public/pano');
const out = process.argv[2] ? resolve(process.argv[2]) : join(pano, 'jinshan.html');
const scratch = await mkdtemp(join(tmpdir(),'jinshan-calibrate-'));
const file = join(scratch,'jinshan.html');
const temporary = out + '.build-' + process.pid;
const run = (...args) => execFileSync(process.execPath,args,{cwd:repo,stdio:'inherit'});
try {
  const names = (await readdir(pano)).filter(x => x.endsWith('.html') && x !== 'jinshan.html');
  await Promise.all(names.map(n => copyFile(join(pano,n),join(scratch,n))));
  run('scenes/jinshan/tools/build-single.mjs',file);
  const calibrators = ['scenes/tools/refine-native-panorama-look.mjs','scenes/tools/guard-native-panorama-mode.mjs'];
  for (const script of calibrators) run(script,scratch);
  for (const script of calibrators) run(script,scratch,'--check');
  await copyFile(file,temporary); await rename(temporary,out);
} finally {
  await rm(scratch,{recursive:true,force:true}); await rm(temporary,{force:true});
}
