/** Present-day 93.157 m steel/glass heritage protection tower. True volumes,
 * measured overall height, photo-guided proportions, no event projections. */
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { lit } from '../../src/kit.js';

const N=8, dA=Math.PI/4, rot=Math.PI/8;
const V=(x,y,z)=>new THREE.Vector3(x,y,z);
const rim=(r,a,y)=>V(Math.sin(a)*r,y,Math.cos(a)*r);
const lerp=(a,b,t)=>a.clone().lerp(b,t);
function quad(a,b,c,d){
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute([...a.toArray(),...b.toArray(),...c.toArray(),...d.toArray()],3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,1,1,0,1],2));
  g.setIndex([0,1,2,0,2,3]);g.computeVertexNormals();return g;
}
function link(a,b,w,d=w){
  const e=b.clone().sub(a),q=new THREE.Quaternion().setFromUnitVectors(V(0,1,0),e.clone().normalize());
  return new THREE.BoxGeometry(w,e.length(),d).applyQuaternion(q).translate(...a.clone().add(b).multiplyScalar(.5).toArray());
}
const box=(w,h,d,x,y,z,r=0)=>new THREE.BoxGeometry(w,h,d).rotateY(r).translate(x,y,z);
const cyl=(r0,r1,h,y,n=N)=>new THREE.CylinderGeometry(r1,r0,h,n).rotateY(rot).translate(0,y,0);
function combine(root,parts,mat,name){
  const g=mergeGeometries(parts.map(x=>x.index?x.toNonIndexed():x));
  const m=new THREE.Mesh(g,mat);m.name=name;root.add(m);return m;
}

export function buildModernTower(scene){
  const root=new THREE.Group();root.name='contemporary-protection-site';scene.add(root);
  const dull=lit('#3a474b',{rough:.81,metal:.40,emissive:'#141d23',ei:.71});
  const lighter=lit('#627377',{rough:.7,metal:.48,emissive:'#263c40',ei:.48});
  const dark=lit('#151d23',{rough:.86,metal:.22,emissive:'#0b151d',ei:.71});
  const stone=lit('#5b5d56',{rough:.96,emissive:'#191b1b',ei:.58});
  const glass=new THREE.MeshStandardMaterial({color:'#506a70',roughness:.45,metalness:.32,
    transparent:true,opacity:.23,side:THREE.DoubleSide,depthWrite:false,emissive:'#4c7773',emissiveIntensity:.24});
  const wingGlass=new THREE.MeshStandardMaterial({color:'#81b2a1',roughness:.27,metalness:.40,
    transparent:true,opacity:.59,side:THREE.DoubleSide,depthWrite:false,emissive:'#476f62',emissiveIntensity:.41});
  const litEdge=lit('#88b8ad',{rough:.57,metal:.40,emissive:'#89c5b3',ei:.70});
  const innerLight=lit('#9ea698',{rough:.72,emissive:'#8eaa95',ei:.53});
  const copper=lit('#8b8466',{rough:.56,metal:.60,emissive:'#594831',ei:.41});
  const jade=lit('#527b6b',{rough:.6,metal:.36,emissive:'#4f9075',ei:.61});
  const pavement=lit('#333a3e',{rough:.98,emissive:'#151f26',ei:.61});
  const stepLight=lit('#b29268',{rough:.8,emissive:'#ae8960',ei:.91});
  const trees=lit('#232f30',{rough:1,emissive:'#172122',ei:.44,side:THREE.DoubleSide});
  const treeBark=lit('#3b3b34',{rough:.99,emissive:'#141b17',ei:.31});
  const glows=[], amber=[], floors=[], supports=[], structure=[], dimGlass=[], wings=[], casing=[], internal=[];
  const stack=new THREE.Group();stack.name='baoen-modern-nine-floors';root.add(stack);
  // Repeated steel intermediate slabs and selected glazed edge boxes. Core and
  // face center deliberately remain dark, unlike a solid fluorescent tube.
  for(let k=0;k<9;k++){
    const level=new THREE.Group();level.name='modern-floor-'+(k+1);stack.add(level);
    const base=11.6+k*7.20,top=base+7.20,R=15.0-k*.61,RT=R-.31;
    floors.push(cyl(R*.93,R*.92,.63,base+.28),cyl(R*.66,R*.65,.29,top-.65));
    internal.push(cyl(4.33,4.31,7.18,base+3.60));
    const ownGlass=[],ownWing=[];
    for(let j=0;j<N;j++){
      const a=rot+j*dA,b=a+dA;
      const A=rim(R,a,base+.54), B=rim(R,b,base+.54), At=rim(RT,a,top-.75), Bt=rim(RT,b,top-.75);
      const radial=V(Math.sin((a+b)/2),0,Math.cos((a+b)/2));
      structure.push(link(A,At,.27,.34),link(A,B,.25,.25),link(At,Bt,.21,.24));
      structure.push(link(lerp(A,B,.48),lerp(At,Bt,.48),.12,.21));
      for(const y of [.34,.66])structure.push(link(lerp(A,At,y),lerp(B,Bt,y),.12,.13));
      ownGlass.push(quad(lerp(A,B,.21),lerp(A,B,.79),lerp(At,Bt,.79),lerp(At,Bt,.21)));
      for(const side of [0,1]){
        const p=side===0?.035:.79, q=side===0?.21:.965;
        const f=1.72+Math.sin((k+2)*.91)*.30;
        const e0=lerp(A,B,p).addScaledVector(radial,f), e1=lerp(A,B,q).addScaledVector(radial,f);
        const u0=lerp(At,Bt,p).addScaledVector(radial,1.12), u1=lerp(At,Bt,q).addScaledVector(radial,1.12);
        ownWing.push(quad(e0,e1,u1,u0),quad(lerp(A,B,p),e0,u0,lerp(At,Bt,p)));
        casing.push(link(e0,e1,.24,.25),link(u0,u1,.17,.23),link(e0,u0,.19,.22),link(e1,u1,.17,.18));
        // Thin discontinuous hints of reflected light, not whole-face fill.
        const t=((k*11+j*3+side*7)%10);
        if(t<8){
          glows.push(link(lerp(e0,u0,.15),lerp(e0,u0,.67),t<3?.25:.133,.099));
          glows.push(link(lerp(e0,e1,.2),lerp(e0,e1,.84),.089,.079));
        }
      }
      if((k+j)%4===1){
        const aa=lerp(A,B,.34).addScaledVector(radial,-.7), bb=lerp(A,B,.59).addScaledVector(radial,-.7);
        wings.push(link(aa,bb,.15,.12));
      }
    }
    // Separate optical panes render behind and in front, with real structure between.
    combine(level,ownGlass,glass,'central-curtain-wall');
    combine(level,ownWing,wingGlass,'projecting-corner-glass');
  }
  combine(stack,floors,dark,'horizontal-nine-slab-edges');
  combine(stack,internal,dull,'dark-steel-core');
  combine(stack,structure,dull,'columns-and-mullions');
  combine(stack,casing,lighter,'corner-box-steel');
  combine(stack,glows,litEdge,'broken-neutral-edge-light');
  combine(stack,wings,innerLight,'selective-low-interior-light');

  const peak=new THREE.Group();peak.name='modern-cone-and-metal-finial';root.add(peak);
  const cap=[cyl(9.5,7.53,1.53,77.11),cyl(9.7,9.26,.24,76.46)];
  for(let k=0;k<5;k++){
    const y=77.82+k*1.63, a=7.57-k*1.24;
    cap.push(cyl(a,Math.max(1.20,a-1.36),1.65,y+.77),cyl(a*.99,a*.94,.12,y+.18));
  }
  combine(peak,cap,jade,'dark-copper-green-pyramidal-roof');
  const metal=[cyl(.42,.28,7.2,89.35,12)];
  for(let i=0;i<8;i++)metal.push(cyl(.93-i*.045,.81-i*.041,.21,86.25+i*.60,16));
  metal.push(new THREE.SphereGeometry(.62,14,9).translate(0,91.43,0));
  metal.push(new THREE.ConeGeometry(.086,1.11,8).translate(0,92.602,0));
  combine(peak,metal,copper,'finial-rings-and-needle');

  // Four pairs of visibly sloping spans support the canopy outside the
  // represented protected perimeter; no load meets the historic core.
  const canopy=[cyl(26.7,13.8,6.7,6.44),cyl(13.8,13.9,.41,9.98)];
  combine(root,canopy,dark,'sloping-heritage-canopy');
  for(const a of [0,Math.PI*.5,Math.PI,Math.PI*1.5]){
    for(const o of [-.102,.102]){
      const z=a+o;
      supports.push(link(rim(28.7,z,1.02),rim(15.2,z,10.98),.86,1.06));
      amber.push(link(rim(29.1,z+.029,1.5),rim(15.31,z+.029,11.33),.107,.14));
    }
  }
  combine(root,supports,lighter,'four-exterior-diagonal-support-groups');
  for(let i=0;i<13;i++){
    const w=14.4-i*.29,z=31.8-i*.75,y=.54+i*.26;
    floors.push(box(w,.33,.83,0,y,z));
    amber.push(box(w-.45,.047,.08,0,y+.187,z+.31));
  }
  combine(root,floors.slice(-13),stone,'near-side-warm-steps');
  combine(root,amber,stepLight,'restrained-steps-and-support-lights');

  const site=[];
  site.push(box(430,.32,455,0,-.19,0));
  for(let x=-4;x<=4;x++)for(let z=-9;z<=9;z++)
    site.push(box(8.03,.05,7.95,x*8.1,.014,z*8.03));
  combine(root,site,pavement,'modern-site-plaza');
  // A low foreground terrace and broken landscape line, neither a survey nor
  // an imitation of event spotlights visible in the historical photograph.
  const verge=lit('#26302c',{rough:.95,emissive:'#172423',ei:.52});
  const berms=[],paths=[],lowLights=[];
  const walkAngle=-.76;
  for(let i=0;i<11;i++){
    const x=-124+(i-5)*4.3,z=-124-(i-5)*4.6;
    berms.push(box(5.8,.48+(i%3)*.17,11,x,.06,z,walkAngle));
    paths.push(box(6.4,.11,1.95,x-7.1,.17,z-6.1,walkAngle));
    if(i%3===1)lowLights.push(box(.17,.13,.25,x-5.8,.41,z-5.1,walkAngle));
  }
  for(let i=0;i<7;i++){
    const x=-119+i*5.5,z=-87-i*1.64;
    berms.push(box(6.2,.26+(i%3)*.17,4.8,x,.12,z,-.12));
  }
  combine(root,berms,verge,'foreground-lawn-and-low-bank-skirts');
  combine(root,paths,dull,'approach-walk-strip');
  combine(root,lowLights,stepLight,'trim-low-approach-guidance');
  const walls=[],win=[];
  for(const [x,z,w,d,h] of [[-38,-11,27,13,7.4],[38,-18,31,18,8.3],[-48,-34,35,14,6.7],[5,-40,51,18,7.1],[-43,26,24,11,5.0],[53,10,21,19,6.4]]){
    walls.push(box(w,h,d,x,h*.5,z),box(w+.66,.44,d+.44,x,h+.16,z));
    for(let i=1;i<w/2.5;i++){
      const p=x-w/2+i*2.5;
      if((Math.floor(i)+x)%3)win.push(box(.58,1.27,.055,p,h*.58,z+d/2+.035));
    }
  }
  combine(root,walls,stone,'low-museum-wing-context');
  combine(root,win,lit('#6f6960',{rough:.93,emissive:'#675746',ei:.42}),'local-museum-window-spill');
  const bark=[],leaves=[];
  for(const [xx,zz,h] of [[-47,-30,7.2],[-30,-25,6.6],[-28,-13,8.8],[-42,-5,7.5],[-31,18,7.8],[20,-30,8.6],[44,-25,7.4],[28,37,6.8],[-23,41,6.5],[36,26,6.4],[-75,-21,7.6],[-57,2,8.1],[-130,-133,7.8],[-117,-148,9.1],[-143,-117,8.4],[-106,-82,7.2],[-91,-103,8.6],[-64,-77,6.3],[-37,-65,7.4],[-1,-82,7.5],[37,-52,6.6],[-27,70,8.4]]){
    bark.push(link(V(xx,0,zz),V(xx+.7,h*.78,zz-.3),.47,.42));
    for(let j=0;j<32;j++){
      const a=j*2.39996, r=.75+(j%7)*.45;
      const f=new THREE.IcosahedronGeometry(.74+(j%5)*.15,1).scale(1.29,.72,1.17);
      f.translate(xx+Math.cos(a)*r,h*.61+(j%6)*.33,zz+Math.sin(a)*r);leaves.push(f);
    }
  }
  combine(root,bark,treeBark,'tree-trunks');
  combine(root,leaves,trees,'quiet-tree-line');
  const ambient=new THREE.HemisphereLight('#72888f','#242a28',.89);root.add(ambient);
  const key=new THREE.DirectionalLight('#c6d1c4',1.04);key.position.set(-61,105,29);root.add(key);
  const warm=new THREE.PointLight('#f2b783',45,27,2);warm.position.set(4,6,30);root.add(warm);
  let brightness=1,level=0,target=0;
  const apply=()=>{
    litEdge.emissiveIntensity=brightness*(.78+.94*level);
    innerLight.emissiveIntensity=brightness*(.38+.65*level);
    wingGlass.emissiveIntensity=brightness*(.31+.38*level);
    glass.emissiveIntensity=.13+brightness*.06;
    stepLight.emissiveIntensity=.64+.22*brightness;
  };
  apply();
  return {
    group:root,stack,litEdge,
    release(on,snap=false){target=on?1:0;if(snap){level=target;apply()}},
    setLampBright(v){brightness=v;apply()},
    update(dt){if(Math.abs(level-target)>.0001){level+=Math.sign(target-level)*Math.min(Math.abs(target-level),dt*.66);apply()}},
  };
}
