/** 海春轩塔：七层八角密檐砖塔、西向券门与 48 龛。剖视为示意，非实测。 */
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { lit } from '../../src/kit.js';
import { TOWER, GROUND_Y } from './data.js';
import * as T from './textures.js';

const SIDES = TOWER.sides;
const STEP = (Math.PI * 2) / SIDES;
const INR = Math.cos(Math.PI / SIDES);   // 外接圆半径 → 面心距（边心距）

const faceAz = (k) => (k + 0.5) * STEP;
const DOOR_FACE = 5; // After the group rotation this is the west-facing panel.

/** 圭首形：下矩上收尖 */
function guiShape(w, h, tip = 0.3) {
  const s = new THREE.Shape();
  s.moveTo(-w / 2, 0);
  s.lineTo(w / 2, 0);
  s.lineTo(w / 2, h * (1 - tip));
  s.lineTo(0, h);
  s.lineTo(-w / 2, h * (1 - tip));
  s.closePath();
  return s;
}

/** 龛口边框：圭首里挖一个圭首洞，光从洞里出来 */
function guiFrame(w, h, border) {
  const outer = guiShape(w, h);
  const inner = guiShape(w - border * 2, h - border * 1.6, 0.3);
  outer.holes.push(new THREE.Path(inner.getPoints(12).reverse()));
  const geo = new THREE.ShapeGeometry(outer);
  geo.translate(0, -h / 2, 0);
  return geo;
}

function guiPlate(w, h) {
  const geo = new THREE.ShapeGeometry(guiShape(w, h));
  geo.translate(0, -h / 2, 0);
  return geo;
}

/** 券拱：矩形 + 半圆顶 */
function archPlate(w, h) {
  const s = new THREE.Shape();
  const r = w / 2;
  s.moveTo(-r, 0);
  s.lineTo(-r, h - r);
  s.absarc(0, h - r, r, Math.PI, 0, true);
  s.lineTo(r, 0);
  s.closePath();
  return new THREE.ShapeGeometry(s);
}

/** 券门口的砖券圈：中间空出来才看得见筒内的门灯 */
function archRing(w, h, border) {
  const outer = new THREE.Shape();
  const R = w / 2;
  outer.moveTo(-R, 0);
  outer.lineTo(-R, h - R);
  outer.absarc(0, h - R, R, Math.PI, 0, true);
  outer.lineTo(R, 0);
  outer.closePath();
  const iw = w - border * 2, ih = h - border * 1.5, r = iw / 2;
  const inner = new THREE.Shape();
  inner.moveTo(-r, border * 0.6);
  inner.lineTo(-r, ih - r);
  inner.absarc(0, ih - r, r, Math.PI, 0, true);
  inner.lineTo(r, border * 0.6);
  inner.closePath();
  outer.holes.push(new THREE.Path(inner.getPoints(14).reverse()));
  return new THREE.ShapeGeometry(outer);
}

function octPrism(rBottom, rTop, h, mat, openEnded = false) {
  const g = new THREE.CylinderGeometry(rTop, rBottom, h, SIDES, 1, openEnded);
  g.translate(0, h / 2, 0);
  return new THREE.Mesh(g, mat);
}

/** 叠涩檐：砖自下而上逐层内退，退不下去的那一截就是挑出的檐口 */
function corbelEave(r, proj, thick, courses) {
  const parts = [];
  const ch = thick / courses;
  for (let j = 0; j < courses; j++) {
    const pLo = proj * (1 - j / courses);
    const pHi = proj * (1 - (j + 1) / courses);
    const g = new THREE.CylinderGeometry(r + pHi, r + pLo, ch, SIDES, 1, false);
    g.translate(0, j * ch + ch / 2, 0);
    parts.push(g);
  }
  return mergeGeometries(parts);
}

function arcOutline(w,h,low=0) {
  const r=w/2, cy=low+h-r;
  const out=[[-r,low],[r,low],[r,cy]];
  for(let j=1;j<=10;j++) {
    const t=Math.PI*j/10;
    out.push([Math.cos(t)*r,cy+Math.sin(t)*r]);
  }
  return out;
}
function surfaceFace(h,R,rt,k,hole) {
  const half=R*Math.sin(Math.PI/8), face=faceAz(k);
  const rect=new THREE.Shape();
  if(hole?.door) {
    const arch=arcOutline(hole.w,hole.h);
    rect.moveTo(-half,0);
    for(const [a,b] of [arch[0],...arch.slice(2).reverse(),arch[1]])rect.lineTo(a,b);
    rect.lineTo(half,0);
  } else {
    rect.moveTo(-half,0);rect.lineTo(half,0);
    if(hole) rect.holes.push(new THREE.Path(arcOutline(hole.w,hole.h,hole.low).map(([a,b])=>new THREE.Vector2(a,b))));
  }
  rect.lineTo(half,h);rect.lineTo(-half,h);rect.closePath();
  const g=new THREE.ShapeGeometry(rect,12);
  const p=g.attributes.position,u=g.attributes.uv;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i), y=p.getY(i),r=THREE.MathUtils.lerp(R,rt,y/h);
    p.setXYZ(i,x*r/R,y,r*INR);
    u.setXY(i,x/2.85+ k*.217,y/1.50);
  }
  g.rotateY(face);g.computeVertexNormals();
  return g;
}
function returnWalls(hole,az,r,depth) {
  const outline=arcOutline(hole.w,hole.h,hole.low||0);
  const pos=[],uv=[];
  for(let i=0;i<outline.length;i++){
    if(i===0&&hole.door)continue;
    const [x,y]=outline[i], [nx,ny]=outline[(i+1)%outline.length];
    pos.push(x,y,r,nx,ny,r,nx,ny,r-depth,x,y,r,nx,ny,r-depth,x,y,r-depth);
    for(let j=0;j<6;j++)uv.push((j%2)*.16,(y+(j>2?.2:0))/.45);
  }
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  g.computeVertexNormals();g.rotateY(az);
  return g;
}
function masonryEave(radius,proj,thick,i) {
  const out=[];
  const levels=[0,.1,.24,.46,.67,.83,1], grows=[0,.17,.38,.64,.83,.97,1];
  for(let j=0;j<6;j++){
    const a=radius+proj*grows[j], b=radius+proj*grows[j+1];
    const g=new THREE.CylinderGeometry(b,a,thick*(levels[j+1]-levels[j]),SIDES,1,true);
    g.translate(0,thick*(levels[j+1]+levels[j])/2,0);out.push(g);
  }
  const rim=new THREE.CylinderGeometry(radius+proj,radius+proj,thick*.19,SIDES,1,true);
  rim.translate(0,thick*.97,0);out.push(rim);
  return mergeGeometries(out);
}
export function buildTower(scene) {
  const group = new THREE.Group();
  group.name = 'tower';
  group.position.set(0, GROUND_Y, 0);
  group.rotation.y = TOWER.rot;
  scene.add(group);

  const brickMap = T.bricks('#777873','#5e5f5e',16,10,.16).clone();
  brickMap.repeat.set(1,1);brickMap.needsUpdate=true;
  const tangMap = T.tangBricks();
  const outerMats = [];
  const brickMat=lit('#b8b9b1',{map:brickMap,rough:.91,emissive:'#22231f',ei:.22,side:THREE.DoubleSide});
  brickMat.bumpMap=brickMap;brickMat.bumpScale=.044;
  const eaveMat=lit('#9b9a92',{map:T.bricks('#868583','#616360',12,8,.22),rough:.94,emissive:'#211e1a',ei:.21,side:THREE.DoubleSide});
  const tileMat=lit('#747973',{map:T.tileBand('#535859','#59605e'),rough:.8,side:THREE.DoubleSide,emissive:'#141a20',ei:.18});
  const dark=lit('#373b38',{map:brickMap,rough:.97,side:THREE.DoubleSide});
  outerMats.push(brickMat,eaveMat,tileMat,dark);
  const eaves=new THREE.Group();eaves.name='seven-corbel-courses';group.add(eaves);
  let y=0;
  const tierY=[],slots=[];
  for(let i=0;i<TOWER.tiers;i++){
    const [h,R]=TOWER.body[i], rt=R-.036-i*.004;
    const shell=[], jambs=[], backs=[];
    const nh=i===0?2.14:Math.min(.90,h*.59);
    tierY.push(y);
    for(let k=0;k<SIDES;k++){
      const az=faceAz(k);
      const hole=i>0?{w:.50+i*.008,h:nh,low:h*.47-nh/2}:k===DOOR_FACE?{door:true,w:1.35,h:2.14,low:0}:null;
      shell.push(surfaceFace(h,R,rt,k,hole));
      if(hole){
        const r=THREE.MathUtils.lerp(R,rt,(hole.low+hole.h*.5)/h)*INR;
        const depth=i>0?.23:.91;
        jambs.push(returnWalls(hole,az,r-.012,depth));
        const b=archPlate(hole.w+.025,hole.h+.025);
        b.translate(0,hole.low,r-depth-.008);b.rotateY(az);backs.push(b);
        if(i>0) slots.push({tier:i,az,order:(k-DOOR_FACE+SIDES)%SIDES,
          y:y+hole.low+hole.h/2,inr:r,w:hole.w,h:hole.h});
      }
    }
    for(const [geo,mat] of [[shell,brickMat],[jambs,eaveMat],[backs,dark]]){
      const body=new THREE.Mesh(mergeGeometries(geo),mat);
      body.position.y=y;body.castShadow=true;body.receiveShadow=true;
      if(mat===brickMat)body.name='octagonal-brick-tier-'+(i+1);
      group.add(body);
    }
    y+=h;
    const proj=.56-i*.035;
    const eave=new THREE.Mesh(masonryEave(rt,proj,TOWER.eaveThk,i),eaveMat);
    eave.position.y=y;eave.castShadow=true;eave.receiveShadow=true;eave.name='corbel-'+(i+1);eaves.add(eave);
    const topR=i===6?.65:TOWER.body[i+1][1] - .035;
    const roofH=i===6?.75:.16;
    const cap=new THREE.Mesh(new THREE.CylinderGeometry(topR,rt+proj,roofH,SIDES,1,true),tileMat);
    cap.position.y=y+TOWER.eaveThk+roofH/2-.025;cap.castShadow=true;group.add(cap);
    y+=TOWER.eaveThk;
  }
  slots.sort((a,b)=>a.tier-b.tier||a.order-b.order);
  const bodyTop=y;

  const frameMat = lit('#b0b6c4', { map: brickMap.clone(), rough: 0.9, emissive: '#0d1017', ei: 0.3 });
  frameMat.map.needsUpdate = true;
  frameMat.map.repeat.set(1, 1);
  // 龛口框不进渐隐名单：外皮化成玻璃壳时，檐与龛的轮廓要留下来

  const dummy = new THREE.Object3D();
  const frames = new THREE.InstancedMesh(archRing(1,1,.065).translate(0,-.5,0), frameMat, slots.length);
  frames.name = 'nicheFrame';
  const nicheGlowMat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: true, fog: true });
  const glows = new THREE.InstancedMesh(archPlate(.87,.91).translate(0,-.47,0),nicheGlowMat,slots.length);
  glows.name = 'nicheGlow';
  glows.frustumCulled = false;

  const warm = new THREE.Color('#df9b57');
  const cTmp = new THREE.Color();
  slots.forEach((s, idx) => {
    dummy.rotation.set(0, s.az, 0);
    dummy.scale.set(s.w, s.h, 1);
    dummy.position.set(Math.sin(s.az) * (s.inr + 0.031), s.y, Math.cos(s.az) * (s.inr + 0.031));
    dummy.updateMatrix();
    frames.setMatrixAt(idx, dummy.matrix);
    dummy.position.set(Math.sin(s.az) * (s.inr - 0.205), s.y, Math.cos(s.az) * (s.inr - 0.205));
    dummy.updateMatrix();
    glows.setMatrixAt(idx, dummy.matrix);
    glows.setColorAt(idx, cTmp.setRGB(0, 0, 0));
  });
  frames.instanceMatrix.needsUpdate = true;
  glows.instanceMatrix.needsUpdate = true;
  group.add(frames, glows);

  let nicheK = 0;
  let nicheTarget = 0;
  let nicheBright = 1;
  let mirrorGlows = null;
  function paintNiches() {
    for (let i = 0; i < slots.length; i++) {
      const t = THREE.MathUtils.clamp(nicheK - i, 0, 1);
      cTmp.copy(warm).multiplyScalar(t * t * (3 - 2 * t));
      glows.setColorAt(i, cTmp);
    }
    glows.instanceColor.needsUpdate = true;
    // 镜像里的 instanceColor 不跟着源走，每次落色抄一份过去，水里的龛灯才跟着次第亮
    if (mirrorGlows && mirrorGlows.instanceColor) {
      mirrorGlows.instanceColor.array.set(glows.instanceColor.array);
      mirrorGlows.instanceColor.needsUpdate = true;
    }
  }
  paintNiches();

  /* ------------------------------------------------------------ 西北券门与空筒 */
  const [h1, R1] = TOWER.body[0];
  const doorAz = faceAz(DOOR_FACE);
  const doorIn = R1 * INR;
  const doorW = 1.35, doorH = 2.14;
  const sx = Math.sin(doorAz), sz = Math.cos(doorAz);
  const tubeR = R1 - TOWER.wall + 0.06;

  const tubeMat = lit('#3a3227', { map: tangMap, rough: 0.96, side: THREE.DoubleSide, emissive: '#040403', ei: 0.15 });
  outerMats.push(tubeMat);
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(tubeR, tubeR, h1 - 0.1, SIDES, 1, true), tubeMat);
  tube.position.y = (h1 - 0.1) / 2;
  group.add(tube);

  // 门洞三层：砖券圈（外）→ 暖亮的内塔门（中）→ 发黑的筒底（后）
  const mouth = new THREE.Mesh(archPlate(doorW, doorH), new THREE.MeshBasicMaterial({ color: 0x0a0810, fog: false }));
  mouth.position.set(sx * (doorIn - .91), 0.06, sz * (doorIn - .91));
  mouth.rotation.y = doorAz;
  group.add(mouth);

  const innerDoorMat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, fog: false });
  const innerDoor = new THREE.Mesh(archPlate(doorW * 0.62, doorH * 0.62), innerDoorMat);
  innerDoor.position.set(sx * (doorIn - .79), 0.24, sz * (doorIn - .79));
  innerDoor.rotation.y = doorAz;
  group.add(innerDoor);

  const frameM = lit('#a89e90', { map: brickMap.clone(), rough: 0.92, emissive: '#141110', ei: 0.4 });
  frameM.map.needsUpdate = true;
  outerMats.push(frameM);
  const doorFrame = new THREE.Mesh(archRing(doorW + 0.44, doorH + 0.34, 0.18), frameM);
  doorFrame.position.set(sx * (doorIn + 0.05), -0.04, sz * (doorIn + 0.05));
  doorFrame.rotation.y = doorAz;
  group.add(doorFrame);

  /* ------------------------------------------------------------ 内唐塔 */
  const inner = new THREE.Group();
  inner.visible=false;
  inner.name = 'innerTower';
  group.add(inner);
  const tangMat = lit('#a89478', { map: tangMap, rough: 0.96, emissive: '#3a3020', ei: 0.5 });
  const innerBase = tubeR - 0.2;
  const innerH = bodyTop - TOWER.eaveThk - 1.6;
  const innerTiers = 5;
  let iy = 0;
  for (let i = 0; i < innerTiers; i++) {
    const f0 = i / innerTiers, f1 = (i + 1) / innerTiers;
    const h = innerH * (f1 - f0);
    const rB = innerBase * (1 - f0 * 0.4);
    const rT = innerBase * (1 - f1 * 0.4);
    const m = octPrism(rB, rT, h, tangMat);
    m.position.y = iy;
    inner.add(m);
    iy += h;
    const e = new THREE.Mesh(corbelEave(rT, 0.28, 0.2, 2), tangMat);
    e.position.y = iy - 0.02;
    inner.add(e);
    iy += 0.15;
  }
  const innerGlowMat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, fog: false });
  for (let i = 0; i < 4; i++) {
    const r = innerBase * (1 - (i / 4) * 0.4) * INR;
    for (let k = 0; k < SIDES; k += 2) {
      const a = faceAz(k);
      const p = new THREE.Mesh(guiPlate(0.4, 0.62), innerGlowMat);
      p.position.set(Math.sin(a) * (r + 0.01), 0.85 + (i * innerH) / 4, Math.cos(a) * (r + 0.01));
      p.rotation.y = a;
      inner.add(p);
    }
  }

  /* ------------------------------------------------------------ 塔刹 */
  const spire = new THREE.Group();
  spire.position.y = bodyTop+.72;
  const scale=(TOWER.height-spire.position.y)/2.27;
  spire.scale.set(.80,scale,.80);
  group.add(spire);
  const iron=lit('#6c726b',{rough:.64,metal:.42,emissive:'#313633',ei:.23});
  const copper=lit('#8b7862',{rough:.57,metal:.47,emissive:'#332c21',ei:.31});

  const basin = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.5, 0.22, SIDES), iron);
  basin.position.y = 0.11;
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.5, 8, 4, 0, Math.PI * 2, 0, Math.PI / 2), iron);
  dome.position.y = 0.2;
  dome.scale.y = 0.42;
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.09, 1.24, 8), copper);
  shaft.position.y = 0.95;
  spire.add(basin, dome, shaft);
  for (let i = 0; i < 5; i++) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.42 - i * 0.062, 0.048, 6, 14), iron);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.44 + i * 0.17;
    spire.add(ring);
  }
  const canopy = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.3, SIDES, 1, true), iron);
  canopy.position.y = 1.5;
  const gourd = new THREE.Group();
  gourd.position.y = 1.86;
  const bulbLo = new THREE.Mesh(new THREE.SphereGeometry(0.21, 10, 8), copper);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.1, 8), copper);
  neck.position.y = 0.13;
  const bulbHi = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), copper);
  bulbHi.position.y = 0.26;
  gourd.add(bulbLo, neck, bulbHi);
  spire.add(canopy, gourd);

  // 门口这盏只照券周砖，别把筒壁照亮点，否则门洞看不出是开口
  const doorLight = new THREE.PointLight(0xffb469, 18, 12, 2);
  doorLight.position.set(sx * (doorIn + 2.2), 2.4, sz * (doorIn + 2.2));
  group.add(doorLight);
  // 门前一盏自下而上的暖光：夜景灯色的写意，替月亮补出塔身的体积
  const upLight = new THREE.PointLight(0xf3b472, 46, 26, 2);
  upLight.position.set(sx * 5.4, 0.9, sz * 5.4);
  group.add(upLight);
  for(const [x,z,k] of [[6.7,6.8,105],[-6.2,-5.8,76],[-4.4,7.8,62]]){
    const w=new THREE.SpotLight('#f8bd82',k,29,.45,.72,2);
    w.position.set(x,.22,z); w.target.position.set(0,10.6,0);group.add(w,w.target);
    const f=new THREE.Mesh(new THREE.CircleGeometry(.07,8),new THREE.MeshBasicMaterial({color:'#987754'}));
    f.rotation.x=-Math.PI/2;f.position.set(x,.029,z);group.add(f);
  }

  /* ------------------------------------------------------------ 剖视与龛火 */

  let reveal = 0;
  let revealTarget = 0;
  let lastReveal = -1;

  const rot = new THREE.Vector3(0, 1, 0);
  const api = {
    group, inner, spire, slots: slots.length,
    anchors: {
      door: new THREE.Vector3(sx * doorIn, 1.5, sz * doorIn).applyAxisAngle(rot, TOWER.rot).setY(GROUND_Y + 1.5),
      spireTop: new THREE.Vector3(0, GROUND_Y + TOWER.height, 0),
      body: new THREE.Vector3(0, GROUND_Y + tierY[3] + 1, 0),
    },
    release(on, snap = false) {
      nicheTarget = on ? slots.length : 0;
      if (snap) { nicheK = nicheTarget; paintNiches(); }
    },
    setNicheBright(v) { nicheBright = v; },
    reveal(on, snap = false) { revealTarget = on ? 1 : 0; if (snap) reveal = revealTarget; },
    /** 水面镜像里的 instanceColor 不会自动跟着源走，抄一份过去 */
    bindMirror(root) {
      root.traverse((o) => { if (o.isInstancedMesh && o.name === 'nicheGlow') mirrorGlows = o; });
      paintNiches();
    },
    update(t, dt) {
      if (nicheK !== nicheTarget) {
        const up = nicheTarget > nicheK;
        nicheK = THREE.MathUtils.clamp(nicheK + (up ? 1 : -1) * dt * (up ? 6.4 : 16), 0, slots.length);
        if (Math.abs(nicheK - nicheTarget) < 0.01) nicheK = nicheTarget;
        paintNiches();
      }
      nicheGlowMat.color.setScalar((0.86 + 0.09 * Math.sin(t * 2.3) + 0.05 * Math.sin(t * 5.7 + 1.3)) * nicheBright);
      innerDoorMat.color.setRGB(.56,.36,.16).multiplyScalar((.44 + .50 * reveal) * (0.92 + 0.08 * Math.sin(t * 1.7)) * nicheBright);


      reveal += (revealTarget - reveal) * Math.min(1, dt * 2.2);
      if (Math.abs(reveal - revealTarget) < 0.004) reveal = revealTarget;
      inner.visible=reveal>.015;
      if (Math.abs(reveal - lastReveal) > 0.002) {
        const op = 1 - 0.62 * reveal;
        for (const m of outerMats) {
          const transparent=op<.998;
          if(m.transparent!==transparent){m.transparent=transparent;m.needsUpdate=true;}
          m.opacity = op;
          m.depthWrite = op > .75;
        }
        innerGlowMat.color.setRGB(1.0, 0.74, 0.44).multiplyScalar(0.14 + 1.15 * reveal);
        tangMat.emissiveIntensity = 0.5 + 2.6 * reveal;
        lastReveal = reveal;
      }
      return { reveal, niche: nicheK / slots.length };
    },
  };
  return api;
}
