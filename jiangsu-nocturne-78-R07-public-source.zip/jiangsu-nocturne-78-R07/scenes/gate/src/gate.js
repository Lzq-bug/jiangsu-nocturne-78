import * as THREE from 'three';
import { M, glow, box, mesh } from './kit.js';
import { GATE, LAKE } from './data.js';
import { sculptGateSkin, buildJinjiLandscape } from './jinji-architectural-skin.js';

const H = GATE.height;
const DEPTH = GATE.depth;
const FRONT = DEPTH / 2;

/** where the built parts are, for the water columns and the light show */
export const ANCHORS = { crown: [], archEdge: [], podium: [], soffit: [] };

/* ------------------------------------------------------------------ profile */

/** outer elevation barely moves — 150 m at the feet, 142 m under the crown */
const outerHalf = (y) => GATE.outerHalf - 5.4 * (y / H) ** 2 - 3.1 * Math.pow(Math.max(0,(y/H-.87)/.13),3);

const ARCH_A = GATE.archHalf;  // half gap at ground level
const APEX = GATE.archApex;    // crown of the arch, underside of the bridge
const APEX1 = APEX * 0.946;    // where the straight run hands over to the cap

function archHalf(y) {
  if (y <= 0) return ARCH_A;
  if (y <= APEX1) {
    const u = Math.min(1, y / APEX);
    return ARCH_A * Math.pow(Math.max(0, 1 - Math.pow(u, 1.98)), 0.64);
  }
  const cap = archHalf(APEX1);
  const t = Math.min(1, (y - APEX1) / (APEX - APEX1));
  return cap * Math.sqrt(Math.max(0, 1 - t * t));
}

/** the 门 as one closed, concave outline — no holes needed */
function outline() {
  const pts = [];
  const push = (x, y) => {
    const l = pts[pts.length - 1];
    if (l && Math.abs(l[0] - x) < 1e-4 && Math.abs(l[1] - y) < 1e-4) return;
    pts.push([x, y]);
  };
  const nOut = 24, nIn = 26;
  for (let i = 0; i <= nOut; i++) push(-outerHalf((H * i) / nOut), (H * i) / nOut);
  for (let i = nOut; i >= 0; i--) push(outerHalf((H * i) / nOut), (H * i) / nOut);
  push(archHalf(0), 0);
  for (let i = 1; i <= nIn; i++) {
    const y = (APEX * i) / nIn;
    push(archHalf(y), y);
  }
  for (let i = nIn; i >= 1; i--) {
    const y = (APEX * i) / nIn;
    push(-archHalf(y), y);
  }
  push(-archHalf(0), 0);
  return pts;
}

function gateGeometry() {
  const pts = outline();
  const shape = new THREE.Shape(pts.map(([x, y]) => new THREE.Vector2(x, y)));
  const g = new THREE.ExtrudeGeometry(shape, { depth: DEPTH, bevelEnabled: false, curveSegments: 1, steps: 1 });
  g.translate(0, 0, -FRONT);
  g.computeVertexNormals();
  return { shape, geometry: g, points: pts };
}

/* ------------------------------------------------------------------ lights on the edges */

/** a glowing tube following a 2-D point list, placed on a face of the tower */
function edgeTube(points, { z, radius, color, intensity = 1.7, seg = 3 }) {
  const pts = points.map(([x, y]) => new THREE.Vector3(x, y, z));
  const curve = new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.02);
  const g = new THREE.TubeGeometry(curve, Math.max(24, pts.length * 3), radius, seg, false);
  return new THREE.Mesh(g, glow(color, intensity));
}

/** the inner arch curve only — the signature outline of the gate */
function archCurvePoints() {
  const pts = [];
  for (let i = 0; i <= 30; i++) {
    const y = (APEX * i) / 30;
    pts.push([archHalf(y), y]);
  }
  for (let i = 30; i >= 0; i--) {
    const y = (APEX * i) / 30;
    pts.push([-archHalf(y), y]);
  }
  return pts;
}

/* ------------------------------------------------------------------ pieces */

function towers(geo) {
  const m = new THREE.Mesh(geo, [M.glass, M.glassSide, M.steel]);
  m.name = 'gate-body';
  m.receiveShadow = true;
  ANCHORS.crown.push(new THREE.Vector3(0, H + 1, 0));
  return m;
}

/** vertical light lines on the four outer arrises + the crown cornice */
function edgeLights(g) {
  const dim=[],warm=[];
  for(const side of [-1,1]){
    const pts=[];
    for(let i=0;i<30;i++){
      const y=7+i*9.47;
      pts.push([side*(outerHalf(y)-3.1),y]);
    }
    const line=edgeTube(pts,{z:FRONT-.22,radius:.095,color:'#bed5df',intensity:.92});
    line.name='gate-curtain-seam';g.add(line);
    for(let k=0;k<14;k++){
      const y=15+k*19.25;
      const x=side*(archHalf(Math.min(y,APEX)) + 2.3 + 1.1*Math.sin(k*1.83));
      if(k>11)continue;
      warm.push(box(1.02,3.6,.48,x,y,FRONT-.25));
    }
  }
  for(let i=0;i<48;i++){
    if(i%7===2 || i%7===5)continue;
    dim.push(box(2.7,.24,.53,-68+i*2.865,H-16,FRONT+.03));
  }
  g.add(mesh(dim,glow('#d4caf0',.44)),mesh(warm,glow('#e7d4aa',.39)));
  for(const side of [-1,1]){
    const edge=[];
    for(let i=0;i<26;i++){
      const y=11+i*(APEX-11)/26;
      edge.push([side*(archHalf(y)+.46),y]);
    }
    const seam=edgeTube(edge,{z:FRONT-2.05,radius:.145,color:'#d8dae1',intensity:.83});
    seam.name='gate-recessed-silver-seam';g.add(seam);
  }
}

function archLights(g) {
  ANCHORS.soffit.push(new THREE.Vector3(0, APEX - 6, FRONT - 8), new THREE.Vector3(0, APEX - 6, -FRONT + 8));
  const up=new THREE.DirectionalLight(0x92b3c9,.55);up.position.set(-410,50,541);g.add(up);
}

/** skybridge band + observation deck on the lake face */
function bridge(g) {
  const oh = outerHalf(H);
  // a bright horizontal seam where the arch closes into the bridge
  const seam = mesh([
    box(48, .34, .36, 0, APEX + 1.5, FRONT + 0.3),
    box(48, .34, .36, 0, APEX + 1.5, -FRONT - 0.3),
  ], glow('#d4b796', .21));
  g.add(seam);

  // deck at 246 m: the camera stands here in the 连廊 station
  const deck = mesh([box(52, 1.2, 11, 0, 246, FRONT + 5)], M.deck);
  deck.receiveShadow = true;
  deck.name = 'gate-deck';
  g.add(deck);
  // a dim lit underside, otherwise the platform reads as a black slab from the arch
  g.add(mesh([box(46, 0.3, 8, 0, 245.5, FRONT + 5)], glow('#ffd9a0', 0.3)));
  const rail = [];
  for (let i = 0; i <= 13; i++) rail.push(box(0.18, 1.15, 0.18, -26 + i * 4, 247.2, FRONT + 10.2));
  for (const sx of [-1, 1]) rail.push(box(0.18, 1.15, 10.6, sx * 25.9, 247.2, FRONT + 5));
  g.add(mesh(rail, M.steel));
  // the handrail sits at eye level 8 m from the 连廊 camera: any brighter than a
  // hint and it smears across the whole frame
  g.add(mesh([box(53, 0.12, 0.2, 0, 248.35, FRONT + 10.2)], glow('#9fe6ff', 0.07)));
  ANCHORS.crown.push(new THREE.Vector3(0, 248, FRONT + 5));
}

/** 裙房：the mall wings hugging the two legs, kept clear of the arch opening */
function podium(g) {
  const grp = new THREE.Group();
  grp.name = 'gate-podium';
  const top = 18;
  const parts = [], glass = [];
  for (const sx of [-1, 1]) {
    const x0 = GATE.outerHalf + 4, x1 = 330;
    const w = x1 - x0;
    parts.push(box(w, top, 150, (x0 + x1) / 2 * sx, 0, -30));
    for(let i=1;i<=23;i++)if(i%5!==1 && i%7!==3)
      glass.push(box(3.2+(i%3)*.9,1.5+(i%4)*.56,1.45,(x0+i*w/24)*sx,5.8+(i%3)*1.15,46));
  }
  // rear slab on the city side, so the gate never looks like a freestanding arch
  parts.push(box(700, top - 4, 130, 0, 0, -FRONT - 70));
  const body = mesh(parts, M.concrete);
  body.receiveShadow = true;
  const bands = mesh(glass, glow('#d0ad7b',.46));
  bands.name = 'podium-band';
  grp.add(body, bands);

  // roof edge lighting — the flat top of the podium reads as a bright shelf
  const edge = [];
  for (const sx of [-1, 1]) {
    for(let i=2;i<15;i++)if(i%4!==0)edge.push(box(5.5,.21,.49,sx*(90+i*14.5),top,46));
    edge.push(box(0.9, 0.5, 150, sx * 330, top, -30));
  }
  grp.add(mesh(edge, glow('#8da6c5',.49)));

  // arcade columns under the arch, at the mouth of the passage
  const col = [];
  for (const sx of [-1, 1]) for (let i = -2; i <= 2; i++) col.push(box(2.4, top - 2, 2.4, sx * (ARCH_A - 12) + i * 6, 0, FRONT - 4));
  grp.add(mesh(col, M.stoneDark));
  ANCHORS.podium.push(new THREE.Vector3(-244, top, 46), new THREE.Vector3(244, top, 46));
  g.add(grp);
  return grp;
}

/** rooftop plant + aviation warning lights */
function crown(g) {
  const grp = new THREE.Group();
  const parts = [];
  for (const sx of [-1, 1]) {
    parts.push(box(29, 2, 24, sx * 53, H-7.5, -4));
    parts.push(box(15, 3.8, 17, sx * 53, H - 8, -2));
  }
  grp.add(mesh(parts, M.dark));
  for (const sx of [-1, 1]) {
    const b = new THREE.Mesh(new THREE.SphereGeometry(1.1, 8, 6), glow('#ff5a4a', 2.4));
    b.position.set(sx * 53, H, 0);
    b.name = 'beacon';
    grp.add(b);
  }
  g.add(grp);
  return grp;
}

/** plaza deck, the stepped lakeside terrace and the passage through the arch */
function ground(g) {
  const grp = new THREE.Group();
  const DECK = 5.5;              // promenade level, metres above the lake surface
  const zBack = -1900, zShore = GATE.shoreZ + 4;
  const deck = mesh([box(3600, DECK + 4, zShore - zBack, 0, -4, (zBack + zShore) / 2)], M.stone);
  deck.receiveShadow = true;
  deck.name = 'plaza';
  grp.add(deck);

  // the far and opposite shores: without ground the mirrored towers would hang
  // in mid-air past the water's edge
  const land = [];
  land.push(box(7000, 12, 2400, 0, -12.2, LAKE.farZ + 1200));
  for (const sx of [-1, 1]) land.push(box(2200, 12, LAKE.farZ, sx * (LAKE.halfWidth + 1100), -12.2, (LAKE.nearZ + LAKE.farZ) / 2));
  const lm = mesh(land, M.stoneDark);
  lm.name = 'far-ground';
  grp.add(lm);

  // stepped terrace down to the water, the last few treads stay wet
  const steps = [];
  for (let k = 0; k < 6; k++) {
    steps.push(box(760 - k * 24, 0.9, 5.6, 0, DECK - 0.9 - k * 0.92, GATE.shoreZ - 6 + k * 5.6));
  }
  const sm = mesh(steps, M.stone);
  sm.receiveShadow = true;
  grp.add(sm);
  const lip = mesh([box(760, 0.3, 1.1, 0, DECK + 0.15, GATE.shoreZ - 7)], glow('#a6987d',.34));
  grp.add(lip);

  // lamp posts along the promenade — the eye's ruler against a 300 m tower
  const posts = [], lamps = [];
  for (let x = -340; x <= 340; x += 26) {
    const z = GATE.shoreZ - 24;
    posts.push(box(0.45, 6, 0.45, x, DECK, z));
    posts.push(box(2.8, 0.32, 0.32, x, DECK + 5.9, z - 1.1));
    lamps.push(box(2, 0.28, 0.28, x, DECK + 5.6, z - 1.6));
    ANCHORS.podium.push(new THREE.Vector3(x, DECK + 5.4, z - 1.6));
  }
  grp.add(mesh(posts, M.steel));
  grp.add(mesh(lamps, glow('#ffe2b0', 1.9)));

  // inlay stripes in the plaza pointing at the gate
  const inlay = [];
  for (const sx of [-1, 1]) inlay.push(box(1.1, 0.12, 170, sx * 52, DECK + 0.06, GATE.shoreZ - 100));
  grp.add(mesh(inlay, glow('#8fe0ff', 0.9)));
  g.add(grp);
  return grp;
}

/* ------------------------------------------------------------------ assembly */

export function buildGate(scene) {
  const {shape}=gateGeometry();
  const skin=sculptGateSkin({H,DEPTH,apex:APEX,archHalf,outerHalf});
  const group = new THREE.Group();
  group.name = 'gate';
  scene.add(group);

  group.add(towers(skin.shell),skin.mullions);
  const lakeside=buildJinjiLandscape(scene);
  edgeLights(group);
  archLights(group);
  bridge(group);
  const pod = podium(group);
  const crownGrp = crown(group);
  // the plaza is deliberately kept out of `group`: mirroring a 1500 m slab would
  // paint the whole lake bed and swallow the tower reflections
  const groundGrp = ground(scene);

  return {
    group, lakeside, skin,
    /** front elevation outline, reused by the media facade in show.js */
    shape,
    podium: pod,
    crown: crownGrp,
    ground: groundGrp,
    anchors: ANCHORS,
    frontZ: FRONT,
    height: H,
    archHalf,
    outerHalf,
    apex: APEX,
    archCurve: archCurvePoints(),
  };
}
