import * as THREE from 'three';
import { box, glow, lit, mesh, M } from './kit.js';

// Actual three-dimensional curtain wall shell. The described dimensions and the
// photo-inferred profiles are kept separate: this is not a survey model.
export function sculptGateSkin({H,DEPTH,apex,archHalf,outerHalf}){
  const dep=DEPTH*.5, frontBySide=new Map();
  const get=(y,s,u,face)=>{
    const a=y>=apex?0:archHalf(y), o=outerHalf(y);
    const x=s*(a+(o-a)*u);
    const upper=Math.pow(Math.max(0,(y/H-.78)/.22),2);
    const inward=Math.pow(Math.abs(2*u-1),5)*(y<apex ? 3.35 : u*u*2.8);
    const swell=.7*Math.sin(y/H*Math.PI);
    return [x,y,face*(dep-inward-upper*3.8+swell) -(face<0?.7:0)];
  };
  const blocks=[];
  const append=(sets,unit,reverse,material)=>blocks.push({sets,unit,reverse,material});
  const ys=Array.from({length:81},(_,i)=>i*H/80);ys.push(apex);ys.sort((a,b)=>a-b);
  for(const s of [-1,1])for(const f of [-1,1]){
    const points=[];
    for(const y of ys)points.push(Array.from({length:17},(_,i)=>get(y,s,i/16,f)));
    append(points,p=>[p[0],p[1]],s*f<0,0);
    if(!frontBySide.has(f))frontBySide.set(f,[]);
    frontBySide.get(f).push({points,reverse:s*f<0});
  }
  for(const side of [-1,1])for(const u of [0,1]){
    const points=[];
    for(const y of ys){
      if(u===0&&y>apex)break;
      const a=get(y,side,u,-1),b=get(y,side,u,1);
      points.push(Array.from({length:13},(_,i)=>{
        const mix=i/12,z=THREE.MathUtils.lerp(a[2],b[2],mix),p= Math.sin(Math.PI*mix);
        return [a[0]+side*(u===0?-1:1)*1.8*p,y,z];
      }));
    }
    append(points,p=>[p[2],p[1]],side*(u?1:-1)>0,1);
  }
  for(const s of [-1,1]){
    const cap=[];
    for(const f of [-1,1])cap.push(Array.from({length:17},(_,i)=>get(H,s,i/16,f)));
    append(cap,p=>[p[0],p[2]],s>0,2);
  }
  const make=(patches)=>{
    const pos=[],uv=[],ind=[],matGroups=[];
    for(const {sets,unit,reverse,material} of patches){
      const base=pos.length/3,n=sets[0].length,start=ind.length;
      for(const row of sets)for(const p of row){pos.push(...p);uv.push(...unit(p));}
      for(let iy=0;iy<sets.length-1;iy++)for(let ix=0;ix<n-1;ix++){
        const a=base+iy*n+ix,b=a+1,c=a+n,d=c+1;
        ind.push(...(reverse?[a,c,b,b,c,d]:[a,b,c,b,d,c]));
      }
      matGroups.push([start,ind.length-start,material]);
    }
    const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(ind);g.computeVertexNormals();
    for(const group of matGroups)g.addGroup(...group);return g;
  };
  const skin=make(blocks);
  const trims=[];
  for(const side of [-1,1])for(const face of [-1,1])for(let k=2;k<6;k++){
    const points=ys.map(y=>{
      const p=get(y,side,k/7,face);
      return new THREE.Vector3(p[0],p[1],p[2]+face*.065);
    });
    const fcurve=new THREE.CatmullRomCurve3(points);
    trims.push(new THREE.TubeGeometry(fcurve,84,.099,4,false));
  }
  const mullions=mesh(trims,lit('#637b8b',{rough:.62,metal:.35,emissive:'#1e3546',ei:.26}));
  mullions.name='gate-curtain-mullions';
  // The show rides the same curved skin, rather than a giant floating plane.
  const overlays=[1,-1].map(f=>make(frontBySide.get(f).map(({points,reverse})=>({
    sets:points.map(row=>row.map(([x,y,z])=>[x,y,z+f*.055])),unit:p=>[p[0],p[1]],reverse,material:0,
  }))));
  return {shell:skin,mullions,overlays};
}

export function buildJinjiLandscape(scene){
  const group=new THREE.Group();group.name='jinji-reference-landmarks';
  const deck=[],piers=[],lamps=[],blue=[],copper=[],amberFaces=[],wings=[],glass=[];
  const a=[-1418,535],b=[-241,126], dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz);
  const cx=(a[0]+b[0])/2,cz=(a[1]+b[1])/2, ang=Math.atan2(-dz,dx);
  const at=(parts,w,h,d,y,x,z,angle=ang)=>{
    const geo=new THREE.BoxGeometry(w,h,d);geo.rotateY(angle);geo.translate(x,y,z);parts.push(geo);
  };
  at(deck,len,2.65,23,5.24,cx,cz);
  at(deck,len,.95,24.5,6.81,cx,cz);
  for(let i=1;i<31;i++){
    const u=i/32,x=a[0]+dx*u,z=a[1]+dz*u;
    at(piers,4.9,6.15,9.1,2.64,x,z);
    at(piers,7.2,.9,13.2,4.55,x,z);
    if(i%2!==0){
      at(lamps,.31,6.4,.31,9.38,x+2.2,z+8.6);
      at(copper,1.57,.34,.79,12.68,x+2.2,z+8.55);
    }
    if(i%9!==0)at(blue,len/32*.94,.86,.72,6.81,x+3,z+12);
    if(i%5!==1){
      at(copper,3.6,.54,.27,4.99,x+2.1,z+9.45);
      at(amberFaces,2.75,3.2+(i%4)*.35,.42,2.12,x+1.18,z+4.47);
    }
  }
  group.add(mesh(deck,lit('#30353d',{rough:.87,emissive:'#172434',ei:.25})));
  group.add(mesh(piers,lit('#3a3b3b',{rough:.94,emissive:'#1b201f',ei:.32})));
  group.add(mesh(lamps,M.steel),mesh(blue,glow('#5776fd',1.15)),mesh(copper,glow('#e6ba7b',.91)),mesh(amberFaces,glow('#c58a4c',.46)));

  // Shapes are a lower commercial wing, grouped behind the tower rather than
  // claimed as a detailed surveyed model of the shopping complex.
  for(const [x,z,w,d,h] of [[-191,-107,99,74,25],[-262,-132,76,67,33],[-154,-174,98,65,31],[153,-119,108,84,27],[222,-146,96,92,35]]){
    wings.push(box(w,h,d,x,5.5,z),box(w*.79,2.6,d*.76,x,5.5+h,z));
    for(let k=0;k<12;k++){
      if((k+Math.round(x))%4===0)continue;
      glass.push(box(w*.061,2.2,.35,x-w*.46+k*w*.079,9+(k%2)*4,z+d*.5+.13));
    }
  }
  group.add(mesh(wings,M.concrete),mesh(glass,glow('#e1bb85',.55)));
  const stones=[];
  for(const [x0,z0] of [[89,927],[-1012,725]]){
    for(let i=0;i<18;i++){
      const shape=new THREE.IcosahedronGeometry(1,1);
      const width=2+(i%7)*.83;
      shape.scale(width,.41+(i%4)*.36,width*.82);
      shape.rotateY(i*.98);shape.translate(x0+Math.sin(i*2.37)*(15+i*2),.3,z0+Math.cos(i*1.85)*(11+i));stones.push(shape);
    }
  }
  group.add(mesh(stones,lit('#68717a',{rough:.96,emissive:'#1f2b36',ei:.25})));
  scene.add(group);
  return {group,bridgePoints:Array.from({length:22},(_,i)=>{
    const u=(i+1)/25;return [a[0]+dx*u,a[1]+dz*u];
  })};
}
