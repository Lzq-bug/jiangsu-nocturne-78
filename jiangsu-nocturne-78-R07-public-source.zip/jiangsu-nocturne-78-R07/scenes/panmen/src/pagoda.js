import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { M, glow, box, mesh } from './kit.js';
import { SITE, LEVEL } from './data.js';
import * as T from './textures.js';

const P = SITE.pagoda;
const N = 8;                        // 平面八角
const baseY = LEVEL.quay + 0.1;

/** 八角棱柱的一段：CylinderGeometry 八边即八角形，UV 绕一周 */
function tierGeo({ r0, r1, h, rot = 0 }) {
  const g = new THREE.CylinderGeometry(r1, r0, h, N, 1, false);
  g.rotateY(rot);
  g.translate(0, h / 2, 0);
  return g;
}

/** 逐檐做出八条会聚的瓦坡和微翘檐角，砖身仍保持同一套八面轴。 */
function eaveGeo({ r, h, rot = 0 }) {
  const points=[], uv=[], ix=[], tips=[];
  const SEG=12, ROW=5;
  for(let side=0;side<N;side++){
    const a=rot+side*Math.PI*2/N, b=rot+(side+1)*Math.PI*2/N;
    const x0=Math.sin(a),z0=Math.cos(a),x1=Math.sin(b),z1=Math.cos(b);
    const offset=points.length/3;
    for(let j=0;j<=ROW;j++){
      const q=j/ROW, radius=r*(.60+.40*q);
      for(let i=0;i<=SEG;i++){
        const u=i/SEG,corner=Math.pow(2*Math.abs(u-.5),3.2), dy=(.61-.91*q+.22*q*q+corner*.31*Math.pow(q,2.4))*h;
        points.push((x0+(x1-x0)*u)*radius,dy,(z0+(z1-z0)*u)*radius);
        uv.push(u*3,q*1.5);
        if(i<SEG&&j<ROW){
          const k=offset+j*(SEG+1)+i;
          ix.push(k,k+1,k+SEG+1,k+1,k+SEG+2,k+SEG+1);
        }
      }
    }
    const xx=x0*r*.988,zz=z0*r*.988;
    tips.push(box(.35,.23,.35,xx,h*.21,zz));
    tips.push(box(.12,.34,.12,xx,-h*.19,zz));
    const foot=box(r*.75,.14,.12,0,-h*.18,0);
    foot.rotateY(-Math.atan2(z1-z0,x1-x0));
    foot.translate((x0+x1)*r*.485,0,(z0+z1)*r*.485);
    tips.push(foot);
  }
  const main=new THREE.BufferGeometry();
  main.setAttribute('position',new THREE.Float32BufferAttribute(points,3));
  main.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  main.setIndex(ix);main.computeVertexNormals();
  return { main, tips:merge(tips) };
}

function merge(parts) {
  return mergeGeometries(parts);
}

/** 平座勾栏：檐下的一圈矮栏，返回几何以便并入总组 */
function balustrade({ r, rot = 0 }) {
  const parts = [];
  for (let i = 0; i < N; i++) {
    const a = rot + (i / N) * Math.PI * 2 + Math.PI / N;
    const b = rot + ((i + 1) / N) * Math.PI * 2 + Math.PI / N;
    const x0 = Math.cos(a) * r, z0 = Math.sin(a) * r;
    const x1 = Math.cos(b) * r, z1 = Math.sin(b) * r;
    const len = Math.hypot(x1 - x0, z1 - z0);
    const mid = [(x0 + x1) / 2, (z0 + z1) / 2];
    const ang = -Math.atan2(z1 - z0, x1 - x0);
    const rail = box(len, 0.14, 0.2, 0, 0.86, 0);
    rail.rotateY(ang);
    rail.translate(mid[0], 0, mid[1]);
    parts.push(rail);
    const sill = box(len, 0.3, 0.16, 0, 0.18, 0);
    sill.rotateY(ang);
    sill.translate(mid[0], 0, mid[1]);
    parts.push(sill);
    for (const t of [0.08, 0.5, 0.92]) {
      const px = x0 + (x1 - x0) * t, pz = z0 + (z1 - z0) * t;
      const post = box(0.14, 1.0, 0.14, px, 0.5, pz);
      parts.push(post);
    }
  }
  return merge(parts);
}

/** 每层八面里挑四面开窗，逐层错开一面 */
function faces(rot) {
  const out = [];
  for (let i = 0; i < N; i++) {
    const a = rot + (i / N) * Math.PI * 2 + Math.PI / N;
    out.push({ i, a });
  }
  return out;
}

function spire(grp, lights, y) {
  const st = new THREE.Group();
  // 刹座：八棱台形木构框架，一粗刹柱加八根小柱
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.6, 1.2, N), M.stoneDressed);
  base.position.y = 0.6;
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.3, 7.4, 8), M.beam);
  shaft.position.y = 4.2;
  const small = [];
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2 + Math.PI / N;
    const g = new THREE.CylinderGeometry(0.11, 0.13, 2.9, 6);
    g.translate(Math.cos(a) * 1.05, 2.3, Math.sin(a) * 1.05);
    small.push(g);
  }
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.95, 16, 12), M.gilt);
  bowl.position.y = 4.0;
  bowl.scale.y = 0.75;
  st.add(base, shaft, bowl, mesh(small, M.beam));

  let ty = 4.7;
  const rings = [];
  for (let i = 0; i < 6; i++) {
    const r = 0.78 - i * 0.1;
    const ring = new THREE.CylinderGeometry(r, r, 0.16, 14);
    ring.translate(0, ty, 0);
    rings.push(ring);
    ty += 0.44;
  }
  st.add(mesh(rings, M.gilt));
  const finial = new THREE.Mesh(new THREE.SphereGeometry(0.42, 12, 10), glow('#ffe0ab', 1.9));
  finial.position.y = ty + 0.5;
  const cap = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.85, 8), M.gilt);
  cap.position.y = ty + 1.15;
  st.add(finial, cap);
  st.position.y = y;
  grp.add(st);
  lights.push({ p: [0, y + ty + 0.5, 0], color: '#ffe0ab', halo: 2.4, column: 0 });
  return st;
}

/** 塔院：一圈矮墙、山门与香炉，把塔托在一块干净的暗地上 */
function yard(grp, lights) {
  const r = P.yard.r;
  const parts = [];
  const n = 26;
  for (let i = 0; i < n; i++) {
    const a0 = (i / n) * Math.PI * 2, a1 = ((i + 1) / n) * Math.PI * 2;
    if (a0 > -0.28 && a0 < 0.28) continue;    // 南面开门
    const chord = r * (a1 - a0) * 1.05;
    const p = box(chord, P.yard.wallTop - baseY, 0.6, 0, (baseY + P.yard.wallTop) / 2, 0);
    p.rotateY(-(a0 + a1) / 2);
    p.translate(Math.sin((a0 + a1) / 2) * r, 0, Math.cos((a0 + a1) / 2) * r);
    parts.push(p);
  }
  grp.add(mesh(parts, M.wall));
  // 月台与香炉
  const terrace = new THREE.Mesh(new THREE.CylinderGeometry(P.r0 + 3.4, P.r0 + 3.8, 0.9, N, 1), M.stoneDressed);
  terrace.position.set(0, baseY + 0.45, 0);
  terrace.rotation.y = Math.PI / N;
  grp.add(terrace);
  const burner = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.6, 1.1, 10), M.gilt);
  burner.position.set(0, baseY + 1.5, P.r0 + 9);
  grp.add(burner);
  lights.push({ p: [0, baseY + 2.4, P.r0 + 9], color: '#ffb066', halo: 2.4, column: 3 });
}

export function buildPagoda(scene) {
  const group = new THREE.Group();
  group.name = 'ruiguang-tower';
  const lights = [];
  const brick = [];
  const timber = [];
  const carved = [];
  const eaves = [];
  const rails = [];
  const glows = [];

  let y = baseY + 0.9;
  const rot0 = Math.PI / N;
  for (let s = 0; s < P.storeys; s++) {
    const t = s / (P.storeys - 1);
    const r0 = P.r0 * Math.pow(P.taper, s);
    const r1 = P.r0 * Math.pow(P.taper, s + 0.62);
    const h = P.floorH[s];
    const rot = rot0;

    const body = tierGeo({ r0, r1, h, rot });
    body.translate(0, y, 0);
    // 下部五层砖砌筒体，六、七层改木构
    (s >= P.timberFrom ? timber : brick).push(body);

    // 腰檐压在每一层顶，出挑大而坡度平，第一层最阔
    const er = r1 + (2.95 - t * 1.22);
    const eh = 1.55 - t * 0.56;
    const ev = eaveGeo({ r: er, h: eh, rot });
    ev.main.translate(0, y + h, 0);
    eaves.push(ev.main);
    const tipG = ev.tips.clone();
    tipG.translate(0, y + h, 0);
    rails.push(tipG);

    // 平座：檐下一圈勾栏
    const bal = balustrade({ r: r1 + 1.29, rot });
    bal.translate(0, y + h - 0.12, 0);
    rails.push(bal);

    // 门窗：四面开，逐层错开，灯就藏在这些面后头
    // 门窗：一层只四面开门，四层以上四面交错开门洞、另四面隐刻直棂窗
    const fs = faces(rot);
    for (const f of fs) {
      const nx = Math.cos(f.a), nz = Math.sin(f.a);
      const rr2 = THREE.MathUtils.lerp(r0,r1, s===0?.26:.46) * Math.cos(Math.PI/N);
      if (f.i % 2 !== s % 2) {
        if (s >= 3) {
          // 隐刻直棂窗：砖壁上刻出的窗形，不透光
          const g = box(1.0, 1.55, 0.16, 0, 0, 0);
          g.rotateY(Math.PI / 2 - f.a);
          g.translate(nx * (rr2 + 0.02), y + h * 0.46, nz * (rr2 + 0.02));
          carved.push(g);
        }
        continue;
      }
      const isDoor = s === 0;
      const w = isDoor ? 1.5 : 1.05;
      const hh = isDoor ? h * 0.42 : h * 0.4;
      const leaf = new THREE.Mesh(new THREE.PlaneGeometry(w, hh), M.lattice);
      // 窗面贴在八角壁上，法线沿半径朝外
      leaf.position.set(nx * (rr2 + 0.14), y + h * (isDoor ? 0.26 : 0.46), nz * (rr2 + 0.14));
      leaf.rotation.y = Math.PI / 2 - f.a;
      glows.push(leaf);
      // 深朱木门窗套，开孔发暖但外墙和瓦面不发光。
      const frame=box(w+.19,hh+.15,.16,0,0,0);
      frame.rotateY(Math.PI/2-f.a);
      frame.translate(nx*(rr2+.055),y+h*(isDoor?.26:.46),nz*(rr2+.055));
      timber.push(frame);
      if (s % 2 === 0 || s === 1) {
        lights.push({
          p: [nx * (rr2 + 0.5), y + h * (isDoor ? 0.3 : 0.46), nz * (rr2 + 0.5)],
          color: s > 3 ? '#ffcf92' : '#ffb066',
          halo: 0.9 + (P.storeys - s) * 0.1,
          column: s === 0 ? 5 : 2.6,
        });
      }
    }
    y += h;
  }

  // 第七层腰檐就是檐顶；不要另堆一个重叠的第八檐。

  const brickMat = M.towerBrick.clone();
  brickMat.map = M.towerBrick.map.clone();
  brickMat.map.repeat.set(7, 2.2);
  brickMat.map.needsUpdate = true;

  const bodyMesh = mesh(brick, brickMat);
  bodyMesh.castShadow = true;
  const woodMesh = mesh(timber, M.beam);
  woodMesh.castShadow = true;
  group.add(bodyMesh, woodMesh);
  group.add(mesh(eaves, M.roof));
  group.add(mesh(rails, M.pillar));
  group.add(mesh(carved, M.ink));
  for (const g of glows) group.add(g);

  spire(group, lights, y + 1.0);
  yard(group, lights);

  // 塔址：全部几何都在局部坐标里建，摆放只改组位置
  group.position.set(P.x, 0, P.z);
  addLamps(group, lights);
  scene.add(group);
  return { group, lights: group.userData.lamps, top: y + P.spireH };
}

function addLamps(group, spots) {
  const lamps = [];
  for (const s of spots) {
    const p = s.p;
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), glow(s.color || '#ffcf92', 1.6));
    bulb.position.set(p[0], p[1], p[2]);
    group.add(bulb);
    if (s.halo) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({
        map: T.softGlow('255,206,142', 0.12), transparent: true, opacity: 0.24,
        blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
      }));
      sp.scale.setScalar(s.halo * 0.32);
      sp.position.set(p[0], p[1], p[2]);
      group.add(sp);
    }
    if (s.column) {
      const wp = new THREE.Vector3(p[0], p[1], p[2]).add(group.position);
      lamps.push({ p: wp, color: s.color, width: s.column * 0.45, depth: s.column });
    }
  }
  group.userData.lamps = lamps;
  return lamps;
}
