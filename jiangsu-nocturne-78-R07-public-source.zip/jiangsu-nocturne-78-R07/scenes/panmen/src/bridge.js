import * as THREE from 'three';
import { M, glow, box, mesh } from './kit.js';
import { SITE, LEVEL } from './data.js';
import * as T from './textures.js';

const B = SITE.bridge;
const CY = B.crown - B.radius;                 // 拱圆心标高
const A = B.span / 2;                          // 半跨
/** 坦拱：拱脚处与水平线的夹角 φ = acos(半跨 / 半径)，圆弧走中间那一段 */
const PHI = Math.acos(Math.min(1, A / B.radius));
const TH1 = Math.PI - PHI, TH2 = PHI;
const HALF = B.length / 2;

/** 高拱顶有一小段平桥心，两堍石级渐次放缓；不是栏板跟着券洞直接走圆。 */
function deckY(x) {
  const ax = Math.min(HALF, Math.abs(x));
  const high = B.crown + B.deckT + 0.44;
  if (ax <= 2.25) return high;
  if (ax <= 9.1) {
    const t = (ax - 2.25) / 6.85;
    return THREE.MathUtils.lerp(high, 8.04, t * t * (1.65 - 0.65 * t));
  }
  if (ax <= 19.2) return THREE.MathUtils.lerp(8.04, 4.71, (ax - 9.1) / 10.1);
  return THREE.MathUtils.lerp(4.71, LEVEL.quay + 0.11, (ax - 19.2) / (HALF - 19.2));
}
const openingBottom = -0.18;
const intrados = (t, offset=0) => [Math.cos(t)*(B.radius+offset), CY+Math.sin(t)*(B.radius+offset)];
/** 半径 r 的一段圆弧面，沿 Z 拉出宽度：拱腹就靠它 */
function arcBand({ r, cy, t0, t1, width, seg = 30 }) {
  const pos = [], uv = [], idx = [];
  const nv = seg + 1;
  for (const z of [width / 2, -width / 2]) {
    for (let i = 0; i <= seg; i++) {
      const th = t0 + ((t1 - t0) * i) / seg;
      const x = Math.cos(th) * r, y = cy + Math.sin(th) * r;
      pos.push(x, y, z);
      uv.push((th - t0) * r / 2.4, z / 2.4);
    }
  }
  for (let i = 0; i < nv - 1; i++) {
    const a = i, b = i + 1, c = nv + i, d = c + 1;
    idx.push(a, c, b, b, c, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/** 一座单孔石桥。显式连接石身的两面、顶面、底面和券洞；
 * 不把跨越复杂轮廓的孔洞交给通用三角化器，以免共线点和轮廓穿插形成坏三角面。
 */
function bridgeBody() {
  const position=[], uv=[], indices=[], D=B.width*.5;
  function quad(a,b,c,d,projection){
    const k=position.length/3;
    for(const p of [a,b,c,d]){
      position.push(...p);
      uv.push(...(projection===0?[p[0],p[1]]:projection===1?[p[0],p[2]]:[p[2],p[1]]));
    }
    indices.push(k,k+1,k+2,k,k+2,k+3);
  }
  const extrudedStrip=(x0,x1,y0,y1)=>{
    const a0=deckY(x0)-.158, a1=deckY(x1)-.158;
    quad([x0,y0,D],[x1,y1,D],[x1,a1,D],[x0,a0,D],0);
    quad([x1,y1,-D],[x0,y0,-D],[x0,a0,-D],[x1,a1,-D],0);
    quad([x0,a0,D],[x1,a1,D],[x1,a1,-D],[x0,a0,-D],1);
    quad([x0,y0,-D],[x1,y1,-D],[x1,y1,D],[x0,y0,D],1);
  };
  const archY=x=>CY+Math.sqrt(Math.max(0,B.radius**2-x*x));
  for(const [x0,x1,h,n] of [
    [-HALF,-A,()=>B.base,50],[-A,A,archY,56],[A,HALF,()=>B.base,50],
  ]){
    for(let i=0;i<n;i++){
      const l=THREE.MathUtils.lerp(x0,x1,i/n),r=THREE.MathUtils.lerp(x0,x1,(i+1)/n);
      extrudedStrip(l,r,h(l),h(r));
    }
  }
  for(const x of [-HALF,-A,A,HALF]){
    const y2=Math.abs(x)===A?archY(x):deckY(x)-.158;
    quad([x,B.base,-D],[x,B.base,D],[x,y2,D],[x,y2,-D],2);
  }
  const geo=new THREE.BufferGeometry();
  geo.setAttribute('position',new THREE.Float32BufferAttribute(position,3));
  geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  geo.setIndex(indices);geo.computeVertexNormals();geo.computeBoundingSphere();
  return geo;
}

/** 真正的楔形券石：沿半径长短边切开，保留薄灰缝，外加垂直券脚层砌。 */
function ringFace(depth = 0.22, ring = 0.54, count = 25) {
  const result = [];
  const springY = intrados(TH1)[1];
  for (let i = 0; i < count; i++) {
    const ta = TH1 + (TH2-TH1)*(i+0.025)/count;
    const tb = TH1 + (TH2-TH1)*(i+0.975)/count;
    const width = ring * (i === Math.floor(count/2) ? 1.12 : (0.92 + (i*7%5)*.04));
    const s = new THREE.Shape();
    s.moveTo(...intrados(ta,-.01)); s.lineTo(...intrados(tb,-.01));
    s.lineTo(...intrados(tb,width)); s.lineTo(...intrados(ta,width)); s.closePath();
    const g = new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:false});
    g.translate(0,0,-depth/2);
    result.push(g);
  }
  for (const sign of [-1,1]) {
    for (let i=0;i<7;i++){
      const row=(springY-openingBottom)/7;
      result.push(box(ring*(1.02+(i%3)*.055),row-.015,depth,
        sign*(A+ring*.43),openingBottom+row*(i+.5),0));
    }
  }
  return result;
}

/** 金刚墙两翼顺岸展宽，留实墙与贴水窄纤道，不另开第二个孔。 */
function bankWings(){
  const wall=[], copings=[], feet=[];
  for (const s of [-1,1]){
    for(const q of [-1,1]){
      const n=12;
      for(let i=0;i<n;i++){
        const t0=i/n,t1=(i+1)/n;
        const x0=s*(8.3+11.4*t0),x1=s*(8.3+11.4*t1);
        const z0=q*(2.13+9.3*Math.pow(t0,.78)),z1=q*(2.13+9.3*Math.pow(t1,.78));
        const az = -Math.atan2(z1-z0,x1-x0);
        const run=Math.hypot(x1-x0,z1-z0), x=(x1+x0)/2, z=(z1+z0)/2;
        const y=3.56+1.36*(1-(t0+t1)*.5);
        const put = (g,a,b,c) => { g.rotateY(az);g.translate(a,b,c);return g; };
        wall.push(put(box(run+.13,y+0.46,1.28),x,(y-.46)*.5,z));
        copings.push(put(box(run+.16,.20,1.59),x,y+.012,z));
        feet.push(put(box(run+.05,.32,1.10),x-s*.55,.17,z+q*.35));
      }
    }
  }
  return [mesh(wall,M.bridgeBrick),mesh(copings,M.graniteCrown),mesh(feet,M.graniteWet)];
}

/** 栏板与望柱沿桥面曲线立起来 */
function railing(side, lights) {
  const parts = [];
  const w = B.width / 2 - 0.2;
  const step = 1.7;
  for (let x = -HALF; x < HALF; x += step) {
    const len = Math.min(step, HALF - x);
    const y = deckY(x), ny = deckY(Math.min(HALF, x + len));
    const mid = (y + ny) / 2;
    const slope = Math.atan2(ny - y, len);
    // 构件一律先在原点摆好、转坡、再搬上桥：先搬后转会绕世界原点甩出去
    const put = (g, dy, dz) => { g.rotateZ(slope); g.translate(x + len / 2, mid + dy, side * (w + dz)); return g; };
    if(Math.round((x+HALF)/step)%4===0){
      parts.push(put(box(.31,.94,.26),.48,0));
      parts.push(put(box(.35,.12,.31),.99,0));
    }
    parts.push(put(box(len+.035,.74,.20),.29,0));
    parts.push(put(box(len+.048,.14,.29),.71,0));
    parts.push(put(box(len+.031,.15,.29),.03,0));
  }
  // 柱头灯立在两肩、高出视平线：正中的那盏会正好糊在桥顶机位上
  for (const x of [-(A + 0.5), A + 0.5]) {
    lights.push({
      p: [x, deckY(x) + .84, side * w],
      color: '#ffcf92', halo: 1.3, column: 2.4,
    });
  }
  return parts;
}

/** 桥头细节：系缆石与桥头灯。桥身侧面已是石面，不再叠多余的石皮 */
function approach(lights) {
  const stone = [];
  const xa = B.abutment.fromX;
  for (const s of [-1, 1]) {
    for (let i = 0; i < 4; i++) {
      const x = s * (xa - 1.2 - i * 2.4);
      const y = deckY(x);
      for (const k of [-1, 1]) {
        stone.push(box(0.5, 0.85, 0.5, x, y + 0.3, k * (B.width / 2 + 0.55)));
      }
    }
    lights.push({ p: [s * (xa + 1.6), LEVEL.quay + 4.4, 0], color: '#ffb066', halo: 1.4, column: 3.2 });
  }
  return { bollards: mesh(stone, M.stoneDressed) };
}

function addLamps(group, spots) {
  const lamps = [];
  for (const s of spots) {
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), glow(s.color || '#ffcf92', 1.5));
    bulb.position.set(...s.p);
    group.add(bulb);
    if (s.halo) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({
        map: T.softGlow('255,204,138', 0.14), transparent: true, opacity: 0.27,
        blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
      }));
      sp.scale.setScalar(s.halo * 0.32);
      sp.position.set(...s.p);
      group.add(sp);
    }
    if (s.column) lamps.push({ p: new THREE.Vector3(...s.p), color: s.color, width: s.column * 0.5, depth: s.column });
  }
  group.userData.lamps = lamps;
  return lamps;
}

export function buildBridge(scene) {
  const group = new THREE.Group();
  group.name = 'wumen-bridge';
  const lights = [];

  // 桥身实体：券洞是真洞，船能穿过去
  const structural = mesh(bridgeBody(), M.bridgeBrick);
  structural.name='吴门桥单孔主券';group.add(structural, ...bankWings());

  // 拱腹：一层圆柱面贴在洞顶，把 Extrude 的洞壁读成砌砖
  group.add(new THREE.Mesh(
    arcBand({ r: B.radius-.018, cy: CY, t0: TH1, t1: TH2, width: B.width - 0.08, seg: 56 }),
    M.bridgeSoffit,
  ));

  // 两堍各 50 道踏面，石缝有不齐的横向分割。履道连续并压在实体桥台上。
  const deck=[], HALF_LANDING=2.25, tread=(HALF-HALF_LANDING)/50;
  for(const sign of [-1,1]){
    for(let i=0;i<50;i++){
      const xx=HALF_LANDING+tread*i;
      const y=deckY(xx+tread*.35),low=deckY(xx+tread*1.25);
      const joint=((i*23%9)-4)*.075;
      const z0=-B.width*.452,z1=B.width*.452;
      for(const [za,zb] of [[z0,joint-.013],[joint+.013,z1]]){
        const h=Math.max(.32,(y-low)+.24);
        deck.push(box(tread-.014,h,zb-za,sign*(xx+tread/2),y-h/2+.075,(za+zb)/2));
      }
    }
  }
  deck.push(box(4.5,.25,B.width-.5,0,deckY(0)-.05,0));
  group.add(mesh(deck,M.pavingWarm));

  const ringBins=[[],[],[]];
  for (const side of [-1,1]) {
    for (const [i,geo] of ringFace().entries()) {
      geo.translate(0,0,side*(B.width/2+.048));
      ringBins[((i*13)%7)%3].push(geo);
    }
  }
  const tones=[M.graniteCrown,M.stoneDressed,M.bridgeSoffit];
  ringBins.forEach((parts,i)=>group.add(mesh(parts,tones[i])));
  group.add(mesh(railing(1, lights), M.graniteCrown));
  group.add(mesh(railing(-1, lights), M.graniteCrown));

  // 桥心石：拱顶正中一块稍亮的条石
  group.add(mesh([box(2.3, 0.12, B.width - 0.8, 0, deckY(0) + .13, 0)], M.stone));

  // 桥额两面都刻，嵌在拱顶两侧的金刚墙上，不探到行人头前
  for (const s of [1, -1]) {
    const plate = new THREE.Mesh(
      new THREE.PlaneGeometry(.74, 1.02),
      new THREE.MeshStandardMaterial({ map: T.carving('吳門橋', { dir: 'v' }), roughness: 0.88, side: THREE.DoubleSide }),
    );
    plate.position.set(0, B.crown + .77, s * (B.width / 2 + .18));
    if (s < 0) plate.rotation.y = Math.PI;
    group.add(plate);
  }

  const ap = approach(lights);
  group.add(ap.bollards);

  // 券洞内一盏：船过桥洞时两岸的灯火都在洞外
  lights.push({ p: [A-.48, 3.4, -1.14], color: '#efb27c', halo: 1.0, column: 2.2 });

  addLamps(group, lights);
  // Compact reflected light on the north approach; fixtures are not reconstructed.
  // Two short, non-shadowing pools leave the roofline, other reaches and sky unchanged.
  const nearSteps = new THREE.PointLight('#e4cba9', 35, 11.0, 2);
  nearSteps.position.set(8.4, 2.8, -5.6);
  nearSteps.name = 'wumen-north-stair-bounce';
  const archWash = new THREE.PointLight('#ddcfb8', 34, 9.0, 2);
  archWash.position.set(-3.9, 3.0, -2.8);
  archWash.name = 'wumen-north-soffit-bounce';
  group.add(nearSteps, archWash);
  group.position.set(0, 0, B.z);
  scene.add(group);
  return { group, lights: group.userData.lamps, deckY, crown: deckY(0) };
}
