// 镜头特征：岸边的古树、暗水、对岸粉墙的几何窗与临水矮护栏。
import * as THREE from 'three';
import { M, lit, box, mesh, chineseRoof } from './kit.js';
import * as T from './textures.js';
import { GARDEN } from './data.js';
const Y=GARDEN.groundY;
const p=(a)=>new THREE.Vector3(...a);
const bar=(a,b,w,d=w)=>{
  const aa=p(a),bb=p(b),v=bb.clone().sub(aa),mid=aa.clone().lerp(bb,.5);
  const q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),v.clone().normalize());
  return box(w,v.length()+.018,d).applyQuaternion(q).translate(...mid.toArray());
};
function inlay(){
  const gr=new THREE.Group();gr.name='jinhuiyi-angular-window-gallery';
  gr.position.set(GARDEN.zhiyu.x,Y,GARDEN.zhiyu.z);gr.rotation.y=Math.PI/2;
  const white=lit('#d6d1c2',{map:T.plaster('#d1c8b5'),emissive:'#5c574d',ei:.36,rough:.96,side:THREE.DoubleSide});
  const weathered=lit('#a39586',{map:T.stone('#a19d9a'),rough:.94,emissive:'#302c26',ei:.35});
  const wood=lit('#695049',{map:T.wood('#896b60','#4e3630'),rough:.86,emissive:'#3b2921',ei:.36});
  const silhouette=lit('#2c2d27',{emissive:'#383125',ei:.23,rough:1});
  gr.add(mesh([box(10.9,.26,4.56,0,.12,.35),box(11.2,.13,.29,0,.25,2.6)],weathered));
  const posts=[],walls=[],frames=[],lattice=[],recess=[],rail=[],details=[];
  for(let i=0;i<7;i++){
    const x=-5.13+i*1.71;posts.push(box(.125,1.08,.16,x,.65,2.53));
    details.push(box(.223,.115,.208,x,1.21,2.53),box(.224,.99,.34,x,-.29,2.24));
  }
  rail.push(box(10.44,.074,.188,0,1.13,2.53),box(10.42,.085,.135,0,.61,2.53));
  for(let i=0;i<12;i++){
    const x=-4.74+i*.86,z=2.52;
    if(i%2===0){
      rail.push(bar([x-.324,.67,z],[x,1.07,z],.046),bar([x,.67,z],[x+.324,1.07,z],.046),bar([x-.324,1.07,z],[x+.324,.67,z],.046));
    }else{
      rail.push(box(.058,.41,.07,x-.25,.87,z),box(.058,.30,.07,x+.025,.93,z),box(.42,.051,.07,x-.039,.86,z),box(.37,.05,.07,x+.01,.98,z));
    }
  }
  // Each octagonal opening has an actual hole in the plaster and a recessed lattice.
  function windowBay(x,cy,r,phase=0){
    const ring=Array.from({length:8},(_,i)=>[x+r*Math.cos(Math.PI/8+i*Math.PI/4),cy+r*Math.sin(Math.PI/8+i*Math.PI/4),.96]);
    const border=ring.map(([u,v])=>[x+Math.sign(u-x)*Math.min(.81,Math.abs(u-x)*1.92),cy+Math.sign(v-cy)*Math.min(.71,Math.abs(v-cy)*1.92),.963]);
    for(let i=0;i<8;i++){
      const j=(i+1)%8;
      const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([...ring[i],...ring[j],...border[j],...border[i]],3));g.setIndex([0,2,1,0,3,2]);g.computeVertexNormals();g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,1,1,0,1],2));walls.push(g);
      frames.push(bar(ring[i],ring[j],.072,.09));
    }
    for(let i=-2;i<=2;i++){
      const d=i*.14,span=(Math.abs(i)>1?.30:.42);
      lattice.push(box(.035,span*1.86,.07,x+d,cy,.89),box(span*1.86,.035,.07,x,cy+d,.89));
      if(phase)lattice.push(bar([x-.28,cy+d,.895],[x+.28,cy+d+.13,.895],.028,.032));
    }
    recess.push(box(1.30,1.30,.15,x,cy,.23));
    walls.push(box(1.67,.35,.15,x,cy+.84,.89),box(1.67,.46,.15,x,cy-.94,.89));
  }
  for(let i=0;i<6;i++){
    const x=-4.15+i*1.66;
    windowBay(x,1.83,.61,i%2);walls.push(box(.16,2.73,.16,x-.83,1.65,.92));
  }
  walls.push(box(.29,2.45,.17,4.88,1.63,.92),box(10.1,.34,.18,0,2.97,.91),box(10.1,.17,.18,0,.53,.91));
  for(const x of [-5.05,-1.68,1.69,5.06])posts.push(box(.18,2.74,.17,x,1.63,2.51));
  posts.push(box(10.5,.2,.28,0,2.99,2.50),box(10.5,.17,.26,0,3.04,-1.70));
  gr.add(mesh(walls,white),mesh(details,weathered),mesh(posts,wood),mesh(rail,wood),mesh(frames,weathered),mesh(lattice,wood),mesh(recess,silhouette));
  const rf=mesh([chineseRoof({width:11.45,depth:5.12,height:.96,ridgeRatio:.91,overhang:.57})],M.roof);
  rf.position.set(0,3.13,.35);gr.add(rf);
  for(const x of [-3.43,2.63]){
    const l=new THREE.PointLight(0xffd5ab,6.9,5.8,1.63);l.position.set(x,2.38,2.38);gr.add(l);
  }
  return gr;
}
function bankTree(){
  const gr=new THREE.Group();gr.name='jinhuiyi-near-bank-tree';
  gr.position.set(78.1,Y,-141.65);
  gr.scale.z=-1;
  const limbs=[],foliage=[],stone=[];
  const tube=(pts,r,n=14)=>new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p)),n,r,7,false);
  // Multiple tapering sweeps instead of a straight tube with a cone crown.
  const stem=[[.15,-.16,.06],[.05,.58,0],[-.26,1.43,.03],[-.72,2.25,.36],[-1.31,3.18,.76],[-2.47,3.83,1.48],[-3.31,4.40,1.9]];
  for(let i=1;i<stem.length;i++){
    const a=p(stem[i-1]),b=p(stem[i]),v=b.clone().sub(a);
    const rad=.375-i*.042;
    limbs.push(new THREE.CylinderGeometry(rad*.89,rad*1.07,v.length()+.10,9,1)
      .applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),v.normalize()))
      .translate(...a.lerp(b,.5).toArray()));
  }
  const sprays=[
    [[-.64,2.17,.32],[-.78,3.80,-.65],[-1.51,4.95,-1.59],[-2.13,5.65,-1.90]],
    [[-1.36,3.25,.85],[-2.62,3.64,1.97],[-4.61,4.09,3.71],[-5.31,3.83,5.4]],
    [[-2.38,3.81,1.40],[-3.71,4.88,1.15],[-5.29,5.03,2.03],[-6.12,5.56,3.8]],
    [[-.88,2.42,.43],[-.49,3.59,1.29],[-1.09,4.27,2.77],[-1.91,4.71,4.0]],
    [[-3.26,4.39,1.85],[-4.41,5.24,2.62],[-5.7,5.67,2.7],[-6.5,5.93,2.96]]
  ];
  const r=i=>.5+.5*Math.sin(i*83.21+Math.cos(i*13.7));
  for(let i=0;i<sprays.length;i++){
    const b=sprays[i];limbs.push(tube(b,.105-i*.01));
    for(let j=0;j<8;j++){
      const t=(j+2)/10,cv=new THREE.CatmullRomCurve3(b.map(p)),v=cv.getPoint(t),side=j%2?1:-1;
      const u=v.clone().add(new THREE.Vector3(-.41-r(j+i)*1.6, -.04-r(j*3)*.81,side*(.6+r(j*4)*1.21)));
      limbs.push(tube([v.toArray(),v.clone().lerp(u,.59).add(new THREE.Vector3(0,.19,0)).toArray(),u.toArray()],.025,7));
      for(let k=0;k<19;k++){
        const a=j*41+k*3+i*137,s=.12+r(a)*.24;
        foliage.push(new THREE.IcosahedronGeometry(s,0).scale(1.7,.48,.98).rotateY(r(a+3)*6.2).translate(u.x+(r(a+9)-.5)*2.8,u.y+(r(a+7)-.5)*.78,u.z+(r(a+2)-.5)*2.2));
      }
    }
  }
  for(let i=0;i<29;i++){
    const s=.28+r(i*4)*.68;
    stone.push(new THREE.IcosahedronGeometry(s,i%3===0?1:0).scale(1.36,.43+r(i*4+2)*.24,.83).rotateY(i*.92).translate(-2.4+i*.17,.04+r(i*6)*.12,(r(i*3+2)-.6)*3.4));
  }
  gr.add(mesh(limbs,lit('#665344',{map:T.wood('#755c4b','#43372b'),emissive:'#30281f',ei:.38,rough:1})),
    mesh(foliage,lit('#35473a',{emissive:'#242d20',ei:.29,rough:1})),
    mesh(stone,lit('#9c9a8b',{map:T.lakeStone('#a49c8e'),emissive:'#37372d',ei:.3,rough:.96})));
  return gr;
}
export function gardenShore(root){
  const gallery=inlay();root.add(gallery,bankTree());
  return gallery.children.filter(o=>o.isLight).map(light=>({light,level:light.intensity}));
}
