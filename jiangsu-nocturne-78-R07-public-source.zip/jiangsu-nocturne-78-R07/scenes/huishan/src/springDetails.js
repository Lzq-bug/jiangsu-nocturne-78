// Photo-led architectural cues; procedural geometry/textures, no photo planes.
import * as THREE from 'three';
import { M, lit, box, mesh, chineseRoof } from './kit.js';
import * as T from './textures.js';
import { SPRING } from './data.js';
const Y=SPRING.groundY;
const stone=(c,e='#21232b')=>lit(c,{map:T.stone('#b2adb0'),rough:.93,emissive:e,ei:.23});
const place=(w,h,d,x,y,z,ry=0)=>box(w,h,d).rotateY(ry).translate(x,y,z);
const path=(pts,r=.025)=>new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(a=>new THREE.Vector3(...a))),18,r,6,false);
function bounds(b) {
  return [b.cx-(b.hw||b.octagon),b.cx+(b.hw||b.octagon),b.cz-(b.hd||b.octagon),b.cz+(b.hd||b.octagon)];
}
function pad(x0,x1,z0,z1) {
  return new THREE.PlaneGeometry(x1-x0,z1-z0).rotateX(-Math.PI/2).translate((x1+x0)/2,Y,(z1+z0)/2);
}
// Grid exclusions are explicit, so neither a floor nor a mirrored floor can blanket the water.
export function springPaving(){
  const rects=[SPRING.upper,SPRING.middle,SPRING.lower].map(bounds);
  const xx=[SPRING.x0,...rects.flatMap(b=>b.slice(0,2)),SPRING.x1].sort((a,b)=>a-b);
  const zz=[SPRING.z0,...rects.flatMap(b=>b.slice(2)),SPRING.z1].sort((a,b)=>a-b),g=[];
  for(let i=1;i<xx.length;i++)for(let j=1;j<zz.length;j++){
    const x=(xx[i]+xx[i-1])/2,z=(zz[j]+zz[j-1])/2;
    if(!rects.some(([a,b,c,d])=>x>a&&x<b&&z>c&&z<d))g.push(pad(xx[i-1],xx[i],zz[j-1],zz[j]));
  }
  const m=mesh(g,stone('#bbb6aa'));m.name='spring-paving-cutouts';m.receiveShadow=true;return m;
}
function board(text,w,h,pos,rot=0,stoneCut=false) {
  const g=new THREE.Group(),c=document.createElement('canvas');c.width=1024;c.height=224;
  const ctx=c.getContext('2d'),rng=i=>(Math.sin(i*91.47)*4758.2)%1;
  ctx.fillStyle=stoneCut?'#38362f':'#25221b';ctx.fillRect(0,0,c.width,c.height);
  for(let j=0;j<7200;j++){const a=Math.abs(rng(j)),b=Math.abs(rng(j+2082));ctx.fillStyle=j%3?'#76737020':'#05040533';ctx.fillRect(a*1024,b*224,2+j%5,1+j%3);}
  ctx.strokeStyle=stoneCut?'#8b7b594e':'#8b6e41';ctx.lineWidth=stoneCut?4:7;ctx.strokeRect(9,9,1006,206);
  if(text){
    ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='700 155px "Noto Serif CJK SC","Noto Sans CJK SC",serif';
    [...text].forEach((a,i)=>{
      const x=(i+0.5)*1024/text.length,y=117+2*(i%2);
      ctx.fillStyle='#090807';ctx.fillText(a,x+2,y+3);
      ctx.fillStyle=stoneCut?'#a69372':'#baa277';ctx.fillText(a,x,y);
      if(stoneCut&&i){ctx.fillStyle='#0b0a078a';ctx.fillRect(i*1024/text.length,0,3,224);}
    });
  } else {
    // Companion tablets are textural marks; no unverified transcriptions.
    ctx.strokeStyle=stoneCut?'#81725488':'#94816a85';ctx.lineWidth=2;
    for(let j=0;j<96;j++){const i=j%24,x=34+i*41,y=45+Math.floor(j/24)*42;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+5+(j%5)*3,y+4);ctx.lineTo(x-2+j%4,y+9);ctx.stroke();}
  }
  const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
  const b=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:tex,toneMapped:false,color:stoneCut?0x817b71:0x938474}));b.position.z=.042;g.add(b);
  g.add(mesh([box(w+.10,h+.09,.075)],stone(stoneCut?'#6e6558':'#625139')));
  g.position.set(...pos);g.rotation.y=rot;return g;
}
function wellRim(){
  const b=SPRING.upper,cap=stone('#c0b9a8','#3c3428'),cut=stone('#989184'),l=[],u=[],fill=[];
  for(let i=0;i<8;i++){
    const a=i*Math.PI/4,beta=a+Math.PI/4,m=(a+beta)/2;
    const rx=Math.cos(m),rz=Math.sin(m),x=b.cx+rx*1.385,z=b.cz+rz*1.385,L=1.20;
    u.push(place(L,.13,.22,x,Y+.22,z,Math.PI/2-m));
    l.push(place(L,.60,.26,x,Y-.113,z,Math.PI/2-m));
    const point=(t,outer)=>[b.cx+snap(Math.cos(t),outer),Y,b.cz+snap(Math.sin(t),outer)];
    const snap=(v,outer)=>Math.abs(v)<1e-8?0:outer?Math.sign(v)*1.38:v*1.33;
    const coords=[point(a,false),point(beta,false),point(beta,true),point(a,true)];
    const tri=new THREE.BufferGeometry();tri.setAttribute('position',new THREE.Float32BufferAttribute(coords.flat(),3));tri.setIndex([0,1,2,0,2,3]);tri.computeVertexNormals();tri.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,1,1,0,1],2));fill.push(tri);
  }
  const grp=new THREE.Group();grp.name='spring-octagonal-limestone-well';grp.add(mesh(u,cap),mesh(l,cut),mesh(fill,cut));return grp;
}
function squaredLining(b,name){
  const panels=[],coping=[];
  for(const s of [-1,1]){
    panels.push(box(b.hw*2+.22,.74,.2,b.cx,Y-.34,b.cz+s*(b.hd+.01)),box(.2,.74,b.hd*2,b.cx+s*(b.hw+.01),Y-.34,b.cz));
    for(let i=0;i<Math.ceil(b.hw*2/.76);i++){const n=Math.ceil(b.hw*2/.76),w=2*b.hw/n;coping.push(box(w-.017,.13,.29,b.cx-b.hw+w*(i+.5),Y+.065,b.cz+s*(b.hd+.12)));}
    for(let i=0;i<Math.ceil(b.hd*2/.7);i++){const n=Math.ceil(b.hd*2/.7),w=2*b.hd/n;coping.push(box(.29,.13,w-.017,b.cx+s*(b.hw+.12),Y+.065,b.cz-b.hd+w*(i+.5)));}
  }
  const gr=new THREE.Group();gr.name=name;gr.add(mesh(panels,stone('#827e76')),mesh(coping,stone('#c3bcae')));return gr;
}
export function springArchitecture(root) {
  root.add(wellRim(),squaredLining(SPRING.middle,'spring-square-lining'),squaredLining(SPRING.lower,'spring-rectangular-lining'));
  const b=SPRING.upper,g=new THREE.Group();g.name='spring-source-shelter';g.position.set(b.cx,Y,b.cz);
  const timber=lit('#765146',{map:T.wood('#8a5e50','#4b332a'),rough:.86,emissive:'#39251d',ei:.32});
  const rail=stone('#b8ad99','#403324'), trim=stone('#988d77');
  const wall=lit('#a99f91',{map:T.plaster('#c2b8a5'),rough:.94,emissive:'#4b443a',ei:.18});
  const posts=[],bases=[],slats=[];
  for(const x of [-2.20,2.20])for(const z of [-2.40,1.73]){
    posts.push(new THREE.CylinderGeometry(.14,.16,2.89,10).translate(x,1.5,z));
    bases.push(box(.36,.15,.36,x,.075,z));
  }
  for(const z of [-2.40,1.73])posts.push(box(4.67,.18,.23,0,2.83,z));
  for(const x of [-2.20,2.20]){
    posts.push(box(.23,.18,4.30,x,2.83,-.35));
    slats.push(box(.105,.09,3.58,x,1.03,-.38),box(.10,.09,3.58,x,.37,-.38));
    for(let i=0;i<13;i++)slats.push(box(.08,.63,.062,x,.70,-2.02+i*.27));
  }
  g.add(mesh(posts,timber),mesh(bases,rail),mesh(slats,timber));
  g.add(mesh([box(4.25,2.68,.17,0,1.36,-2.38)],wall));
  const roof=mesh([chineseRoof({width:5.5,depth:5.2,height:.82,ridgeRatio:.70,overhang:.4})],M.roof);
  roof.position.set(0,2.93,-.33);g.add(roof);
  const joists=[];for(let j=0;j<15;j++)joists.push(box(.067,.095,4.28,-2.22+j*.314,2.865,-.33));
  g.add(mesh(joists,timber));
  const soffit=[];for(let j=0;j<14;j++)soffit.push(box(.306,.035,4.16,-2.08+j*.32,2.924,-.33));
  g.add(mesh(soffit,lit('#4c3f36',{map:T.wood('#6d5747','#493b32'),rough:1,emissive:'#2b251f',ei:.22})));
  const title=board('泉二第下天',1.98,.49,[.16,1.94,-2.277]);
  title.name='spring-inner-bay-title';g.add(title,board('',.64,.57,[-1.53,1.44,-2.27]),board('',1.72,.31,[.18,.92,-2.27]));
  // Low relief guard in the photo is limestone, not the ordinary timber balustrade.
  const fronts=[],scrolls=[];
  for(const x of [-1.66,-.73,.73,1.66]){
    fronts.push(box(.145,.49,.18,x,.31,1.42),box(.22,.10,.24,x,.60,1.42));
    const k=new THREE.SphereGeometry(.115,10,6);k.scale(1,.46,.97).translate(x,.65,1.42);fronts.push(k);
  }
  for(const [x,w] of [[0,1.34],[-1.20,.78],[1.20,.78]]){
    fronts.push(box(w,.27,.13,x,.30,1.42),box(w,.074,.22,x,.465,1.42),box(w,.08,.19,x,.14,1.42));
    for(let j=0;j<Math.round(w/.23);j++){
      const u=x-w*.43+j*.20;
      scrolls.push(path([[u,.30,1.51],[u+.04,.384,1.51],[u+.12,.36,1.51],[u+.105,.30,1.51],[u+.07,.29,1.51],[u+.065,.33,1.51]],.017));
    }
  }
  const guard=new THREE.Group();guard.name='spring-carved-limestone-guardrail';
  guard.add(mesh(fronts,rail),mesh(scrolls,trim));guard.position.z=.37;g.add(guard);
  const lamps=[[-1.75,2.55,.85],[1.6,2.49,-.6]];
  const fixtures=[];
  for(const [x,y,z] of lamps){
    const l=new THREE.PointLight(0xffd2a1,5.5,6,1.95);l.position.set(x,y,z);g.add(l);
    const lens=new THREE.Mesh(new THREE.BoxGeometry(.078,.095,.06),new THREE.MeshBasicMaterial({color:0x907053}));lens.position.set(x,y+.03,z);g.add(lens);fixtures.push({light:l,lens,level:l.intensity});
  }
  root.add(g);return fixtures;
}
export function inscriptionWall(root){
  const b=SPRING.wallCarve,w=7.9,m=new THREE.Group();m.name='spring-separate-inscription-wall';
  const wall=lit('#c9c1b3',{map:T.plaster('#bcb4a4'),rough:1,emissive:'#58544a',ei:.24});
  m.add(mesh([box(w,2.92,.16,0,1.46,0)],wall));
  const coping=[];
  for(let i=0;i<53;i++) coping.push(new THREE.CylinderGeometry(.09,.093,.42,7,1).rotateX(Math.PI/2).translate(-w*.5+i*.15,2.97,.075));
  m.add(mesh(coping,M.roof),mesh([box(w+.18,.15,.39,0,2.91,.04)],M.roof));
  const plaques=board(b.text,b.w,b.h,[.86,1.54,.118],0,true);
  plaques.name='spring-outer-five-inscribed-slabs';m.add(plaques,board('',.57,.69,[-2.19,1.47,.12],0,true),board('',.71,.87,[-3.1,1.46,.12],0,true));
  const vines=[],leaves=[],rocks=[],paving=[];
  const r=i=>.5+.5*Math.sin(i*89.419+Math.cos(i*23.1));
  for(let i=0;i<18;i++){
    const x=-3.8+i*.45,a=.3+r(i)*1.12;
    vines.push(path([[x,3,.16],[x+Math.sin(i)*.22,2.64,.18],[x+.23,2.96-a,.20]],.013));
    for(let j=0;j<11;j++){
      const t=j/10,s=.044+r(i*13+j)*.06;
      leaves.push(new THREE.IcosahedronGeometry(s,0).scale(1.4,.81,.33).rotateZ(i*.57+j).translate(x+Math.sin(i+j*.8)*.23,2.99-a*t,.22+r(i+j)*.1));
    }
  }
  for(let i=0;i<20;i++){
    const q=r(i),s=.20+q*.43;
    rocks.push(new THREE.IcosahedronGeometry(s,i%3===0?1:0).scale(1.45,.51+r(i+6)*.60,.85).rotateY(i*.97).translate(-3.86+i*.405,s*.29,.35+.27*r(i+3)));
  }
  for(let i=0;i<23;i++)for(let j=0;j<15;j++){
    const x=-4.2+i*.383+(j%2)*.15,z=.64+j*.31,h=.009+r(i*19+j)*.005;
    paving.push(place(.263,h,.123,x,h*.38,z,(i+j)%2?Math.PI/4:-Math.PI/4));
  }
  m.add(mesh(rocks,stone('#99968c')),mesh(paving,stone('#918d84')),mesh(leaves,lit('#39513b',{emissive:'#152014',ei:.42})),mesh(vines,M.beam));
  const l=new THREE.PointLight(0xffdfbc,8.1,7,1.65);l.position.set(-.45,2.45,2.70);m.add(l);
  m.position.set(b.x,Y,b.z);m.rotation.y=-Math.PI/2;root.add(m);
  return {light:l,level:l.intensity};
}
