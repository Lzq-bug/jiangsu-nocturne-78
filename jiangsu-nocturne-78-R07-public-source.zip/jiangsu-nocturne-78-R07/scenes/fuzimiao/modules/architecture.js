__def("src/architecture.js", function (__req) {
const THREE = __req("vendor/three.module.js");
const { mergeGeometries } = __req("vendor/addons/utils/BufferGeometryUtils.js");
const { M, chineseRoof, ridgeOrnament, pillarGeo, railingGeo, bracketGeo, plaqueMesh, box, mesh, rand, rr, glow, lit, PAL, registerOccluder } = __req("src/kit.js");
const { RIVER, STATIONS } = __req("src/data.js");
const T = __req("src/textures.js");

const Q = RIVER.quayY;          // quay deck height
const HW = RIVER.halfWidth;     // water half width

/** where the built structures actually are, filled in as they are built */
const LAYOUT = {};

/* ---------------------------------------------------------------- banks & quays */
function banks() {
  const parts = [], partsStone = [];
  for (const s of [-1, 1]) {
    const inner = HW * s;
    // retaining wall down to the water
    const wall = new THREE.BoxGeometry(1.6, Q + 1.4, RIVER.length);
    wall.translate(inner + s * 0.8, (Q + 1.4) / 2 - 1.0, 0);
    partsStone.push(wall);
    // coping stripe along the edge
    const cop = new THREE.BoxGeometry(0.7, 0.32, RIVER.length);
    cop.translate(inner + s * 1.55, Q + 0.16, 0);
    partsStone.push(cop);
    // promenade
    const ground = new THREE.BoxGeometry(60, 0.7, RIVER.length + 90);
    ground.translate(inner + s * 31.5, Q - 0.35, 0);
    parts.push(ground);
  }
  const g = new THREE.Group();
  const quay = mesh(partsStone, M.stone);
  quay.receiveShadow = true;
  const ground = mesh(parts, M.stoneDark);
  ground.receiveShadow = true;
  g.add(ground, quay);
  return g;
}

/** steps, bollards and lamp posts reaching the water on both sides */
function quayFurniture(anchors) {
  const g = new THREE.Group();
  const steps = [];
  const bollards = [];
  for (const s of [-1, 1]) {
    for (let z = -84; z <= 84; z += 12) {
      for (let k = 0; k < 4; k++) {
        steps.push(box(3.4, 0.5, 0.75, s * (HW + 0.4 - k * 0.7), Q - 0.55 - k * 0.55, z));
      }
      const b = new THREE.CylinderGeometry(0.22, 0.3, 1.1, 8);
      b.translate(s * (HW + 2.4), Q + 0.55, z + 4.5);
      bollards.push(b);
    }
    // pole lamps along the promenade
    for (let z = -88; z <= 88; z += 11) {
      const x = s * (HW + 4.6);
      const pole = new THREE.CylinderGeometry(0.09, 0.14, 4.4, 6);
      pole.translate(x, Q + 2.2, z);
      const arm = box(0.9, 0.12, 0.12, x - s * 0.45, Q + 4.35, z);
      const post = mesh([pole, arm], M.ink);
      g.add(registerOccluder(post, 2.6, new THREE.Vector3(x, Q + 2.2, z)));
      anchors.lampPosts.push(new THREE.Vector3(x, Q + 3.9, z));
    }
  }
  const sMesh = mesh(steps, M.stone); sMesh.receiveShadow = true;
  const bMesh = mesh(bollards, M.stoneDark); bMesh.castShadow = true;
  g.add(sMesh, bMesh);
  return g;
}

/* ---------------------------------------------------------------- 秦淮画廊 */
function gallery(anchors) {
  const g = new THREE.Group();
  const x0 = -HW - 5.5;          // waterside colonnade
  const x1 = -HW - 12.5;         // inner colonnade
  const zA = -74, zB = 74;
  LAYOUT.gallery = { x0, x1, zA, zB, deckY: Q + 0.45, eaveY: Q + 4.95, bay: (zB - zA) / Math.round((zB - zA) / 3.4) };
  const span = zB - zA, bays = Math.round(span / 3.4);

  const deck = mesh(box(Math.abs(x1 - x0) + 3.2, 0.55, span + 3.4, (x0 + x1) / 2, Q - 0.1, 0), M.stone);
  deck.receiveShadow = true;
  g.add(deck);

  const beamParts = [], bracketParts = [], latticeMeshes = [];
  const pillarSpots = [];
  for (let i = 0; i <= bays; i++) {
    const z = zA + (span * i) / bays;
    for (const x of [x0, x1]) {
      pillarSpots.push([x, Q + 0.2, z]);
      anchors.eaves.push(new THREE.Vector3(x + (x === x0 ? 0.7 : -0.7), Q + 4.3, z));
    }
    if (i < bays) {
      const zc = zA + (span * (i + 0.5)) / bays;
      const bay = span / bays;
      for (const x of [x0, x1]) beamParts.push(box(0.34, 0.55, bay, x, Q + 4.5, zc));
      beamParts.push(box(Math.abs(x1 - x0), 0.3, 0.34, (x0 + x1) / 2, Q + 4.62, z));
      for (const x of [x0, x1]) {
        const br = bracketGeo(0.9);
        br.translate(x, Q + 4.85, zc);
        bracketParts.push(br);
      }
    }
  }
  const pillars = new THREE.InstancedMesh(pillarGeo(4.6, 0.26), M.pillar, pillarSpots.length);
  const dum = new THREE.Object3D();
  pillarSpots.forEach(([x, y, z], i) => {
    dum.position.set(x, y, z);
    dum.updateMatrix();
    pillars.setMatrixAt(i, dum.matrix);
  });
  pillars.castShadow = true;
  pillars.frustumCulled = false;
  g.add(pillars);
  g.add(mesh(beamParts, M.beam));
  const brM = mesh(bracketParts, M.gilt);
  g.add(brM);

  //美人靠 railing on the river side
  const rail = new THREE.Mesh(railingGeo(span + 1, { height: 0.95, spacing: 1.4 }), M.pillarBright);
  rail.position.set(x0 + 1.1, Q + 0.4, 0);
  rail.rotation.y = Math.PI / 2;
  g.add(rail);
  const rail2 = new THREE.Mesh(railingGeo(span + 1, { height: 0.9, spacing: 1.7 }), M.stone);
  rail2.position.set(x1 - 1.0, Q + 0.4, 0);
  rail2.rotation.y = Math.PI / 2;
  g.add(rail2);

  // inner wall with lattice windows
  const wallParts = [];
  for (let i = 0; i < bays; i++) {
    const z = zA + (span * (i + 0.5)) / bays;
    if (i % 3 === 1) continue;
    wallParts.push(box(0.3, 3.3, span / bays - 0.9, x1 - 1.6, Q + 1.9, z));
  }
  const wall = mesh(wallParts, M.wall);
  wall.castShadow = wall.receiveShadow = true;
  g.add(wall);
  for (let i = 0; i < bays; i += 3) {
    const z = zA + (span * (i + 0.5)) / bays;
    const win = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 2.2), M.lattice);
    win.position.set(x1 - 1.44, Q + 2.0, z);
    win.rotation.y = Math.PI / 2;
    g.add(win);
    anchors.windowGlow.push(new THREE.Vector3(x1 - 1.4, Q + 2.0, z));
  }

  // double eave roof
  const lower = new THREE.Mesh(chineseRoof({
    width: span + 4, depth: Math.abs(x1 - x0) + 3.4, height: 1.5, ridgeRatio: 0.78,
    curve: 0.55, eaveLift: 0.35, overhang: 0.9, hip: true,
  }), M.roof);
  lower.rotation.y = Math.PI / 2;
  lower.position.set((x0 + x1) / 2, Q + 4.95, 0);
  lower.castShadow = true;
  const upper = new THREE.Mesh(chineseRoof({
    width: span - 8, depth: Math.abs(x1 - x0) - 3.4, height: 1.9, ridgeRatio: 0.86,
    curve: 0.5, eaveLift: 0.5, overhang: 0.5, hip: true,
  }), M.roof);
  upper.rotation.y = Math.PI / 2;
  upper.position.set((x0 + x1) / 2, Q + 6.2, 0);
  upper.castShadow = true;
  const ridge = mesh(ridgeOrnament({ width: span - 8, depth: 6, height: 1.9, ridgeRatio: 0.86 }), M.ridge);
  ridge.rotation.y = Math.PI / 2;
  ridge.position.set((x0 + x1) / 2, Q + 8.1, 0);
  g.add(lower, upper, ridge);

  // entrance gate of the gallery
  const gz = -22;
  const gate = mesh([
    box(0.9, 5.2, 0.9, x0 + 0.4, Q + 2.6, gz - 2.4),
    box(0.9, 5.2, 0.9, x0 + 0.4, Q + 2.6, gz + 2.4),
    box(0.7, 0.5, 5.6, x0 + 0.4, Q + 5.4, gz),
  ], M.pillarBright);
  gate.castShadow = true;
  g.add(gate);
  const sign = plaqueMesh('秦淮画廊', 4.4, 1.25, { dir: 'h', bg: '#173a2e' });
  sign.position.set(x0 + 0.85, Q + 5.95, gz);
  sign.rotation.y = Math.PI / 2;
  g.add(sign);
  anchors.gate.push(new THREE.Vector3(x0 + 0.9, Q + 6.6, gz));
  return g;
}

/* ---------------------------------------------------------------- 文德桥 */
function bridge(anchors) {
  const g = new THREE.Group();
  g.name = '文德桥 · 三孔';
  const z0 = -20, half = 2.7, span = 19;
  const deckY = x => Q + 0.55 + 4.05 * Math.max(0, 1 - (x / span) ** 2);
  const slots = [{x:-11.7,r:3.65,h:2.9},{x:0,r:7.65,h:5.25},{x:11.7,r:3.65,h:2.9}];
  const soffit = (slot,t) => [slot.x + slot.r * Math.cos(t), 0.63 + slot.h*Math.sin(t)];
  const shape = new THREE.Shape();
  shape.moveTo(-20, -.6);
  for (const slot of slots) {
    shape.lineTo(slot.x-slot.r,-.6);
    for (let j=0;j<=28;j++) { const [x,y] = soffit(slot,Math.PI*(1-j/28)); shape.lineTo(x,y); }
    shape.lineTo(slot.x+slot.r,-.6);
  }
  shape.lineTo(20,-.6);
  for (let i=60;i>=0;i--) {const x=-20+i*40/60;shape.lineTo(x,deckY(x)-.17);}
  shape.closePath();
  const solid = new THREE.ExtrudeGeometry(shape,{depth:half*2,bevelEnabled:false});
  solid.translate(0,0,z0-half);
  const body = new THREE.Mesh(solid,M.stoneDressed);
  body.castShadow=body.receiveShadow=true;g.add(body);
  const walk=[];
  for(let i=0;i<40;i++){
    const x=-20+i+.5;
    const part=box(1.02,.2,half*2+.1,x,deckY(x)-.04,z0);
    walk.push(part);
  }
  const walkMesh=mesh(walk,M.stone);walkMesh.receiveShadow=true;g.add(walkMesh);
  for(const side of [-1,1]){
    const z=z0+side*(half+.08), rails=[], carved=[];
    for(let i=0;i<=18;i++){
      const x=-18.9+i*2.1,y=deckY(x);
      rails.push(box(.22,.94,.29,x,y+.5,z),box(.32,.128,.31,x,y+.99,z));
      if(i===18)continue;
      const nx=x+2.1,mid=(x+nx)/2,yp=(y+deckY(nx))/2;
      for(const [h,lift,d] of [[.38,.34,.19],[.105,.78,.28],[.125,.12,.31]]){
        const q=new THREE.BoxGeometry(1.9,h,d);
        q.rotateZ(Math.atan2(deckY(nx)-y,nx-x));q.translate(mid,yp+lift,z);rails.push(q);
      }
      carved.push(box(1.41,.22,.045,mid,yp+.34,z+side*.109));
    }
    const white=lit('#d3cfbe',{rough:.76,emissive:'#22201f',ei:.38});
    g.add(mesh(rails,white),mesh(carved,M.stone));
    for(const slot of slots){
      const bevel=[];
      for(let j=0;j<21;j++){
        const a=Math.PI*(1-j/21),b=Math.PI*(1-(j+1)/21);
        const va=soffit(slot,a),vb=soffit(slot,b),seg=box(Math.hypot(vb[0]-va[0],vb[1]-va[1])*.96,.19,.16,0,0,0);
        seg.rotateZ(Math.atan2(vb[1]-va[1],vb[0]-va[0]));
        const theta=(a+b)/2;
        seg.translate((va[0]+vb[0])/2+.13*Math.cos(theta),(va[1]+vb[1])/2+.13*Math.sin(theta),z);
        bevel.push(seg);
      }
      g.add(mesh(bevel,M.stone));
    }
    const plaque=plaqueMesh('桥德文',2.4,.66,{dir:'h',bg:'#39362e',fg:'#eae4d7'});
    plaque.position.set(0,deckY(0)-.4,z+side*.08);plaque.rotation.y=side>0?0:Math.PI;g.add(plaque);
  }
  for(const x of [-19,19])for(const z of [z0-2.6,z0+2.6])anchors.bridgeLamps.push(new THREE.Vector3(x,deckY(x)+.95,z));
  for(const slot of slots)for(let i=1;i<=5;i++){const [x,y]=soffit(slot,Math.PI*i/6);anchors.archLamps.push(new THREE.Vector3(x,y-.25,z0-2));}
  return g;
}

/* ---------------------------------------------------------------- 夫子庙 */
function temple(anchors) {
  const g = new THREE.Group();
  const cx = 58;

  // silled platform
  const plat = mesh(box(24, 2.6, 30, cx, Q + 1.3, 0), M.stone);
  plat.castShadow = plat.receiveShadow = true;
  g.add(plat);
  // 前侧石栏留出与正阶同宽的中缝。
  for(const sign of [-1,1]){
    const r=new THREE.Mesh(railingGeo(9.1,{height:1.0,spacing:1.5}),M.stone);
    r.position.set(cx-11.64,Q+2.6,sign*10.0);r.rotation.y=Math.PI/2;g.add(r);
  }
  const backRail=new THREE.Mesh(railingGeo(28,{height:1.1,spacing:1.5}),M.stone);
  backRail.position.set(cx+11.6,Q+2.6,0);backRail.rotation.y=Math.PI/2;g.add(backRail);
  // central stairs with 御路
  const stairParts = [];
  for (let k = 0; k < 7; k++) stairParts.push(box(.8, .42, 10.6, cx - 12 - 0.4 - k * .70, Q + 2.5 - k * .42, 0));
  const stair = mesh(stairParts, M.stone);
  stair.receiveShadow = true;
  g.add(stair);
  const ramp = mesh(box(5.15, .19, 1.78, cx - 15, Q + 1.44, 0), M.stoneDark);
  ramp.rotation.z = 0.51;
  g.add(ramp);

  // 院中像为低细节的铜色轮廓示意，不复制实拍/实物纹样。
  const figureZ=0,figureX=41.75;
  const bronze=lit('#65513a',{rough:.63,metal:.26,emissive:'#39240e',ei:.62});
  const stone=mesh([box(1.96,.45,2.20,figureX,Q+.225,figureZ),box(1.44,.53,1.53,figureX,Q+.64,figureZ)],M.stoneDark);g.add(stone);
  const coat=new THREE.Mesh(new THREE.CylinderGeometry(.49,.64,2.3,9),bronze);
  coat.scale.set(.66,1,1);coat.position.set(figureX,Q+2.03,figureZ);g.add(coat);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.34,10,8),bronze);
  head.scale.set(.77,1.19,.91);head.position.set(figureX-.035,Q+3.43,figureZ);g.add(head);
  const cap=new THREE.Mesh(new THREE.CylinderGeometry(.279,.321,.24,8),bronze);
  cap.position.set(figureX,Q+3.78,figureZ);g.add(cap);
  const hands=new THREE.Mesh(new THREE.SphereGeometry(.29,10,7),bronze);
  hands.scale.set(.98,.81,1.64);hands.position.set(figureX-.42,Q+2.83,figureZ);g.add(hands);
  // hall body
  const wallH = 6.0, wy = Q + 2.6;
  LAYOUT.temple = { x0: cx - 5.7, x1: cx + 9.7, halfZ: 9.6, floorY: wy, ceilY: wy + wallH, axisZ: 0, doorX: cx - 6.1 };
  const shell = mesh([
    box(0.5, wallH, 20, cx + 10, wy + wallH / 2, 0),
    box(16, wallH, 0.5, cx + 2, wy + wallH / 2, -9.9),
    box(16, wallH, 0.5, cx + 2, wy + wallH / 2, 9.9),
    box(0.5, wallH, 20, cx - 6, wy + wallH / 2, 0),
  ], M.redWall);
  shell.castShadow = shell.receiveShadow = true;
  g.add(shell);

  // colonnade on the front (riverside) face
  const cols = [];
  for (let i = 0; i <= 6; i++) {
    const z = -9 + (18 * i) / 6;
    const c = new THREE.Mesh(pillarGeo(wallH + 0.6, 0.34), M.pillarBright);
    c.position.set(cx - 7.4, wy, z);
    c.castShadow = true;
    g.add(c);
    cols.push(z);
    anchors.templeLamps.push(new THREE.Vector3(cx - 7.6, wy + wallH - 0.4, z));
  }
  const archi = mesh(box(0.6, 0.6, 19, cx - 7.4, wy + wallH + 0.2, 0), M.beam);
  g.add(archi);

  // lattice doors
  for (let i = 0; i < 6; i++) {
    const z = -9 + (18 * (i + 0.5)) / 6;
    const w = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 3.6), M.lattice);
    w.position.set(cx - 5.9, wy + 1.9, z);
    w.rotation.y = Math.PI / 2;
    g.add(w);
    anchors.templeWindows.push(new THREE.Vector3(cx - 6.2, wy + 2.2, z));
  }

  // double-eave hip roof, upper and lower
  const lower = new THREE.Mesh(chineseRoof({
    width: 24, depth: 19, height: 3.0, ridgeRatio: 0.46, curve: 0.62, eaveLift: 0.62, overhang: 1.4, segU: 30, segV: 20,
  }), M.roofGreen);
  lower.rotation.y = Math.PI / 2;
  lower.position.set(cx + 2, wy + wallH + 0.5, 0);
  lower.castShadow = true;
  const upper = new THREE.Mesh(chineseRoof({
    width: 17, depth: 12, height: 3.2, ridgeRatio: 0.4, curve: 0.6, eaveLift: 0.75, overhang: 1.1, segU: 26, segV: 18,
  }), M.roofGreen);
  upper.rotation.y = Math.PI / 2;
  upper.position.set(cx + 2, wy + wallH + 3.6, 0);
  upper.castShadow = true;
  const ridge = mesh(ridgeOrnament({ width: 17, depth: 12, height: 3.2, ridgeRatio: 0.4, overhang: 1.1 }), M.gilt);
  ridge.rotation.y = Math.PI / 2;
  ridge.position.copy(upper.position);
  g.add(lower, upper, ridge);

  const sign = plaqueMesh('大成殿', 6.4, 1.8, { dir: 'h', bg: '#123057', fg: '#f5e2b4' });
  sign.position.set(cx - 7.84, wy + wallH - 0.33, 0);
  sign.rotation.y = -Math.PI / 2;
  g.add(sign);
  anchors.dian.sign = sign.position;

  // side wings / 廊
  for (const s of [-1, 1]) {
    const wing = mesh([
      box(12, 3.4, 0.5, cx - 12, Q + 2.6 + 1.7, s * 14),
      box(0.5, 3.4, 6, cx - 6, Q + 2.6 + 1.7, s * 12),
    ], M.wall);
    wing.castShadow = true;
    g.add(wing);
    const wr = new THREE.Mesh(chineseRoof({
      width: 13, depth: 5, height: 1.4, ridgeRatio: 0.9, curve: 0.5, eaveLift: 0.3, overhang: 0.8,
    }), M.roof);
    wr.position.set(cx - 12, Q + 6.1, s * 14);
    wr.rotation.y = Math.PI / 2;
    g.add(wr);
    for (let i = 0; i < 4; i++) anchors.courtyardLamps.push(new THREE.Vector3(cx - 12 + rr(-5, 5), Q + 4.6, s * (10 + i * 1.4)));
  }
  return g;
}

/* ---------------------------------------------------------------- 天下文枢坊 & 照壁 */
function paifang(anchors) {
  const g=new THREE.Group();g.name='天下文枢坊 · 北岸';
  const cx=29.1;
  for(const z of [-9.35,-4.15,4.15,9.35]){
    const c=new THREE.Mesh(pillarGeo(Math.abs(z)<5?6.95:5.85,.46),M.pillarBright);
    c.position.set(cx,Q+.19,z);c.castShadow=true;g.add(c,mesh(box(1.3,.61,1.22,cx,Q+.29,z),M.stone));
  }
  const paint=lit('#294e56',{rough:.73,emissive:'#15292d',ei:.8});
  for(const [z,w,h] of [[0,8.65,7.1],[-6.75,5.42,5.86],[6.75,5.42,5.86]]){
    const carving=[box(.8,.56,w,cx,Q+h-.21,z),box(.92,.16,w+.17,cx,Q+h+.08,z)];
    for(let j=-3;j<=3;j++){
      const zz=z+j*w/8;
      carving.push(box(.93,.42,.23,cx,Q+h+.33,zz),box(1.26,.15,.35,cx,Q+h+.55,zz));
    }
    g.add(mesh(carving,paint));
    const roof=new THREE.Mesh(chineseRoof({width:w+1.78,depth:3.2,height:1.10,ridgeRatio:.65,curve:.66,eaveLift:.61,overhang:.4,hip:true}),M.roof);
    roof.rotation.y=Math.PI/2;roof.position.set(cx,Q+h+.59,z);roof.castShadow=true;g.add(roof);
    const crest=mesh(ridgeOrnament({width:w+1.78,depth:3.2,height:1.10,ridgeRatio:.65,overhang:.4}),M.ridge);
    crest.rotation.y=Math.PI/2;crest.position.copy(roof.position);g.add(crest);
  }
  for(const facing of [-1,1]){
    const sign=plaqueMesh('天下文枢',4.8,1.19,{dir:'h',bg:'#123057',fg:'#e9ca87'});
    sign.position.set(cx+facing*.62,Q+6.25,0);sign.rotation.y=facing*Math.PI/2;g.add(sign);
  }
  for(const z of [-3.15,3.15])anchors.paifangLamps.push(new THREE.Vector3(cx,Q+4.6,z));
  return g;
}

function dragonRelief(g,x,z,y){
  const gold=lit('#a77932',{rough:.71,metal:.2,emissive:'#58330d',ei:.85});
  const scale=2.10;
  for(const dir of [-1,1]){
    const coord=(u,v,d=0)=>new THREE.Vector3(x+d,y+v*scale,z+dir*u*scale);
    const pts=[[1.5,.48],[2.1,.68],[2.97,.7],[3.63,.22],[4.2,-.21],[5.04,-.22],[5.8,.1],[6.04,.4],[6.76,.57],[7.22,.15],[7.89,-.32],[8.59,-.37],[9.29,-.1],[9.61,.27]].map(([u,v])=>coord(u,v));
    const spine=new THREE.CatmullRomCurve3(pts);
    const strand=new THREE.Mesh(new THREE.TubeGeometry(spine,54,.125,6,false),gold);g.add(strand);
    const flakes=new THREE.InstancedMesh(new THREE.SphereGeometry(.127,7,5),gold,58);
    const m=new THREE.Matrix4();
    for(let i=0;i<58;i++){const q=spine.getPoint(i/57);m.makeTranslation(q.x+.095,q.y+.055*Math.sin(i*2),q.z);flakes.setMatrixAt(i,m);}
    g.add(flakes);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.44,14,8),gold);
    head.scale.set(.40,.78,1.36);head.position.copy(coord(1.33,.52,.12));g.add(head);
    const underbelly=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p,i)=>new THREE.Vector3(p.x+.06,p.y-.18*Math.sin(Math.PI*i/(pts.length-1)),p.z))),54,.052,5,false),gold);g.add(underbelly);
    const eye=new THREE.Mesh(new THREE.SphereGeometry(.064,8,6),lit('#ffce66',{rough:.57,emissive:'#98691b',ei:1.15}));eye.position.copy(coord(1.22,.60,.45));g.add(eye);
    for(let j=0;j<10;j++){
      const t=j/9;
      const crown=new THREE.CatmullRomCurve3([coord(1.43+t*.8,.60,.06),coord(1.51+t*.8,.74+t*.08,.07),coord(1.63+t*.8,.66+t*.1,.05)]);
      g.add(new THREE.Mesh(new THREE.TubeGeometry(crown,4,.043,4,false),gold));
    }
    for(const pts of [[[1.37,.62],[.94,.70],[.78,.57]],[[1.25,.51],[.91,.49],[.77,.55]],[[1.46,.65],[1.65,.96],[1.91,.93]],[[3.55,.29],[3.63,.62],[3.33,.73]],[[4.60,-.17],[4.73,-.49],[4.48,-.55]],[[6.69,.45],[6.82,.80],[7.11,.85]],[[8.03,-.32],[8.22,-.58],[8.57,-.60]]]){
      const c=new THREE.CatmullRomCurve3(pts.map(([u,v])=>coord(u,v,.1)));
      g.add(new THREE.Mesh(new THREE.TubeGeometry(c,9,.052,4,false),gold));
    }
  }
  const pearl=new THREE.Mesh(new THREE.SphereGeometry(.37,13,8),gold);pearl.scale.x=.35;pearl.position.set(x+.15,y+1.48,z);g.add(pearl);
}

function southScreen(anchors){
  const g=new THREE.Group();g.name='大照壁 · 南岸双龙';
  const x=-18.95,z=22,len=69;
  const clay=lit('#8c332b',{rough:.9,emissive:'#4c1a13',ei:.5});
  g.add(mesh([box(1.32,4.8,len,x,Q+2.4,z),box(1.8,.60,len+.25,x,Q+.28,z),box(1.86,.32,len+.33,x,Q+4.8,z)],clay));
  const top=new THREE.Mesh(chineseRoof({width:len+1.6,depth:2.5,height:.91,ridgeRatio:.94,curve:.4,eaveLift:.39,overhang:.34}),M.roof);
  top.rotation.y=Math.PI/2;top.position.set(x,Q+4.88,z);g.add(top);
  dragonRelief(g,x+.74,z,Q+2.6);
  for(let i=-4;i<=4;i++)anchors.zhaobiLamps.push(new THREE.Vector3(x+.86,Q+.67,z+i*5.9));
  for(const dz of [-12,0,12]){
    const fill=new THREE.PointLight('#ffc18d',24,19,2);
    fill.position.set(x+4.9,Q+2.6,z+dz);g.add(fill);
  }
  return g;
}

function kuixing(anchors){
  const g=new THREE.Group();g.name='魁星阁 · 北岸六角剪影';
  const x=20.9,z=42.9;
  const cap=(radius,height,top,y,mat)=>{
    const m=new THREE.Mesh(new THREE.CylinderGeometry(top,radius,height,6,1),mat);
    m.position.set(x,y,z);m.rotation.y=Math.PI/6;g.add(m);
  };
  cap(3.8,.62,3.8,Q+.3,M.stone);
  const wood=lit('#75432e',{rough:.82,emissive:'#59311a',ei:.55});
  const roof=lit('#373b44',{rough:.93,emissive:'#7e4b20',ei:.25});
  for(let level=0;level<3;level++){
    const r=2.94-level*.29,b=Q+.55+level*2.48;
    cap(r,1.85,r,b+.93,wood);
    for(let k=0;k<6;k++){
      const t=Math.PI/6+k*Math.PI/3;
      const c=new THREE.Mesh(pillarGeo(1.9,.105),M.pillarBright);
      c.position.set(x+r*Math.cos(t),b,z+r*Math.sin(t));g.add(c);
    }
    cap(r+1.0,1.02,r-.52,b+2.04,roof);
    cap(r+1.04,.115,r+1.04,b+1.63,lit('#8e5935',{rough:.8,emissive:'#76340f',ei:.7}));
    for(let k=0;k<6;k++){
      const t=Math.PI/6+k*Math.PI/3,rad=r+.77;
      const ridge=new THREE.CatmullRomCurve3([new THREE.Vector3(x+rad*.72*Math.cos(t),b+1.80,z+rad*.72*Math.sin(t)),new THREE.Vector3(x+rad*Math.cos(t),b+1.65,z+rad*Math.sin(t)),new THREE.Vector3(x+(rad+.37)*Math.cos(t),b+1.93,z+(rad+.37)*Math.sin(t))]);
      g.add(new THREE.Mesh(new THREE.TubeGeometry(ridge,8,.067,5,false),M.ridge));
    }
    anchors.paifangLamps.push(new THREE.Vector3(x-2.05,b+1.5,z));
  }
  cap(.43,.92,.12,Q+8.95,M.ridge);
  return g;
}

/* ---------------------------------------------------------------- 江南贡院 */
function examinationHall(anchors) {
  const g = new THREE.Group();
  const cx = -52, cz = 46;
  LAYOUT.gongyuan = { cx, cz, hallX: cx - 12, cellsX0: cx - 22, cellsZ: cz };
  const gate = mesh([
    box(0.8, 6.2, 0.8, cx, Q + 3.1, cz - 5.4),
    box(0.8, 6.2, 0.8, cx, Q + 3.1, cz + 5.4),
    box(0.8, 4.6, 0.8, cx + 4.5, Q + 2.3, cz - 5.4),
    box(0.8, 4.6, 0.8, cx + 4.5, Q + 2.3, cz + 5.4),
    box(1.1, 0.7, 12.6, cx, Q + 6.5, cz),
    box(1.1, 0.6, 12.6, cx, Q + 4.1, cz),
  ], M.pillar);
  gate.castShadow = true;
  g.add(gate);
  for (const [y, w] of [[Q + 7.2, 14.4], [Q + 4.8, 12.6]]) {
    const r = new THREE.Mesh(chineseRoof({ width: w, depth: 3, height: 1.0, ridgeRatio: 0.5, curve: 0.55, eaveLift: 0.5, overhang: 0.4 }), M.roof);
    r.rotation.y = Math.PI / 2;
    r.position.set(cx, y, cz);
    r.castShadow = true;
    g.add(r);
  }
  const sign = plaqueMesh('江南贡院', 5.2, 1.5, { dir: 'h', bg: '#1a2f24', fg: '#eeddb0' });
  sign.position.set(cx - 0.7, Q + 5.4, cz);
  sign.rotation.y = -Math.PI / 2;
  g.add(sign);
  for (const dz of [-4.4, 4.4]) anchors.gongyuanLamps.push(new THREE.Vector3(cx - 0.9, Q + 4.6, cz + dz));

  // hall behind the gate
  const hall = mesh(box(13, 5.2, 17, cx - 12, Q + 2.6, cz), M.wall);
  hall.castShadow = hall.receiveShadow = true;
  g.add(hall);
  const hr = new THREE.Mesh(chineseRoof({ width: 20, depth: 16, height: 2.4, ridgeRatio: 0.5, curve: 0.6, eaveLift: 0.55, overhang: 1.2 }), M.roof);
  hr.rotation.y = Math.PI / 2;
  hr.position.set(cx - 12, Q + 5.4, cz);
  hr.castShadow = true;
  g.add(hr);
  for (let i = 0; i < 5; i++) {
    const w = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 2.6), M.lattice);
    w.position.set(cx - 5.4, Q + 2.9, cz - 7 + i * 3.5);
    g.add(w);
    anchors.gongyuanWindows.push(new THREE.Vector3(cx - 5.6, Q + 3.0, cz - 7 + i * 3.5));
  }

  // rows of 号舍, tiny cells receding into the dark
  const cells = [];
  for (let r = 0; r < 5; r++) {
    for (let i = 0; i < 14; i++) {
      const x = cx - 22 - r * 3.4, z = cz - 10.5 + i * 1.6;
      cells.push(box(2.6, 1.9, 1.4, x, Q + 0.95, z));
      const pr = new THREE.BoxGeometry(2.9, 0.7, 1.7);
      pr.rotateY(Math.PI / 4);
      pr.scale(1, 1, 0.6);
      pr.translate(x, Q + 2.2, z);
      cells.push(pr);
    }
  }
  const cm = mesh(cells, M.stoneDark);
  cm.castShadow = true;
  g.add(cm);
  anchors.gongyuanLamps.push(new THREE.Vector3(cx - 20, Q + 3.2, cz - 6), new THREE.Vector3(cx - 20, Q + 3.2, cz + 6));
  return g;
}

/* ---------------------------------------------------------------- 桃叶渡 */
function ferry(anchors) {
  const g = new THREE.Group();
  const cz = -84, x = -HW - 2.2;
  LAYOUT.ferry = { x: x - 4, z: cz };
  const pav = new THREE.Group();
  const posts = [];
  for (const [dx, dz] of [[-1.7, -1.7], [1.7, -1.7], [-1.7, 1.7], [1.7, 1.7]]) {
    const p = new THREE.Mesh(pillarGeo(3.6, 0.2), M.pillar);
    p.position.set(dx, Q + 0.4, dz);
    p.castShadow = true;
    posts.push(p);
  }
  pav.add(...posts);
  const roof = new THREE.Mesh(chineseRoof({ width: 5.2, depth: 5.2, height: 1.9, ridgeRatio: 0.16, curve: 0.55, eaveLift: 0.55, overhang: 0.7 }), M.roof);
  roof.position.set(0, Q + 4.0, 0);
  roof.castShadow = true;
  pav.add(roof);
  const fin = mesh([
    new THREE.ConeGeometry(0.28, 0.9, 8).translate(0, Q + 5.9, 0),
    box(0.16, 0.7, 0.16, 0, Q + 6.4, 0),
  ], M.gilt);
  pav.add(fin);
  const pl = plaqueMesh('桃叶渡', 1.05, 2.7, { dir: 'v', bg: '#2b1a3a', fg: '#f0d7a2' });
  pl.position.set(0, Q + 3.0, -1.85);
  pav.add(pl);
  pav.position.set(x - 4, 0, cz);
  g.add(pav);
  anchors.ferryLamps.push(new THREE.Vector3(x - 4, Q + 3.4, cz - 1.9), new THREE.Vector3(x - 4, Q + 3.6, cz + 1.6));

  // stone landing + mooring rings
  const land = mesh([
    box(5.4, 0.5, 12, x - 1.2, Q - 0.1, cz),
    box(4.2, 0.4, 3.2, x + 1.4, Q - 0.7, cz + 3),
    box(4.2, 0.4, 3.2, x + 1.4, Q - 1.1, cz - 3),
  ], M.stone);
  land.receiveShadow = true;
  g.add(land);
  const stele = mesh([box(1.1, 2.6, 0.3, x - 3.4, Q + 1.3, cz + 6.4), box(1.7, 0.5, 0.7, x - 3.4, Q + 2.7, cz + 6.4)], M.stone);
  g.add(stele);
  return g;
}

/* ---------------------------------------------------------------- assembly */
function buildQuarter(scene) {
  const anchors = {
    eaves: [], lampPosts: [], windowGlow: [], bridgeLamps: [], archLamps: [],
    templeLamps: [], templeWindows: [], courtyardLamps: [], paifangLamps: [],
    zhaobiLamps: [], gongyuanLamps: [], gongyuanWindows: [], ferryLamps: [],
    shopLamps: [], stringEnds: [], gate: [], dian: {},
  };
  const group = new THREE.Group();
  group.name = 'quarter';
  group.add(banks());
  group.add(quayFurniture(anchors));
  group.add(gallery(anchors));
  group.add(bridge(anchors));
  group.add(temple(anchors));
  group.add(paifang(anchors), southScreen(anchors), kuixing(anchors));
  const exam=examinationHall(anchors);
  exam.scale.x=-1;exam.name='江南贡院 · 北岸';
  const gy=LAYOUT.gongyuan;
  for(const k of ['cx','hallX','cellsX0'])gy[k]*=-1;
  for(const a of [...anchors.gongyuanLamps,...anchors.gongyuanWindows])a.x*=-1;
  group.add(exam);
  group.add(ferry(anchors));

  // pavilions and shops dotting both banks
  const walls = [], roofs = [];
  for (let i = 0; i < 9; i++) {
    const s = i % 2 ? 1 : -1;
    const z = -70 + i * 16 + rr(-4, 4);
    const x = s * (HW + rr(9, 15));
    if (Math.abs(z) < 8 && s < 0) continue;
    const w = rr(4, 6), d = rr(3.5, 5.5), h = rr(2.8, 3.8);
    walls.push(box(w, h, d, x, Q + h / 2, z));
    const rg = chineseRoof({ width: w + 1.4, depth: d + 1.4, height: 1.1, ridgeRatio: 0.45, curve: 0.55, eaveLift: 0.45, overhang: 0.3 });
    if (rand() > 0.5) rg.rotateY(Math.PI / 2);
    rg.translate(x, Q + h + 0.1, z);
    roofs.push(rg);
    anchors.shopLamps.push(new THREE.Vector3(x, Q + h * 0.8, z + d / 2));
  }
  const shopRoofs = mesh(roofs, M.roof);
  const shopWalls = mesh(walls, M.wall);
  shopRoofs.castShadow = shopWalls.castShadow = true;
  group.add(shopRoofs, shopWalls);

  // river-edge banner poles with silk streamers
  const silkParts = [];
  const near = (z) => STATIONS.some((st) => Math.abs(st.pos[2] - z) < 9);
  for (let z = -66; z <= 78; z += 13) {
    if (rand() > 0.72 || near(z)) continue;
    const x = HW + 3.4;
    silkParts.push(box(0.12, 3.6, 0.12, x, Q + 1.8, z));
    const flag = new THREE.PlaneGeometry(1.1, 1.9);
    flag.translate(x - 0.6, Q + 3.1, z);
    silkParts.push(flag);
  }
  const flags = new THREE.Mesh(mergeGeometries(silkParts), M.silk);
  group.add(flags);

  scene.add(group);

  // overhead light strings across the water, endpoints on the two lamp-post lines
  for (let z = -66; z <= 66; z += 22) {
    if (z >= -23 && z <= 45) continue;
    anchors.stringEnds.push([
      new THREE.Vector3(-HW - 4.6, Q + 4.4, z - 5),
      new THREE.Vector3(HW + 4.6, Q + 4.6, z + 5),
    ]);
  }
  return { group, anchors, silkFlags: flags };
}




return { T, LAYOUT, buildQuarter };
});
