/**
 * This native panorama arrived in the repo as the deployed standalone HTML.
 * Recompose its five locally authored registry modules without rebundling
 * engine/vendor/UI chunks. Use the baseline deployed scene as the template when
 * rebuilding from an earlier checkout; current deployed HTML works as well.
 *   node scenes/fuzimiao/tools/build-release.mjs [template] [output]
 */
import { readFileSync, writeFileSync, renameSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const canonical = fileURLToPath(new URL('../../../public/pano/fuzimiao.html', import.meta.url));
const [template = canonical, output = canonical] = process.argv.slice(2).map(p => resolve(p));
let html = readFileSync(template, 'utf8');
for (const name of ['data', 'architecture', 'interiors', 'props', 'water']) {
  const pattern = new RegExp(`^__def\\("src/${name}\\.js", function \\(__req\\) \\{\\n[\\s\\S]*?(?=^__def\\()`, 'gm');
  const parts = [...html.matchAll(pattern)];
  if (parts.length !== 1) throw new Error(`Expected one template module src/${name}.js, got ${parts.length}`);
  const i = parts[0].index;
  const module = readFileSync(new URL(`../modules/${name}.js`, import.meta.url), 'utf8');
  if (!module.startsWith(`__def("src/${name}.js", function (__req) {\n`) || !module.trimEnd().endsWith('});')) {
    throw new Error(`Invalid local module src/${name}.js`);
  }
  html = html.slice(0, i) + module.trimEnd() + '\n\n' + html.slice(i + parts[0][0].length);
}
const temp = `${output}.build-${process.pid}`;
try { writeFileSync(temp, html, { flag: 'wx' }); renameSync(temp, output); }
finally { rmSync(temp, { force: true }); }
