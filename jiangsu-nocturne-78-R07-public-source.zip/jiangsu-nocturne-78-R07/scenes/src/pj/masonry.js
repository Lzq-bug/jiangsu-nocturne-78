import * as THREE from 'three';
import { RIVER, ALLEYS } from './data.js';

// Two instances batches (flags and revetment), entirely procedural.
export function buildMasonry(ferries, notch, materials) {
  const { halfWidth: river, quayY: y, length } = RIVER;
  const root = new THREE.Group();
  let seed = 193922;
  const rnd = () => ((seed = (Math.imul(1664525, seed) + 1013904223) >>> 0) / 4294967296);
  const dummy = new THREE.Object3D();
  const matrix = new THREE.Color();
  const rows = { flag: [], wall: [], cap: [] };
  function stone(kind, x, y, z, w, h, d, light, angle = 0) {
    rows[kind].push([x,y,z,w,h,d,light,angle]);
  }
  for (const side of [-1,1]) {
    for (const [z0,z1] of ferries.map((z,i) => [(ferries[i-1] ?? -length / 2 - notch) + notch,z-notch]).concat([[ferries.at(-1)+notch,length/2]])) {
      if (z1 <= z0) continue;
      for (let level=0; level<5; level++) {
        for(let z=z0; z<z1-.05; ) {
          const d=Math.min(z1-z,.47+rnd()*.96);
          const wet=level<2;
          stone('wall',side*(river+.08+rnd()*.052), y-.145-(level+.5)*.36, z+d*.5, .36, .328+rnd()*.024, Math.max(.02,d-.02), (wet?.52:.69)+rnd()*(wet?.19:.25));
          z+=d;
        }
      }
      for(let z=z0; z<z1-.05;) {
        const d=Math.min(z1-z,.75+rnd()*.62);
        stone('cap',side*(river+.55), y-.061,z+d*.5,1.12,.22,d-.02,.81+rnd()*.17);
        z+=d;
      }
    }
  }
  const bed = (x0,x1,z0,z1,dy) => {
    for(let x=x0, i=0; x<x1-.05;i++) {
      const lane=Math.min(x1-x,(i%3===1?.66:.49)+rnd()*.22);
      for(let z=z0; z<z1-.05;) {
        const d=Math.min(z1-z,.64+rnd()*.8);
        stone('flag',x+lane*.5,y+dy+(rnd()-.5)*.02,z+d*.5, lane-.022,.079,d-.024,.71+rnd()*.29, (rnd()-.5)*.018);
        z+=d;
      }
      x+=lane;
    }
  };
  bed(-river-6.44,-river-1.44,-99,99,0.028);
  bed(river+1.39,river+5.43,-95,95,0.028);
  for (const alley of ALLEYS) bed(river+5.42,river+1.6+alley.depth-.1,alley.z-alley.width*.5,alley.z+alley.width*.5,.151);
  const cube = new THREE.BoxGeometry();
  for (const [kind, stamps] of Object.entries(rows)) {
    const mesh = new THREE.InstancedMesh(cube, materials[kind], stamps.length);
    stamps.forEach(([x,y,z,w,h,d,f,a],i)=>{
      dummy.position.set(x,y,z);
      dummy.rotation.set(0,a,0);
      dummy.scale.set(Math.max(.01,w),Math.max(.01,h),Math.max(.01,d));
      dummy.updateMatrix();
      mesh.setMatrixAt(i,dummy.matrix);
      mesh.setColorAt(i,matrix.setRGB(f,f*.98,f*.955));
    });
    mesh.name='平江·'+kind;
    mesh.receiveShadow=true;
    root.add(mesh);
  }
  return root;
}
