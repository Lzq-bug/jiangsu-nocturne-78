import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { M, glow, mesh, box, plaqueMesh } from '../kit.js';
import { S, pavilion } from './parts.js';
import { LAKE } from './data.js';

const HALF = LAKE.bridge.halfSpan;
const WIDTH = LAKE.bridge.width;
export const BRIDGE = { halfSpan: HALF, width: WIDTH, arches: 15 };

/** Plateau beneath the five pavilions, with stone approaches. */
export function deckY(x) {
  const t = Math.min(1, Math.max(0, (Math.abs(x) - 10.9) / (HALF - 10.9)));
  return 2.35 + 3.55 * (1 - t);
}

/** 15 apertures across the straight through axis and 4 projecting wings.
 * The two paired side bearings are skewed from the main channel. */
export function archLayout() {
  const all = [{ cx: 0, z: 0, r: 3.565, top: 4.72, depth: WIDTH, yaw: 0, family: 'central', index: 0 }];
  for (const side of [-1, 1]) {
    all.push({ cx: side * 19.9, z: 0, r: 2.02, top: 1.95, depth: 6.45, yaw: 0, family: 'approach', index: all.length });
    for (const bank of [-1, 1]) for (let j = 0; j < 3; j++) {
      const yaw = side * bank * .42;
      const delta = (j - 1) * 2.05;
      all.push({ cx: side * 8.25 + delta * Math.cos(yaw), z: bank * 5.6 - delta * Math.sin(yaw),
        r: j === 1 ? .93 : .77, top: j === 1 ? 2.12 : 1.65, depth: 5.35, yaw, family: side === bank ? 'wing-a' : 'wing-b', index: all.length });
    }
  }
  return all;
}

function portalShape(left, right, floor, limit, apertures) {
  const shp = new THREE.Shape();
  shp.moveTo(left, floor);
  for (const { center, radius, top } of apertures) {
    shp.lineTo(center - radius, floor);
    const straight = Math.max(0, top - radius);
    shp.lineTo(center - radius, straight);
    for (let i = 1; i <= 30; i++) {
      const ang = Math.PI * (1 - i / 30);
      shp.lineTo(center + radius * Math.cos(ang), straight + (top - straight) * Math.sin(ang));
    }
    shp.lineTo(center + radius, floor);
  }
  shp.lineTo(right, floor);
  for (let i = 0; i <= 40; i++) {
    const x = right - (right - left) * i / 40;
    shp.lineTo(x, limit(x));
  }
  shp.closePath();
  return shp;
}

function solidPart(group, shape, depth, x, z, yaw) {
  const geo = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, curveSegments: 24 });
  geo.translate(0, 0, -depth / 2);
  geo.rotateY(yaw);
  geo.translate(x, 0, z);
  const m = new THREE.Mesh(geo, S.bridgeStone);
  m.castShadow = m.receiveShadow = true;
  group.add(m);
}

function buildArchFoundation(group, arches) {
  const central = arches[0];
  solidPart(group, portalShape(-4.95, 4.95, -.48, () => 6.23, [{ center: 0, radius: central.r, top: central.top }]), WIDTH, 0, 0, 0);
  for (const side of [-1, 1]) {
    // The core above the four wings is a cap over passages, not a wall closing their mouths.
    const deckBlock = new THREE.Shape();
    const xs = side < 0 ? [-17.0, -4.9] : [4.9, 17.0];
    deckBlock.moveTo(xs[0], 2.42); deckBlock.lineTo(xs[1], 2.42);
    deckBlock.lineTo(xs[1], deckY(xs[1]) + .31);
    deckBlock.lineTo(xs[0], deckY(xs[0]) + .31); deckBlock.closePath();
    solidPart(group, deckBlock, WIDTH * .69, 0, 0, 0);
    const pierX = side * 14.14;
    const transition = new THREE.Shape();
    transition.moveTo(pierX-2.85,-.39);
    transition.lineTo(pierX+2.85,-.39);
    transition.lineTo(pierX+2.85,deckY(pierX+2.85)+.29);
    transition.lineTo(pierX-2.85,deckY(pierX-2.85)+.29);
    transition.closePath();
    solidPart(group, transition, 6.46, 0, 0, 0);
    const aperture = arches.find(a => a.family === 'approach' && Math.sign(a.cx) === side);
    const ends = side < 0 ? [-HALF - .6, -16.92] : [16.92, HALF + .6];
    solidPart(group, portalShape(...ends, -.46, x => deckY(x) + .29, [{center: aperture.cx, radius: aperture.r, top: aperture.top}]), aperture.depth, 0, 0, 0);
    for (const bank of [-1, 1]) {
      const yaw = side * bank * .42;
      const opens = [-1, 0, 1].map(j => ({ center: j * 2.05, radius: j === 0 ? .93 : .77, top: j === 0 ? 2.12 : 1.65 }));
      solidPart(group, portalShape(-3.24, 3.24, -.52, () => 5.91, opens), 5.35, side * 8.25, bank * 5.6, yaw);
    }
  }
}

/** Segmented grey voussoirs, leaving thin unlit joints around every aperture. */
function archDress(group, arches) {
  const mats = [0x727977, 0x687073, 0x85877f, 0x697378].map(color => new THREE.MeshStandardMaterial({color, roughness:.93}));
  const parts = mats.map(() => []);
  for (const a of arches) for (const face of [-1,1]) {
    const spring = Math.max(0, a.top - a.r);
    const n = a.family === 'central' ? 23 : 11;
    const thick = a.family === 'central' ? .27 : .17;
    const point = (angle, width) => [Math.cos(angle)*(a.r+width), spring+Math.sin(angle)*(a.top-spring+width)];
    for (let j=0;j<n;j++) {
      const q0=Math.PI*(j+.011)/n,q1=Math.PI*(j+.989)/n;
      const shape=new THREE.Shape();
      shape.moveTo(...point(q0,0));
      shape.lineTo(...point((q0+q1)/2,0));
      shape.lineTo(...point(q1,0));
      shape.lineTo(...point(q1,thick));
      shape.lineTo(...point((q0+q1)/2,thick));
      shape.lineTo(...point(q0,thick));shape.closePath();
      const g=new THREE.ExtrudeGeometry(shape,{depth:.11,bevelEnabled:false});
      g.translate(0,0,face*a.depth/2-(face<0?.105:.005));g.rotateY(a.yaw);g.translate(a.cx,0,a.z);
      parts[(a.index+j*3+(face>0?1:0))%mats.length].push(g);
    }
  }
  parts.forEach((p,i)=>group.add(mesh(p,mats[i])));
}

/** 桥面铺石：跟着母线起拱，中间略鼓 */
function deckGeo() {
  const nx = 74, nz = 10;
  const pos = [], uv = [], idx = [];
  for (let j = 0; j <= nz; j++) {
    const twist = -1 + 2 * j / nz;
    for (let i = 0; i <= nx; i++) {
      const x = -HALF + (2 * HALF * i) / nx;
      const halfWidth = Math.abs(x) < 14 ? WIDTH / 2 : 3.24;
      const z = twist * halfWidth;
      const crown = 0.16 * Math.sin((j / nz) * Math.PI);
      pos.push(x, deckY(x) + 0.32 + crown, z);
      uv.push(x / 2.4, z / 2.4);
    }
  }
  for (let j = 0; j < nz; j++) {
    for (let i = 0; i < nx; i++) {
      const a = j * (nx + 1) + i, b = a + 1, c = a + nx + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

/** 两旁栏板与望柱，随桥面起伏 */
function railingSide(sign) {
  const parts = [];
  const n = 30;
  for (let i = 0; i <= n; i++) {
    const x = -HALF + (2 * HALF * i) / n;
    const y = deckY(x) + 0.34;
    const z = sign * (Math.abs(x) < 14 ? WIDTH / 2 - .35 : 2.95);
    const post = box(0.19, 1.02, 0.19, x, y + 0.51, z);
    parts.push(post);
    const cap = new THREE.CylinderGeometry(0.13, 0.15, 0.16, 8);
    cap.translate(x, y + 1.08, z);
    parts.push(cap);
    if (i < n) {
      const x2 = -HALF + (2 * HALF * (i + 1)) / n;
      const y2 = deckY(x2) + 0.34;
      const len = Math.hypot(x2 - x, y2 - y);
      const panel = new THREE.BoxGeometry(len, 0.5, 0.17);
      panel.rotateZ(Math.atan2(y2 - y, x2 - x));
      panel.translate((x + x2) / 2, (y + y2) / 2 + 0.3, z);
      parts.push(panel);
    }
  }
  return mergeGeometries(parts);
}

/** 短廊：把四隅亭与中亭连成一组，廊顶低于亭檐 */
function corridor(from, to) {
  const grp = new THREE.Group();
  const dir = new THREE.Vector3().subVectors(to, from);
  const len = dir.length();
  const a = Math.atan2(dir.z, dir.x);
  const yMid = (from.y + to.y) / 2 - 0.35;
  const beam = box(len, 0.18, 1.5, 0, 2.5, 0);
  grp.add(mesh(beam, M.stone));
  const roof = new THREE.Mesh(chineseRoofSlab(len, 2.0, 0.9), M.roof);
  roof.position.y = 2.66;
  roof.castShadow = true;
  grp.add(roof);
  const n = Math.max(2, Math.round(len / 2.4));
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    for (const s of [-1, 1]) {
      const px = -len / 2 + len * t;
      const pz = s * 0.9;
      grp.add(mesh(box(0.16, 2.5, 0.16, px, 1.25, pz), M.pillar));
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), glow('#ffbe72', 1.5));
      lamp.position.set(px, 2.06, pz);
      grp.add(lamp);
      grp.userData.lamps = grp.userData.lamps || [];
      grp.userData.lamps.push(new THREE.Vector3(px, 2.06, pz));
    }
  }
  grp.position.set((from.x + to.x) / 2, yMid, (from.z + to.z) / 2);
  grp.rotation.y = -a;
  return grp;
}

/** 廊顶：一条窄的庑殿面，直接由 chineseRoof 切一段 */
function chineseRoofSlab(len, depth, height) {
  const pos = [], uv = [], idx = [];
  const nu = 18, nv = 8;
  const hw = len / 2 + 0.3, hd = depth / 2 + 0.2;
  const rx = hw * 0.55;
  const dxs = Math.max(0.001, hw - rx);
  for (let j = 0; j <= nv; j++) {
    for (let i = 0; i <= nu; i++) {
      const x = -hw + (2 * hw * i) / nu;
      const z = -hd + (2 * hd * j) / nv;
      const dzN = Math.abs(z) / hd;
      const dxN = Math.max(0, Math.abs(x) - rx) / dxs;
      const t = Math.min(1, Math.max(dzN, dxN));
      const s = t * 0.42 + Math.sqrt(t) * 0.58;
      const y = height * (1 - s) + height * 0.2 * Math.pow(dzN, 4);
      pos.push(x, y, z);
      uv.push(x / 3.1, t * 1.4);
    }
  }
  for (let j = 0; j < nv; j++) {
    for (let i = 0; i < nu; i++) {
      const a = j * (nu + 1) + i, b = a + 1, c = a + nu + 1, d = c + 1;
      idx.push(a, c, b, b, c, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

export function buildFivePavilionBridge(scene, columns) {
  const group = new THREE.Group();
  group.name = 'wuting-bridge';
  const arches = archLayout();

  buildArchFoundation(group, arches);
  archDress(group, arches);
  const plate = mesh([box(21.25,.24,12.3,0,6.05,0)], M.stoneDressed);
  plate.receiveShadow=true;
  group.add(plate);
  group.userData.openingGroups = { central: 1, approach: 2, wingA: 6, wingB: 6, total: arches.length };
  group.userData.axes = [0, -.42, .42];
  const deck = new THREE.Mesh(deckGeo(), S.pavement);
  deck.receiveShadow = true;
  group.add(deck);
  const approachSteps = [];
  for(const side of [-1,1]) for(let i=0;i<21;i++){
    const x=side*(13.6+i*.65);
    approachSteps.push(box(.66,.115,6.18,x,deckY(x)+.435,0));
  }
  const stair = mesh(approachSteps,S.pavement);
  stair.receiveShadow=true;
  group.add(stair);
  group.add(new THREE.Mesh(railingSide(1), M.stone));
  group.add(new THREE.Mesh(railingSide(-1), M.stone));

  const anchors = { bridgeLamps: [], archLamps: [], eaves: [], lampPosts: [], windowGlow: [], stringEnds: [] };

  /* 五亭：中亭重檐八角，四隅单檐方亭 */
  const giltRoof = M.roof.clone();
  giltRoof.color.set('#b88b3d');
  giltRoof.emissive.set('#69440b');
  giltRoof.emissiveIntensity = .21;
  const apex = deckY(0) + 0.44;
  const center = pavilion({ sides: 8, radius: 3.05, pillarH: 3.7, roofH: 3.1, tiers: 2, plinth: 0.44, finialH: 1.24, roofMat: giltRoof });
  center.position.set(0, apex, 0);
  group.add(center);
  group.updateMatrixWorld(true);
  center.userData.lamps.forEach((p) => anchors.eaves.push(center.localToWorld(p.clone())));

  const plaque = plaqueMesh('五亭桥', 2.6, 0.92, { dir: 'h', bg: '#1b2f4d' });
  plaque.position.set(0, apex + 3.05, 3.3);
  group.add(plaque);
  const plaque2 = plaqueMesh('莲花桥', 2.6, 0.92, { dir: 'h', bg: '#3c1f1c' });
  plaque2.position.set(0, apex + 3.05, -3.3);
  plaque2.rotation.y = Math.PI;
  group.add(plaque2);

  const cornerSpots = [];
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) cornerSpots.push([sx * 8.3, sz * 5.25]);
  for (const [x, z] of cornerSpots) {
    const y = deckY(x) + 0.42;
    const pv = pavilion({ sides: 4, radius: 2.0, pillarH: 2.75, roofH: 1.95, tiers: 1, plinth: 0.42, finialH: 0.86, roofMat: giltRoof });
    pv.position.set(x, y, z);
    pv.rotation.y = Math.PI / 4;
    group.add(pv);
    group.updateMatrixWorld(true);
    pv.userData.lamps.forEach((p) => anchors.eaves.push(pv.localToWorld(p.clone())));
    // Small reflections preserve the otherwise dark canal
    columns.add(new THREE.Vector3(x, .10, z + Math.sign(z)*1.35), '#e2a162', .52, 5.0, .51);
  }

  for (const [x, z] of cornerSpots) {
    const from = new THREE.Vector3(x * 0.42, deckY(x * 0.42) + 0.5, z * 0.44);
    const to = new THREE.Vector3(x * 0.9, deckY(x * 0.9) + 0.5, z * 0.86);
    const c = corridor(from, to);
    group.add(c);
    group.updateMatrixWorld(true);
    (c.userData.lamps || []).forEach((p) => anchors.archLamps.push(c.localToWorld(p.clone())));
  }

  // Reflection accents come only from practical warm fixtures. The 2024
  // festival image is not the default or a claim about today's lighting.
  for (const a of arches.filter(a => a.family === 'central' || a.index%3===0)) {
    columns.add(new THREE.Vector3(a.cx, .10, a.z+2), '#e4a269', .52, 4.2, .43);
  }
  /* 桥头：抱鼓石 + 石灯 + 台阶 */
  for (const s of [-1, 1]) {
    for (const t of [-1, 1]) {
      const drum = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 9, 0, Math.PI), M.stoneDressed);
      drum.position.set(s * (HALF - 0.3), deckY(HALF - 0.3) + 0.75, t * (WIDTH / 2 - 0.5));
      drum.rotation.y = s > 0 ? -Math.PI / 2 : Math.PI / 2;
      group.add(drum);
    }
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 3.4, 8), M.stoneDark);
    post.position.set(s * (HALF + 2.4), 2.6, WIDTH / 2 - 1);
    group.add(post);
    const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.34, 10, 8), glow('#ffbe72', 1.9));
    lantern.position.set(s * (HALF + 2.4), 4.5, WIDTH / 2 - 1);
    group.add(lantern);
    anchors.lampPosts.push(new THREE.Vector3(s * (HALF + 2.4), 4.5, WIDTH / 2 - 1));
    const lantern2 = lantern.clone();
    lantern2.position.z = -WIDTH / 2 + 1;
    group.add(lantern2);
    anchors.lampPosts.push(new THREE.Vector3(s * (HALF + 2.4), 4.5, -WIDTH / 2 + 1));
  }

  scene.add(group);
  // Low-angle, off-body lamps: gentle marble bounce, not emissive outlines.
  // Kept outside the reflection clone so the lights don't occur twice.
  const pools = [[-9,3.5,12,0xc7d9ed,132,32],[8,5,-10,0xb7ccd8,106,29],[4,7.8,6.7,0xffc078,74,27]];
  for (const [x,y,z,color,power,reach] of pools) {
    const light = new THREE.PointLight(color,power,reach,2);
    light.position.set(x,y,z);
    scene.add(light);
  }
  const historic = [-1,1].map(side=>{
    const l = new THREE.PointLight(0x2a5de2,0,13,2);
    l.position.set(0,.8,side*4.9);
    scene.add(l);
    return l;
  });
  const setHistorical = (on) => {
    giltRoof.emissive.set(on?'#bb7d10':'#69440b');
    giltRoof.emissiveIntensity = on?.72:.21;
    for (const l of historic) l.intensity = on?42:0;
    group.userData.historicalLighting = on;
  };
  setHistorical(false);
  return { group, arches, anchors, deckY, setHistorical };
}
