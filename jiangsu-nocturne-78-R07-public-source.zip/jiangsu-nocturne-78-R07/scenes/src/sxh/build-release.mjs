/** Publish only shouxihu.html, with the same calibration and mode guard as
 * the full collection. A candidate path keeps the authoritative bundle untouched. */
import {mkdtemp,copyFile,readdir,rename,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const dir = join(root, 'public/pano');
const target = process.argv[2] ? resolve(process.argv[2]) : join(dir, 'shouxihu.html');
const scratch = await mkdtemp(join(tmpdir(), 'shouxihu-build-'));
const asset = join(scratch, 'shouxihu.html');
const run = (...args) => execFileSync(process.execPath,args,{cwd:root,stdio:'inherit'});
try {
 const names = (await readdir(dir)).filter(name=>name.endsWith('.html') && name!=='shouxihu.html');
 await Promise.all(names.map(name=>copyFile(join(dir,name),join(scratch,name))));
 run(join(root,'scenes/tools/build-single.mjs'),'sxh.html','src/sxh/main.js',asset);
 run(join(root,'scenes/tools/refine-native-panorama-look.mjs'),scratch);
 run(join(root,'scenes/tools/guard-native-panorama-mode.mjs'),scratch);
 await copyFile(asset,target+'.temp');
 await rename(target+'.temp',target);
} finally {
 await rm(scratch,{recursive:true,force:true});
 await rm(target+'.temp',{force:true});
}
