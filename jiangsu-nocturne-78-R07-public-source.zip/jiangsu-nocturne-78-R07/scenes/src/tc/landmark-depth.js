import * as THREE from 'three';
import { box, mesh, lit, glow } from '../kit.js';

function volume(w,d,h,x,z,y=0) {
  return box(w,h,d,x,y+h*.5,z);
}

export function purplePeak({ x,z }) {
  const g=new THREE.Group();g.name='zifeng-depth-layer';
  const glass=[],edges=[],floors=[],litWindows=[],crown=[];
  const add=(arr,...p)=>arr.push(volume(...p));
  // City tower is distant from the historic wall and the temple. The shape
  // uses its asymmetrical setbacks, separate crown volume and slim antenna,
  // not a modern tower mapped onto the pagoda silhouette.
  add(glass,77,59,231,x,z,0);add(glass,67,54,106,x+2,z-1,231);
  add(glass,46,46,51,x+6,z+1,337);add(glass,27,31,31,x+8,z,388);
  add(edges,1.1,1.1,9,x+11,z+5,419);
  add(crown,3.1,3.1,35,x+11,z+5,415);
  for(const v of [[76,58,230,x,z,0],[66,53,106,x+2,z-1,231],[45,45,51,x+6,z+1,337],[26,30,30,x+8,z,388]]){
    const [w,d,h,cx,cz,y]=v;
    for(let i=0;i<Math.floor(h/4.6);i++){
      const by=y+i*4.6;
      if(i%4===0) add(floors,w+.13,d+.14,.33,cx,cz,by+.12);
      for(let j=0;j<11;j++){
        const hash=Math.abs(Math.sin(i*71.79+j*17.79+x*1.63+y*.1)*12964.89)%1;
        if(hash<.83)continue;
        const px=cx+(j/10-.5)*w*.88;
        add(litWindows,2.7,.15,2.06,px,cz-d*.5-.14,by+.62);
        if((i+j)%4===1)add(litWindows,.15,2.4,2.04,cx+w*.5+.18,cz+(j/10-.5)*d*.83,by+.62);
      }
    }
  }
  for(let i=0;i<7;i++)if(i!==3)add(crown,25-i*.19,30,.43,x+8,z,390+i*3.42);
  g.add(mesh(glass,lit('#324350',{rough:.64,metal:.26,emissive:'#152336',ei:.61})));
  g.add(mesh(floors,lit('#4a5256',{rough:.85,emissive:'#17212c',ei:.55})));
  if(edges.length)g.add(mesh(edges,lit('#57636c',{rough:.6})));
  g.add(mesh(litWindows,glow('#f0b66c',.83)),mesh(crown,glow('#c8b090',.55)));
  return g;
}
