import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { initMaterials, declutter } from '../kit.js';
import { initTCMaterials } from './surfaces.js';
import { buildSky, MOON_DIR } from './sky.js';
import { buildWall } from './wall.js';
import { buildLake, buildShore } from './lake.js';
import { buildCity } from './city.js';
import { buildProps } from './props.js';
import { LightColumns, Reflections } from '../water.js';
import { Hotspots } from '../hotspots.js';
import { CameraRig } from '../controls.js';
import { createUI } from '../ui.js';
import { STATIONS, DEFAULTS } from './data.js';

const canvas = document.getElementById('stage');
// rAF is frozen in a background tab, so each build step also has a timer fallback
const nextFrame = () => new Promise((r) => {
  let done = false;
  const go = () => { if (!done) { done = true; r(); } };
  requestAnimationFrame(go);
  setTimeout(go, 60);
});

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, 1, .12, 2400);

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(1024, 1024), 0.55, 0.55, 1.02);
composer.addPass(bloom);
composer.addPass(new OutputPass());

const rig = new CameraRig(camera, canvas);
// 共享 rig 的平移范围是按秦淮河谷的尺寸写死的，这条长卷有 690 米，就地放宽
rig.nudge = (moveX, moveY) => {
  const k = rig.fov / 2400;
  const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
  const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
  rig.pos.addScaledVector(right, -moveX * k).addScaledVector(up, moveY * k);
  rig.pos.x = THREE.MathUtils.clamp(rig.pos.x, -330, 330);
  rig.pos.y = THREE.MathUtils.clamp(rig.pos.y, 1.6, 72);
  rig.pos.z = THREE.MathUtils.clamp(rig.pos.z, -320, 120);
};
let ui, env, wall, lake, shore, city, props, columns, reflections, hotspots;
let stationIndex = 0;
let wantShot = false;
let qualityLevel = 0;
let tourClock = 0;
const state = { lantern: 1, ripple: 1, boat: 1, crowd: 90, bloom: 0.55, reflect: true, labels: true, tour: false, autoQuality: true };

/* ------------------------------------------------------------------ sizing */
function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
  composer.setSize(w, h);
  bloom.setSize(w, h);
}
window.addEventListener('resize', resize);

/* ------------------------------------------------------------------ stations */
function goToStation(i, { info = true, animate = true } = {}) {
  stationIndex = (i + STATIONS.length) % STATIONS.length;
  const s = STATIONS[stationIndex];
  if (rig.mode === 'pano') {
    rig.goTo(s.pos,s.look,{animate,seconds:1.8});
    if(animate && rig.travel) rig.travel.toFov=s.fov??58; else rig.setFov(s.fov??58);
  }
  else rig.goToOrbit(s.pos, s.look, { animate, seconds: 1.5 });
  ui.setActive(s.id);
  hotspots.setCurrent(s.id);
  if (info) ui.showInfo(s);
}

function setMode(m) {
  rig.mode = m;
  rig.travel = null;
  const s = STATIONS[stationIndex];
  if (m === 'free') rig.goToOrbit(s.pos, s.look, { animate: false });
  else {rig.goTo(s.pos,s.look,{animate:false});rig.setFov(s.fov??58);}
  ui.setMode(m);
}

/* ------------------------------------------------------------------ params */
function onParam(key, value) {
  switch (key) {
    case 'lantern': {
      state.lantern = value;
      for (const l of wall.lampLights) l.intensity = l.userData.base * value;
      for (const l of env.lights) l.intensity = l.userData.base * value;
      city.templeLight.intensity = 210 * value;
      props.setLantern(value);
      break;
    }
    case 'crowd': state.crowd = value; break;
    case 'ripple': state.ripple = value; break;
    case 'boat': state.boat = value; break;
    case 'bloom': state.bloom = value; bloom.strength = value; break;
    case 'reflect': state.reflect = value; reflections.enabled = value; break;
    case 'labels': state.labels = value; hotspots.labelsVisible = value; break;
    case 'tour': state.tour = value; rig.autoRotate = value; tourClock = value ? 8 : 0; break;
    case 'autoQuality': state.autoQuality = value; if (!value) ui.perfHint(''); break;
    default: break;
  }
}

/* ------------------------------------------------------------------ quality ladder */
const DPR = Math.min(window.devicePixelRatio || 1, 1.35);
function applyQuality(level) {
  qualityLevel = level;
  renderer.setPixelRatio(level >= 1 ? 1 : DPR);
  reflections.enabled = state.reflect && level < 2;
  const notes = [
    '',
    '已自动降低渲染分辨率以保持流畅。',
    '并已关闭水中倒影；如需更高画质可手动调低城上灯火。',
  ];
  ui.perfHint(notes[level] || '');
}

function crowdTarget() {
  const cap = [190, 140, 96][Math.min(2, qualityLevel)];
  return Math.min(state.crowd, cap);
}

/* ------------------------------------------------------------------ loop */
const clock = new THREE.Clock();
let frames = 0, fpsAcc = 0, lowStreak = 0;

function frame() {
  const dt = Math.min(0.05, clock.getDelta());
  const t = clock.elapsedTime;

  rig.update(dt);
  env.update(t);
  lake.update(t, state.ripple);
  props.update(t, dt, state.autoQuality ? crowdTarget() : state.crowd, state.boat);
  columns.update(t, state.ripple, 1.4 + 0.8 * Math.min(1.4, state.lantern));
  if (reflections.enabled) reflections.update(t, state.ripple);
  hotspots.update(camera, t, { width: window.innerWidth, height: window.innerHeight });
  declutter(camera.position);

  if (state.tour) {
    tourClock += dt;
    if (tourClock > 9 && !rig.travel) { tourClock = 0; goToStation(stationIndex + 1); }
  }
  ui.setCompass(THREE.MathUtils.radToDeg(rig.yaw));

  composer.render();
  if (wantShot) { capture(); wantShot = false; }

  frames++; fpsAcc += dt;
  if (fpsAcc > 0.75) {
    const fps = Math.round(frames / fpsAcc);
    ui.setFps(fps, fps < 30);
    frames = 0; fpsAcc = 0;
    if (state.autoQuality && t > 5) {
      if (fps < 20) lowStreak++; else lowStreak = Math.max(0, lowStreak - 2);
      if (lowStreak >= 8 && qualityLevel < 2) { applyQuality(qualityLevel + 1); lowStreak = 0; }
    }
  }
  requestAnimationFrame(frame);
}

function capture() {
  const s = STATIONS[stationIndex];
  try {
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `台城明城墙-${s.short}.png`;
    a.click();
  } catch (e) { /* canvas may be tainted in unusual setups */ }
}

/* ------------------------------------------------------------------ boot */
async function boot() {
  ui = createUI({
    stations: STATIONS,
    defaults: DEFAULTS,
    onChange: onParam,
    onSelect: (s) => goToStation(STATIONS.indexOf(s)),
    onMode: setMode,
    onTour: (v) => onParam('tour', v),
    onShot: () => { wantShot = true; },
    onReset: () => { goToStation(stationIndex, { info: false }); rig.setFov(rig.mode === 'pano' ? STATIONS[stationIndex].fov??60 : 54); },
    onStep: (d) => goToStation(stationIndex + d),
  });
  ui.loading(0.05, '烧制城砖…');

  resize();
  initMaterials();
  initTCMaterials();
  await nextFrame();

  ui.loading(0.22, '升起湖上的月…');
  env = buildSky(scene);
  for (const l of env.lights) l.userData.base = l.intensity;
  await nextFrame();

  ui.loading(0.42, '沿山势砌起城墙…');
  wall = buildWall(scene);
  await nextFrame();

  ui.loading(0.6, '点亮城上灯火…');
  columns = new LightColumns(scene);
  columns.mesh.renderOrder = 4;
  lake = buildLake(scene, MOON_DIR);
  shore = buildShore(scene, columns);
  city = buildCity(scene, columns);
  await nextFrame();

  ui.loading(0.78, '放下一湖春水…');
  props = buildProps(scene, columns);
  reflections = new Reflections(scene);
  reflections.add(wall.group);
  reflections.add(shore.group);
  reflections.add(city.group);
  await nextFrame();

  ui.loading(0.9, '安顿灯影与归人…');
  hotspots = new Hotspots(scene, STATIONS, {
    onPick: (s) => goToStation(STATIONS.indexOf(s)),
  });
  hotspots.labelsVisible = true;
  // #station=<id> 直接落到某处机位，#bare 去掉界面元素：截图与自检用
  const bare = /bare/.test(location.hash);
  if (bare) document.body.classList.add('bare');
  const deep = (location.hash.match(/station=([\w-]+)/) || [])[1];
  stationIndex = Math.max(0, STATIONS.findIndex((s) => s.id === deep));
  // #eye=x,y,z&at=x,y,z&fov= 覆盖机位，试构图用
  const eye = (location.hash.match(/eye=([-\d.,]+)/) || [])[1];
  const at = (location.hash.match(/at=([-\d.,]+)/) || [])[1];
  const fov = Number((location.hash.match(/fov=([\d.]+)/) || [])[1]) || STATIONS[stationIndex].fov || 60;
  const pose = eye && at ? { pos: eye.split(',').map(Number), look: at.split(',').map(Number) } : STATIONS[stationIndex];
  rig.goTo(pose.pos, pose.look, { animate: false });
  rig.setFov(fov);
  ui.setActive(STATIONS[stationIndex].id);
  ui.showInfo(STATIONS[stationIndex]);
  setTimeout(() => ui.hideInfo(), 15000);
  hotspots.setCurrent(STATIONS[stationIndex].id);
  if (bare) hotspots.exteriorShown = false;
  renderer.setPixelRatio(DPR);
  composer.setPixelRatio(DPR);
  await nextFrame();

  // one warm-up render so shaders compile before the curtain lifts
  composer.render();
  renderer.shadowMap.needsUpdate = true;
  composer.render();
  renderer.shadowMap.autoUpdate = false;

  ui.loading(1, '湖山入城…');
  await new Promise((r) => setTimeout(r, 260));
  ui.loaded();
  window.taicheng = { scene, camera, renderer, composer, rig, bloom, STATIONS, goToStation, setMode, THREE };
  requestAnimationFrame(frame);
}

function bindTap() {
  rig.onTap = ({ x, y }) => {
    const ndc = new THREE.Vector2((x / window.innerWidth) * 2 - 1, -(y / window.innerHeight) * 2 + 1);
    const hit = hotspots.pick(ndc, camera);
    if (hit) goToStation(STATIONS.indexOf(hit));
  };
}

boot().then(bindTap).catch((err) => {
  console.error(err);
  const l = document.getElementById('loader');
  if (l) l.querySelector('p').textContent = `场景加载失败：${err.message}`;
});
