import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { M, boxGeo, chineseRoof, lit } from './kit.js';
import * as textures from './textures.js';

/**
 * Protected Bao Mansion core only. Archival entry 12 describes a right-angle pair of
 * wall doors, front hall opposite ancillary rooms, then a wall door and two-storey hall
 * with a narrow skywell. Layout is schematic in the compressed town, not surveyed.
 */
export function addBaoCore(parent, deck) {
  const root=new T.Group();root.name='anfeng-bao-protected-core';root.position.y=deck;parent.add(root);
  const lightOak=lit('#9e6955',{map:textures.wood('#6c4639','#51403a'),rough:.86,emissive:'#24120d',ei:.07});
  const hong=lit('#9b5e4b',{rough:.87,emissive:'#29201a',ei:.12});
  const gray=lit('#8f8980',{map:textures.stone('#73706d'),rough:.98});
  const lime=lit('#ada79a',{map:textures.plaster('#999287'),rough:.97});
  const floor=lit('#8c8a87',{rough:.94});
  const weatherTile=lit('#7c7972',{map:textures.stone('#747570'),rough:.95});
  const tileEdge=lit('#817565',{rough:.95});
  const darkWood=lit('#53423b',{rough:.88,emissive:'#251b14',ei:.41});
  const patina=lit('#6a665f',{rough:.94});
  const x=-55.15;
  const pending=new Map();
  function buffer(target,material,g){
    let mats=pending.get(target);if(!mats){mats=new Map();pending.set(target,mats);}
    let geos=mats.get(material);if(!geos){geos=[];mats.set(material,geos);}
    geos.push(g);
  }
  const cube=(s,m,w,h,d,X,Y,Z)=>buffer(s,m,boxGeo(w,h,d,X,Y,Z));
  const split=(s,mat,X,Z,span,open,H,head,L=.32)=>{
    const w=(span-open)*.50;
    for(const d of [-1,1])cube(s,mat,w,H,L,X+d*(open+w)*.5,H*.5,Z);
    cube(s,mat,open,H-head,L,X,head+(H-head)*.5,Z);
  };
  function endTiles(s,x,z,width,depth,y){
    for(const row of [-1,1])for(let i=0;i<Math.floor(width/.19);i++){
      const dx=(i+.5)*.19-width*.5;
      const tile=new T.CylinderGeometry(.079,.079,.22,8);
      tile.rotateX(Math.PI*.5);tile.translate(x+dx,y+.043,z+row*(depth*.5+.04));buffer(s,i%5===0?tileEdge:weatherTile,tile);
    }
  }
  function roof(s,x,z,w,d,y,h){
    const g=chineseRoof({width:w,depth:d,height:h,ridgeRatio:.86,curve:.58,eaveLift:.12,overhang:.08,hip:false,segU:24,segV:16});
    g.translate(x,y,z); buffer(s,M.roofDark,g);
    cube(s,weatherTile,w*.94,.139,.17,x,y+h*.96,z);
    endTiles(s,x,z,w,d,y);
    for(const side of [-1,1]){
      cube(s,darkWood,w*.98,.147,.13,x,y-.07,z+side*d*.5);
      for(let i=0;i<Math.floor(w/.195);i++)cube(s,darkWood,.055,.08,.29,x-w*.5+.12+i*.195,y-.109,z+side*(d*.5-.08));
    }
  }
  function steppedEnd(s,X,Z,D){
    for(let i=0;i<3;i++){
      const length=D-i*1.15,H=4.0+i*.47;
      cube(s,lime,.39,.48,length,X,H,Z);
      cube(s,weatherTile,.58,.096,length+.43,X,H+.239,Z);
    }
  }
  const group=(name)=>{
    const g=new T.Group();g.name='anfeng-bao-'+name;root.add(g);return g;
  };
  const passage=group('right-angle-wall-door');
  const first=group('first-hall'), store=group('opposing-ancillary-rooms');
  const wallGate=group('between-halls-wall-door');
  const sky=group('skywell-open-to-sky'), upstairs=group('second-storeyed-hall');

  // A blind end makes the interior wall door a true ninety-degree turn off the existing street door.
  cube(passage,gray,.34,3.35,3.62,-57.4,1.675,-22.3);
  cube(passage,lime,.40,.22,3.84,-57.4,3.37,-22.3);
  split(passage,gray,x,-24.30,8.1,1.77,3.33,2.38);
  cube(passage,gray,2.12,.124,.45,x,2.43,-24.13);
  cube(passage,weatherTile,2.37,.13,.55,x,2.61,-24.14);
  cube(passage,patina,1.8,.132,.43,x,.114,-24.3);

  // The first hall faces a shallower service row; floor material changes below roofed sections.
  cube(store,gray,2.97,2.8,.27,x-2.89,1.40,-24.56);
  cube(store,gray,2.99,2.8,.27,x+2.89,1.40,-24.56);
  for(const s of [-1,1]){
    const c=x+s*2.87;
    cube(store,lime,2.89,2.7,.25,c,1.35,-23.0);
    cube(store,lightOak,1.20,1.37,.105,c,1.52,-24.74);
    for(let i=0;i<8;i++)cube(store,darkWood,.047,1.35,.064,c-.52+.147*i,1.52,-24.81);
    roof(store,c,-23.92,3.18,2.46,2.87,.59);
  }
  function lands(s,Z,W,D){
    cube(s,M.flag,W,.08,D,x,.055,Z);
    for(let iz=0;iz<Math.ceil(D/.49);iz++)for(let ix=0;ix<Math.ceil(W/.62);ix++){
      const zz=Z-D*.5+.30+iz*.49,xx=x-W*.5+.32+ix*.62;
      if (zz>Z+D*.5-.10||xx>x+W*.5-.15)continue;
      const shift=.014*Math.sin(iz*73+ix*7);
      cube(s,(iz+ix*7)%9===0?patina:floor,.594,.035,.464,xx,.102+shift,zz);
    }
  }
  lands(passage,-22.0,7.40,4.57);
  lands(passage,-26.35,7.72,3.90);
  lands(first,-30.42,7.71,4.65);
  lands(sky,-34.78,6.84,3.7);
  lands(upstairs,-38,7.54,4.60);
  function hall(s,Z,D,capped){
    const W=7.85,H=capped?5.18:3.54,Y=Z+D/2;
    for(const side of [-1,1]){
      const X=x+side*W*.5;
      cube(s,lime,.33,H,D,X,H*.5,Z);
      cube(s,gray,.41,.43,D,X,.215,Z);
      steppedEnd(s,X,Z,D);
    }
    for(const f of [-1,1]){
      const Zf=Z+f*D*.5;
      for(const X of [-3.72,-1.35,1.35,3.72]){
        cube(s,gray,.35,.19,.41,x+X,.137,Zf);
        cube(s,hong,.158,H-.18,.165,x+X,(H+.16)*.5,Zf);
      }
      cube(s,hong,W-.22,.26,.23,x,H-.39,Zf);
      cube(s,hong,W-.15,.21,.24,x,2.52,Zf);
      for(const side of [-1,1]){
        const X=x+side*2.51,w=2.16;
        cube(s,gray,w,.32,.24,X,.205,Zf);
        cube(s,darkWood,w,.86,.064,X,.91,Zf);
        cube(s,hong,w,.11,.15,X,1.38,Zf);
        for(let i=0;i<11;i++)cube(s,lightOak,.051,1.07,.085,X-w*.48+i*.207,1.96,Zf);
        for(let i=0;i<4;i++)cube(s,lightOak,w,.051,.085,X,1.60+i*.266,Zf);
      }
      if(capped){
        cube(s,darkWood,W-.48,.18,.24,x,2.88,Zf);
        for(let i=0;i<4;i++)cube(s,hong,.14,1.68,.19,x+(i-1.5)*2.27,3.98,Zf);
        for(const side of [-1,1]){
          const X=x+side*2.51;
          cube(s,darkWood,2.20,.69,.105,X,3.41,Zf);
          for(let i=0;i<13;i++)cube(s,lightOak,.049,.79,.088,X-1.06+i*.175,4.15,Zf);
          for(let i=0;i<4;i++)cube(s,hong,2.17,.041,.122,X,3.81+i*.205,Zf);
        }
        cube(s,gray,2.12,1.56,.19,x,3.91,Zf-f*.14);
        cube(s,hong,W-.37,.123,.23,x,4.74,Zf);
      }
    }
    if(capped){
      cube(s,darkWood,W-.27,.19,D,x,3.01,Z);
      // One transverse moon-beam: rising in the center, set behind the courtyard elevation.
      const p=[];
      for(let i=0;i<=18;i++){
        const u=i/18;p.push(new T.Vector3(x-3.57+u*7.14,3.23+.51*Math.sin(Math.PI*u),Z+.20));
      }
      const tube=new T.TubeGeometry(new T.CatmullRomCurve3(p),32,.117,8,false);buffer(s,lightOak,tube);
      cube(s,gray,7.83,2.15,.18,x,1.24,Y-D+.34);
    }
    roof(s,x,Z,W+.59,D+.45,H,.77+(capped?.27:0));
    for (const p of [-D*.27,D*.27]) cube(s,darkWood,W-.3,.13,.16,x,H-.20,Z+p);
  }
  hall(first,-30.48,4.18,false);
  hall(upstairs,-38.67,4.82,true);

  // Wall door between the halls. The true opening leads into a short dry slot with visible night sky.
  split(wallGate,gray,x,-32.90,8.18,1.92,3.03,2.43,.30);
  cube(wallGate,lime,2.17,.16,.32,x,2.51,-32.69);
  cube(wallGate,weatherTile,8.26,.12,.52,x,3.092,-32.89);
  cube(wallGate,patina,2.04,.16,.56,x,.14,-32.80);
  for(const s of [-1,1]){
    cube(sky,lime,.35,4.34,3.71,x+s*3.57,2.17,-34.72);
    cube(sky,gray,.40,.41,3.69,x+s*3.55,.31,-34.72);
    cube(sky,weatherTile,.56,.15,3.83,x+s*3.57,4.37,-34.72);
    cube(sky,gray,.19,.088,3.61,x+s*3.19,.13,-34.72);
    cube(sky,M.stoneDark,.126,.02,3.61,x+s*3.13,.185,-34.72);
  }
  // No night programme or exact historic lamps claimed. Warm fill only within these rooms.
  for(const [X,Y,Z,power,radius,color] of [[x,2.38,-22.4,4.25,5.1,'#e5c9a4'],[x-.85,2.36,-26.76,4.8,6.2,'#e0b892'],[x+1.22,2.3,-33.95,4.15,5.5,'#ebc29a'],[x-.24,2.56,-34.59,4.9,5.7,'#ecd2a9']]){
    const l=new T.PointLight(color,power,radius,2);l.position.set(X,Y,Z);root.add(l);
  }
  for(const [s,ma] of pending)for(const [m,geos] of ma)for(const indexed of [false,true]){
    const subset=geos.filter(g=>(g.index!==null)===indexed);
    if(subset.length===0)continue;
    const g=mergeGeometries(subset,false);subset.forEach(g=>g.dispose());
    if(!g)throw new Error('Bao mansion geometry merge failed');
    const result=new T.Mesh(g,m);result.receiveShadow=true;s.add(result);
  }
  return root;
}
