import * as THREE from 'three';
import { meterBox } from './kit.js';
import { BANK } from './data.js';

const ink = Math.PI;
const box = meterBox;

// Body follows local X. Shape Y is elevation; extrusion extends only across local Z.
export function buildHeritageBridge(b) {
  const {span,width,clearSpan,rise}=b;
  const beam=b.type==='beam', half=span/2, r=clearSpan/2;
  const spring=.21, crown=b.id==='jili'?3.57:2.78;
  const body=[], rail=[], trim=[], relief=[], tops=[];
  const deckAt=(x)=>{
    const d=Math.abs(x), eased=Math.max(0,1-d/half);
    if(beam) return BANK+.03+rise*Math.min(1,(half-d)/(half-r-.17));
    return BANK+.035+rise*Math.pow(eased,.79);
  };
  const stepCount=beam?17:b.id==='jili'?31:23;
  const sh=new THREE.Shape();
  sh.moveTo(-half,-1.65);
  for(let i=0;i<=stepCount;i++) {
    const x=-half+i*span/stepCount; sh.lineTo(x,deckAt(x)-.20);
  }
  sh.lineTo(half,-1.65);
  sh.closePath();
  const clear=new THREE.Path();
  clear.moveTo(-r,-1.55);clear.lineTo(-r,spring);
  if(beam){
    clear.lineTo(-r,deckAt(0)-.32);clear.lineTo(r,deckAt(0)-.32);clear.lineTo(r,spring);
  }else for(let i=1;i<=34;i++){
    const t=ink*(1-i/34);
    clear.lineTo(Math.cos(t)*r,spring+Math.sin(t)*(crown-spring));
  }
  clear.lineTo(r,-1.55);clear.closePath();sh.holes.push(clear);
  const solid=new THREE.ExtrudeGeometry(sh,{depth:width,bevelEnabled:false});
  solid.translate(0,0,-width*.5);body.push(solid);

  // Stepped treads, understated slab parapets and dressed coping.
  const run=span/stepCount;
  for(let t=0;t<stepCount;t++){
    const x=-half+(t+.5)*run,y=deckAt(x);
    body.push(box(run+.027,.235,width+.04,x,y-.22,0));
    for (const side of [-1,1]){
      const z=side*(width*.5-.073);
      const lean=Math.atan2(deckAt(x+run*.5)-deckAt(x-run*.5),run);
      const apron=new THREE.BoxGeometry(run+.013,.44,.15);
      apron.rotateZ(lean);apron.translate(x,y+.205,z);rail.push(apron);
      const cap=new THREE.BoxGeometry(run+.026,.076,.205);
      cap.rotateZ(lean);cap.translate(x,y+.438,z);trim.push(cap);
    }
  }
  for(const s of [-1,1])for(const side of [-1,1]){
    const x=s*(half-.19),y=deckAt(x),z=side*(width*.5-.073);
    rail.push(box(.24,.62,.185,x,y,z),box(.29,.09,.23,x,y+.59,z));
    tops.push([x,y+.78,z]);
  }
  for(const z of [-width*.5-.032,width*.5+.032]){
    if(beam) {
      trim.push(box(clearSpan+.6,.16,.09,0,deckAt(0)-.23,z));
    } else {
      const n=b.id==='jili'?21:17;
      for(let i=0;i<n;i++){
        const a=(i+.033)*ink/n, q=(i+.967)*ink/n;
        const dr=.205+(i%3)*.016, dy=.222+(i%4)*.009;
        const profile=new THREE.Shape();
        profile.moveTo(Math.cos(a)*r,spring+Math.sin(a)*(crown-spring));
        profile.lineTo(Math.cos(q)*r,spring+Math.sin(q)*(crown-spring));
        profile.lineTo(Math.cos(q)*(r+dr),spring+Math.sin(q)*(crown-spring+dy));
        profile.lineTo(Math.cos(a)*(r+dr),spring+Math.sin(a)*(crown-spring+dy));
        profile.closePath();
        const voussoir=new THREE.ExtrudeGeometry(profile,{depth:.095,bevelEnabled:false});
        voussoir.translate(0,0,z-.0475);trim.push(voussoir);
      }
    }
  }
  // Low-relief silhouette incised into the projecting carved keystone, not a freestanding fish.
  if(b.id==='changqing') for(const side of [-1,1]){
    const fish=new THREE.Shape(),y=crown+.19;
    fish.moveTo(-.147,-.034);fish.quadraticCurveTo(-.025,.096,.112,.042);
    fish.quadraticCurveTo(.17,-.003,.096,-.034);fish.quadraticCurveTo(-.041,-.078,-.12,-.034);
    fish.lineTo(-.207,-.091);fish.lineTo(-.186,.044);fish.closePath();
    const carving=new THREE.ExtrudeGeometry(fish,{depth:.029,bevelEnabled:false});
    carving.rotateX(-.09); if(side<0)carving.rotateY(ink);
    carving.translate(0,y,side*(width*.5+.096));relief.push(carving);
  }
  return {body,rail,trim,relief,tops,deckAt};
}
