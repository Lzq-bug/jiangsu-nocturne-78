import * as THREE from 'three';
import { CANAL, BRIDGE, LANE } from './data.js';
import { M, mesh, box, loft, roundedSection, rand, rr } from './kit.js';

/**
 * 文亨桥, the far bank and the city behind it — the layer that frames the lane.
 * The bridge closes the north end of the vista, old roofs line the far bank, and
 * new towers stand behind them, so one night holds two ages in it.
 *
 * The arches are sized from the water: each ring springs just above the summer
 * waterline and its crown sits 1.5 m under the deck, so the hump of the bridge
 * follows from the arches instead of being painted on.
 */
export function buildSkyline(scene) {
  const g = new THREE.Group();
  g.name = 'skyline';

  const stone = [], dark = [], roofs = [], litPanels = [], wood = [], foliage = [], lampHeads = [];
  const B = (list, w, h, d, x, yBottom, z) => list.push(box(w, h, d, x, yBottom, z));
  const bridgeLamps = [];

  /* 1987 relocated bridge, E–W above the tributary (not the Grand
     Canal). Trace the three arch mouths in the solid outline itself. */
  const bridge=new THREE.Group();bridge.name='Wenheng Bridge / tributary crossing';
  g.add(bridge);
  const W=BRIDGE.width,H=BRIDGE.length/2,Z=BRIDGE.z,X=BRIDGE.x;
  const r=BRIDGE.centre,s=BRIDGE.side,d=r+BRIDGE.pier+s;
  const arch=[[-d,s],[0,r],[d,s]];
  const depthY=(u)=>BRIDGE.approachY+(BRIDGE.crownY-BRIDGE.approachY)
     * Math.max(0,1-Math.abs(u)/H) ** .88;
  const ringY=(u,rad)=>BRIDGE.springY + Math.sqrt(Math.max(0,rad*rad-u*u))*.96;
  const outline=new THREE.Shape();outline.moveTo(-H,-1.2);
  for(const [x,rad] of arch){
    outline.lineTo(x-rad,-1.2);outline.lineTo(x-rad,BRIDGE.springY);
    for(let i=0;i<=42;i++){
      const uu=-rad+rad*2*i/42;outline.lineTo(x+uu,ringY(uu,rad));
    }
    outline.lineTo(x+rad,-1.2);
  }
  outline.lineTo(H,-1.2);
  for(let i=0;i<=120;i++){
    const u=H-H*2*i/120;outline.lineTo(u,depthY(u)-.12);
  }
  outline.closePath();
  const bodyGeo=new THREE.ExtrudeGeometry(outline,{depth:W,bevelEnabled:false});
  bodyGeo.translate(X,0,Z-W/2);
  const stoneBody=M.stone.clone();stoneBody.color.set('#8a8880');stoneBody.roughness=.91;
  const stonePale=M.stone.clone();stonePale.color.set('#a7a59a');
  const masonry=new THREE.Mesh(bodyGeo,stoneBody);masonry.name='joined granite arches';bridge.add(masonry);
  const rims=[],seams=[],rail=[],inside=[],planks=[],orn=[];
  const sillZ=[Z-W/2,Z+W/2];
  for(const side of [-1,1]){
    const zz=Z+side*(W*.5+.035);
    for(const [x,rad] of arch){
      const n=rad>4?23:13;
      for(let i=0;i<n;i++){
        const aa=i*Math.PI/n+.007,bb=(i+1)*Math.PI/n-.007;
        const coord=(q,rr)=>new THREE.Vector2(Math.cos(q)*rr,BRIDGE.springY+Math.sin(q)*rr*.96);
        const face=new THREE.Shape([coord(aa,rad),coord(aa,rad+.29),coord(bb,rad+.29),coord(bb,rad)]);
        const g0=new THREE.ExtrudeGeometry(face,{depth:.19,bevelEnabled:false});
        g0.translate(X+x,0,zz+(side>0?-.075:-.114));
        rims.push(g0);
      }
      for(const w of [-1,1]){
        B(orn,.37,.31,.36,X+x+w*(rad+.55),BRIDGE.springY+rad*.49,zz+side*.10);
        B(orn,.23,.17,.29,X+x+w*(rad+.56),BRIDGE.springY+rad*.49-.055,zz+side*.29);
      }
    }
    for(let i=0;i<24;i++){
      const a=-H+i*2*H/24,b=-H+(i+1)*2*H/24;
      const y=(depthY(a)+depthY(b))*.5, dx=b-a,dy=depthY(b)-depthY(a);
      const length=Math.hypot(dx,dy);
      B(rail,.23,1.06,.24,X+a,y-.09,Z+side*(W*.48));
      B(rail,.34,.17,.31,X+a,depthY(a)+.95,Z+side*(W*.48));
      const t=box(length+.045,.16,.23);
      t.translate(0,-.08,0).rotateZ(Math.atan2(dy,dx)).translate(X+(a+b)*.5,y+.88,Z+side*W*.48);
      rail.push(t);
      const p=box(length+.02,.49,.115);
      p.translate(0,-.24,0).rotateZ(Math.atan2(dy,dx)).translate(X+(a+b)*.5,y+.34,Z+side*W*.478);
      rail.push(p);
      B(rail,.18,.11,.14,X+(a+b)*.5,y+.66,Z+side*W*.478);
    }
    for(let k=1;k<=14;k++){
      const y=k*.43;
      for(let j=0;j<37;j++){
        const u=-18.9+j*1.05+(k%2)*.53;
        if(Math.abs(u)>H-.2||y>depthY(u)-.18||arch.some(([xx,rr])=>Math.abs(u-xx)<rr&&y<ringY(u-xx,rr)+.23))continue;
        B(seams,.95,.021,.021,X+u,y,zz);
        B(seams,.019,.34,.021,X+u-.46,y-.32,zz);
      }
    }
  }
  for(let k=0;k<78;k++){
    const u0=-H+H*2*k/78, u1=-H+H*2*(k+1)/78;
    B(planks,u1-u0-.007,.16,W+.035,X+(u0+u1)*.5,Math.max(depthY(u0),depthY(u1))-.137,Z);
  }
  for(let k=0;k<3;k++)for(const side of [-1,1]){
    B(planks,1.05,.19,W+.4,X+side*(H+.51+k*.75),BRIDGE.approachY-.10-k*.14,Z);
  }
  [[rims,stonePale],[seams,stoneBody],[rail,stonePale],[planks,stoneBody],[orn,stonePale]].forEach(([arr,mat])=>{
    if(arr.length)bridge.add(mesh(arr,mat));
  });
  for(const x of [X-H+1.2,X+H-1.1]){
    const y=depthY(x-X);bridgeLamps.push([x,y+.54,Z-2.15]);
  }
  // Restrained mixed wash keeps the three openings dark, not halo-emitting.
  for(const [x,y,z,i] of [[X+16,6,12,220],[X-15,6,14,170],[X+.4,7,11.7,170],[X+11,5.2,7.2,118]]){
    const l=new THREE.PointLight(0xe0d4c1,i,26,2);l.position.set(x,y,z);scene.add(l);
  }
  // Short, inward graze on the near mouth, not a fixture or floodlight.
  // The beam ends at the underside; it is never aimed at the river.
  const innerReturn = new THREE.SpotLight(0xd7c29e, 132, 8.5, .43, .84, 2);
  innerReturn.name = 'wenheng-central-arch-return';
  innerReturn.position.set(X + .25, 1.50, Z + W * .51);
  innerReturn.target.position.set(X - 4.85, 3.96, Z + .35);
  bridge.add(innerReturn, innerReturn.target);
  const deckY=depthY;

  /* ---------------------------------------------------------------- 对岸 老屋 */
  const frontZ = CANAL.farZ + 8;
  for (let x = -300; x < 420; x += rr(7, 12)) {
    const w = rr(6.5, 11), d = rr(6, 10), h = rr(4.4, 7.4);
    B(dark, w, h, d, x, CANAL.wallTop + 0.2, frontZ + d / 2);
    B(roofs, w + 1, 0.28, d + 1, x, CANAL.wallTop + 0.2 + h, frontZ + d / 2);
    if (rand() > 0.52) {
      const p = new THREE.PlaneGeometry(1.1, 1.0);
      p.rotateY(Math.PI);
      p.translate(x + rr(-w / 3, w / 3), CANAL.wallTop + 2.5, frontZ - 0.06);
      litPanels.push(p);
    }
  }

  /* ---------------------------------------------------------------- 新城 高层 */
  const towers = [];
  for (let i = 0; i < 24; i++) {
    const w = rr(14, 26), d = rr(12, 22), h = rr(24, 48);
    const x = -320 + i * 31 + rr(-8, 8);
    const zz = 96 + rr(0, 74);
    towers.push(loft([
      { y: 0, cx: x, cz: zz, sx: w / 2, sz: d / 2 },
      { y: h * 0.8, cx: x, cz: zz, sx: w / 2, sz: d / 2 },
      { y: h, cx: x, cz: zz, sx: (w / 2) * rr(0.6, 0.95), sz: (d / 2) * rr(0.6, 0.95) },
    ], roundedSection(0.16, 3), { uvScale: 1 }));
    B(dark, 2, 2, 2, x, h, zz);
  }

  /* ---------------------------------------------------------------- 树 */
  function willow(x, z, s = 1) {
    const tr = new THREE.CylinderGeometry(0.22 * s, 0.34 * s, 3.4 * s, 7);
    tr.translate(x, CANAL.quayTopY + 1.7 * s, z);
    wood.push(tr);
    for (let i = 0; i < 4; i++) {
      const c = new THREE.SphereGeometry(1.5 * s * rr(0.7, 1.15), 8, 6);
      c.scale(1, 0.62, 1);
      c.translate(x + rr(-1.5, 1.5) * s, CANAL.quayTopY + 3.4 * s + rr(-0.3, 0.8), z + rr(-1.5, 1.5) * s);
      foliage.push(c);
    }
  }
  for (let x = -250; x < 380; x += 37) { if(x < CANAL.tributary.minX-2 || x > CANAL.tributary.maxX+2) willow(x, CANAL.nearZ - 5.5, rr(0.8, 1.15)); }
  for (let x = -240; x < 400; x += 44) {
    const s = rr(0.8, 1.1);
    const tr = new THREE.CylinderGeometry(0.2 * s, 0.3 * s, 3 * s, 6);
    tr.translate(x, CANAL.wallTop + 1.5 * s, CANAL.farZ + 5);
    wood.push(tr);
    const c = new THREE.SphereGeometry(1.4 * s, 7, 5);
    c.scale(1, 0.66, 1);
    c.translate(x, CANAL.wallTop + 3.2 * s, CANAL.farZ + 5);
    foliage.push(c);
  }

  /* ---------------------------------------------------------------- 两端的老屋 */
  // 东头续街
  for (let i = 0; i < 9; i++) {
    const x = LANE.xMin - 10 - i * 9;
    const h = rr(4.6, 7.6);
    const zz = -13 + rr(-7, 7);
    B(dark, 8.4, h, 15, x, CANAL.laneY - 0.4, zz);
    B(roofs, 9.4, 0.28, 16, x, CANAL.laneY - 0.4 + h, zz);
  }
  // 西头只补到桥那头，码头与阁前的空地留给这两处地标
  for (let i = 0; i < 5; i++) {
    const x = BRIDGE.x + 44 + i * 10;
    const h = rr(4.6, 7.2);
    const zz = -12 + rr(-6, 6);
    B(dark, 8.4, h, 14, x, CANAL.laneY - 0.4, zz);
    B(roofs, 9.4, 0.28, 15, x, CANAL.laneY - 0.4 + h, zz);
  }

  /* ---------------------------------------------------------------- assembly */
  const put = (geos, mat, name) => {
    if (!geos.length) return;
    const m = mesh(geos, mat);
    if (name) m.name = name;
    g.add(m);
  };
  put(stone, M.stone);
  put(dark, M.silhouette);
  put(wood, M.woodDark);
  put(foliage, M.foliage);
  put(roofs, M.tile);
  put(lampHeads, M.lantern);
  put(litPanels, M.lattice);

  const cityGroup = new THREE.Group();
  cityGroup.name = 'city';
  for (const geo of towers) cityGroup.add(new THREE.Mesh(geo, rand() > 0.5 ? M.cityCool : M.city));
  g.add(cityGroup);

  scene.add(g);
  return { group: g, city: cityGroup, bridge, bridgeLamps, deckY };
}
