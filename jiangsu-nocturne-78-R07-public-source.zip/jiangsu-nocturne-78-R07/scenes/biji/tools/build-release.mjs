/** Rebuild only Biji historic lane and Wenheng Bridge, preserving collection calibration and mode guards. */
import { mkdtemp, copyFile, readdir, readFile, writeFile, rename, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const repo = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const pano = join(repo, 'public/pano');
const out = process.argv[2] ? resolve(process.argv[2]) : join(pano, 'biji.html');
const scratch = await mkdtemp(join(tmpdir(),'biji-calibrate-'));
const file = join(scratch,'biji.html');
const temporary = out + '.build-' + process.pid;
const run = (...args) => execFileSync(process.execPath,args,{cwd:repo,stdio:'inherit'});
try {
  const names = (await readdir(pano)).filter(x => x.endsWith('.html') && x !== 'biji.html');
  await Promise.all(names.map(n => copyFile(join(pano,n),join(scratch,n))));
  run('scenes/tools/build-single.mjs','biji/index.html','biji/src/main.js',file);
  const calibrators = ['scenes/tools/refine-native-panorama-look.mjs','scenes/tools/guard-native-panorama-mode.mjs'];
  for (const script of calibrators) run(script,scratch);
  for (const script of calibrators) run(script,scratch,'--check');
  // Two whitespace-only hunks from the pinned Three.js source fail clean-baseline patch checks.
  // These replacements do not alter any JS token or GLSL instruction.
  const html=(await readFile(file,'utf8'))
    .replace(/^\t\t\t \tmaterial = getMaterial\( data\.material \);$/m,'\t\t\t\tmaterial = getMaterial( data.material );')
    .replace(/(fragmentShader: \/\* glsl \*\/`\n)\t\n(\t\tprecision highp float;)/,'$1\n$2');
  await writeFile(temporary,html); await rename(temporary,out);
} finally {
  await rm(scratch,{recursive:true,force:true}); await rm(temporary,{force:true});
}
